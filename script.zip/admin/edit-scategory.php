<?php 

$pageTitle = 'Alt Kategoriyi Düzenle'; 
require_once('../system/config-admin.php');
if(isset($_REQUEST['id'])){
	if(!empty($_REQUEST['id'])){
		$details = $product->scatdetails(trim($_REQUEST['id']));
	}else{
		header("location: category.php");
	}
}else{
		$details = $product->scatdetails('0');
	}
if(isset($_REQUEST['id']) && isset($_REQUEST['name'])){
	
		$id = 	trim($_REQUEST['id']);
		$name = trim($_REQUEST['name']);
		$cid = trim($_REQUEST['cat_id']);
	
		$result = $product->updatescat($id,$name,$cid);
		$details = $product->scatdetails(trim($_REQUEST['id']));
	
}
if(!empty($product->msg)){
	$success = $product->msg;
	}
	if(!empty($product->error)){
	$error = $product->error;
	}
	
	$category = $product->get_categories();
	
require_once('includes/admin-header.php');

?>

<div class="content">
  <?php if(isset($details)){ ?>
  <div class="content">
    <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav">
          <li class="nav-item"> <a class="nav-link" href="categories.php">Tüm Kategoriler</a> </li>
          <li class="nav-item"> <a class="nav-link" href="add-category.php">Kategori Ekle</a> </li>
          <li class="nav-item"> <a class="nav-link" href="deleted-categories.php">Silinmiş Kategoriler</a> </li>
        </ul>
      </div>
    </nav>
    <div class="my-3 p-3 bg-white rounded box-shadow">
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'?id='.$details['id']);?>" method="post" class="form-horizontal">
        <input type="hidden" class="form-control" name="id" value="<?php echo $details['id']; ?>" disabled>
        <div class="form-group">
          <label>Ana Kategori:</label>
          <div class="input-group mb-3">
            <select class="custom-select" name="cat_id" id="cat_id" required>
              <option selected value="2">Ana Kategori Seçiniz...</option>
              <option selected value="<?php echo $details['cat_id'];?>">Alt Kategori Seçiniz...</option>
              <?php foreach($category as $cat) {
?>
              <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
              <?php } ?>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>Alt Kategori Adı:</label>
          <input type="text" class="form-control" name="name" value="<?php echo $details['name']; ?>" id="coupon-code" required>
        </div>
        <button type="submit" class="btn btn-success w-100">Kaydet</button>
      </form>
    </div>
    <?php } ?>
  </div>
<?php require_once('includes/admin-footer.php');?>