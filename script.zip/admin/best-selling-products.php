<?php 
$pageTitle = "Çok Satılanlar";
require_once('../system/config-admin.php');
$topProducts = $product->top();
$num = count($topProducts);
require_once('includes/admin-header.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item"> <a class="nav-link" href="products.php">Tüm Ürünler</a> </li>
      <li class="nav-item"> <a class="nav-link" href="add-product.php">Ürün Ekle</a> </li>
      <li class="nav-item active"> <a class="nav-link" href="best-selling-products.php">Çok Satılanlar</a> </li>
    </ul>
  </div>
</nav>
<div class="my-3 p-3 bg-white rounded box-shadow">
<?php if($num > 0){ ?>
<table class="table table-hover table-striped table-bordered">
  <thead>
    <tr>
      <th>Ürün Adı</th>
      <th>Fiyatı</th>
      <th>İzlenme</th>
      <th>Satış</th>
    </tr>
  </thead>
  <tbody>
    <?php 
foreach($topProducts as $pro) {

?>
    <tr>
      <td><?php echo $pro['name'];?></td>
      <td class="hidden-phone"><?php echo $setting['currency_sym']." ".$pro['price'];?></td>
      <td><?php echo $pro['views'];?></td>
      <td><?php echo $pro['sales'];?></td>
    </tr>
    <?php }?>
  </tbody>
</table>
<?php 
  }else{
 echo  "<div class='alert alert-primary'>Henüz ürün yok</div>";
 }
?>
<?php require_once('includes/admin-footer.php');?>