<?php 

$pageTitle = 'Ayarlar'; 
require_once('../system/config-admin.php');
require_once('../system/gateways.php');
$active = 'web';
if(isset($_REQUEST['save'])){
if($_REQUEST['save'] == 'web'){
	$newsettings = array();
	$newsettings['website_url'] = $_REQUEST['website_url'];
	$newsettings['site_name'] = $_REQUEST['site_name'];
	$newsettings['homepage_header'] = $_REQUEST['homepage_header'];
	$newsettings['homepage_subheader'] = $_REQUEST['homepage_subheader'];
    $newsettings['global_message'] = $_REQUEST['global_message'];
    $newsettings['alert_type'] = $_REQUEST['alert_type'];
	$newsettings['support_email'] = $_REQUEST['support_email'];
	$newsettings['smtp_user'] = $_REQUEST['support_email'];
	$newsettings['smtp_auth'] = $_REQUEST['smtp_auth'];
	$newsettings['smtp_secure'] = $_REQUEST['smtp_secure'];
	$newsettings['smtp_host'] = $_REQUEST['smtp_host'];
	$newsettings['smtp_port'] = $_REQUEST['smtp_port'];
	$newsettings['smtp_pass'] = $_REQUEST['smtp_pass'];
	$newsettings['re_sitekey'] = $_REQUEST['re_sitekey'];
	$newsettings['re_securekey'] = $_REQUEST['re_securekey'];
	$newsettings['facebook'] = $_REQUEST['facebook'];
	$newsettings['twitter'] = $_REQUEST['twitter'];
	$newsettings['instagram'] = $_REQUEST['instagram'];
	$newsettings['googlep'] = $_REQUEST['googlep'];
	$newsettings['linkedin'] = $_REQUEST['linkedin'];    
    $newsettings['show_card_sde'] = (isset($_POST['show_card_sde'])) ? 1 : 0;
    
	if(empty($newsettings['website_url']) || empty($newsettings['site_name']) || empty($newsettings['homepage_header']) || empty($newsettings['homepage_subheader']) || empty($newsettings['support_email'])){
	$settings->error = 'All fields are required';
	}
	$result = (!$settings->error?$settings->update($newsettings):$settings->error);
	$active = 'web';
}
elseif($_REQUEST['save'] == 'shopier'){
	$newsettings = array();
	$newsettings['txn'] = $_REQUEST['txn'];
	$newsettings['currency'] = $_REQUEST['currency'];
	$newsettings['currency_sym'] = $_REQUEST['currency_sym'];
	$newsettings['value1'] = $_REQUEST['value1'];
	$newsettings['value2'] = $_REQUEST['value2'];
	$newsettings['value3'] = $_REQUEST['value3'];
	$newsettings['value4'] = $_REQUEST['value4'];
	$newsettings['value5'] = $_REQUEST['value5'];
	$newsettings['value6'] = $_REQUEST['value6'];
	$newsettings['apiuser'] = $_REQUEST['apiuser'];
	$newsettings['apipass'] = $_REQUEST['apipass'];
		$result = (!$settings->error?$settings->update($newsettings):$settings->error);
		$newsettings = 'shopier';
}


	}
	$setting = $settings->get_all();

	if(!empty($settings->msg)){
		$success = $settings->msg;
		}
	if(!empty($settings->error)){
		$error = $settings->error;
		}
		
require_once('includes/admin-header.php');
?>

<ul class="nav nav-tabs">
  <li class="active"><a class="nav-link active" data-toggle="tab" href="#menu1"><b>Genel</b></a></li>
  <li><a class="nav-link" data-toggle="tab" href="#menu2"><b>Email</b></a></li>
  <li><a class="nav-link" data-toggle="tab" href="#menu3"><b>Chaptcha</b></a></li>
  <li><a class="nav-link" data-toggle="tab" href="#menu4"><b>Sosyal</b></a></li>
  <li><a class="nav-link" data-toggle="tab" href="#menu5"><b>Logo</b></a></li>
  <li><a class="nav-link" data-toggle="tab" href="#menu6"><b>Shopier</b></a></li>
</ul>
<div class="my-3 p-3 bg-white rounded box-shadow">
  <div class="tab-content">
    <div id="menu1" class="tab-pane active">
    <form action="settings.php" method="post" class="form-horizontal">
      <input class="form-control" type="hidden" name="save" value="web">
      <h3>Genel Ayarlar</h3>
      <div class="form-group">
        <label class="control-label" for="website-url">Website URL</label>
        <input class="form-control" type="text" name="website_url" value="<?php echo $setting['website_url'] ; ?>" id="website-url">
      </div>
      <div class="form-group">
        <label>Site Mesajı (Yoksa boş bırakın):</label>
        <div class="input-group">
          <input type="text" class="form-control" value="<?php echo $setting['global_message'] ; ?>" name="global_message">
          <div class="input-group-append">
            <select class="form-control" name="alert_type">
              <option value="success" class="alert-success">Success</option>
              <option value="info" class="alert-info">Info</option>
              <option value="warning" class="alert-warning">Warning</option>
              <option value="primary" class="alert-primary" selected="selected">Primary</option>
              <option value="danger" class="alert-danger">Danger</option>
            </select>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="control-label" for="site-name">Site Başlık</label>
        <input class="form-control" type="text" name="site_name" value="<?php echo $setting['site_name'] ; ?>" id="site-name">
      </div>
      <div class="form-group">
        <label class="control-label" for="site-name">Anasayfa Başlık</label>
        <input class="form-control" type="text" name="homepage_header" value="<?php echo $setting['homepage_header'] ; ?>" id="homepage-header">
      </div>
      <div class="form-group">
        <label class="control-label" for="site-name">Homepage Subheader</label>
        <input class="form-control" type="text" name="homepage_subheader" value="<?php echo $setting['homepage_subheader'] ; ?>" id="homepage-subheader">
      </div>
      <div class="form-group">
        <input type="checkbox" name="show_card_sde" <?php if ($setting['show_card_sde'] == 1) {echo 'checked="checked"';} ?> id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Ürün kısa açıklamaları görünsün mü?</label>
      </div>
      <hr>
      <div class="form-group">
        <button class="btn btn-success" type="submit" name="submit">Ayarları Kaydet</button>
      </div>
      </div>
      <div id="menu2" class="tab-pane">
        <h3>Email Ayarları</h3>
        <div class="form-group">
          <label class="control-label" for="support-email">Destek Emaili</label>
          <input class="form-control" type="email" name="support_email" value="<?php echo $setting['support_email'] ; ?>" id="support_email">
        </div>
        <div class="form-group">
          <label class="control-label" for="smtp-auth">SMTP Doğrulaması (Önerilir)</label>
          <select class="form-control" name="smtp_auth">
            <option value="">Seçiniz</option>
            <option <?php if($setting['smtp_auth'] === 'true') echo 'selected'; ?> value="true">Evet</option>
            <option <?php if($setting['smtp_auth'] === 'false') echo 'selected'; ?> value="false">Hayır</option>
          </select>
        </div>
        <div class="form-group">
          <label class="control-label" for="smtp-secure">SMTP Güvenliği (SSL or TLS)</label>
          <select class="form-control" name="smtp_secure">
            <option value="">Seçiniz</option>
            <option <?php if($setting['smtp_secure'] === 'ssl') echo 'selected'; ?> value="ssl">SSL</option>
            <option <?php if($setting['smtp_secure'] === 'tls') echo 'selected'; ?> value="tls">TLS</option>
          </select>
        </div>
        <div class="form-group">
          <label class="control-label" for="smtp-host">SMTP Host (Örn.: mail.benimdomain.com)</label>
          <input class="form-control" type="text" name="smtp_host" value="<?php echo $setting['smtp_host']; ?>" id="smtp_host">
        </div>
        <div class="form-group">
          <label class="control-label" for="smtp-port">SMTP Port (Genellikle 465 yada 587)</label>
          <input class="form-control" type="text" name="smtp_port" value="<?php echo $setting['smtp_port']; ?>" id="smtp_port">
        </div>
        <div class="form-group">
          <label class="control-label" for="smtp-pass">SMTP Şifre (Email şifreniz)</label>
          <input class="form-control" type="password" name="smtp_pass" value="<?php echo $setting['smtp_pass']; ?>" id="smtp_pass">
        </div>
        <hr>
        <div class="form-group">
          <button class="btn btn-success" type="submit" name="submit">Ayarları kaydet</button>
        </div>
      </div>
      <div id="menu3" class="tab-pane">
        <h3>reChapcha Ayarları</h3>
        <div class="form-group">
          <label class="control-label" for="re_sitekey">reChapcha Site Anahtarı (reChapcha kullanmayacaksanız boş bırakın)</label>
          <input class="form-control" type="password" name="re_sitekey" value="<?php echo $setting['re_sitekey'] ; ?>" id="re_sitekey">
        </div>
        <div class="form-group">
          <label class="control-label" for="re_securekey">reChapcha Gizli Anahtar (reChapcha kullanmayacaksanız boş bırakın)</label>
          <input class="form-control" type="password" name="re_securekey" value="<?php echo $setting['re_securekey'] ; ?>" id="re_securekey">
        </div>
        <hr>
        <div class="form-group">
          <button class="btn btn-success" type="submit" name="submit">Ayarları katdet</button>
        </div>
      </div>
      <div id="menu4" class="tab-pane">
        <h3>Sosyal Linkler</h3>
        <div class="form-group">
          <label class="control-label" for="facebook">Facebook (Komple link https:// ile)</label>
          <input class="form-control" type="text" name="facebook" value="<?php echo $setting['facebook']; ?>" id="facebook">
        </div>
        <div class="form-group">
          <label class="control-label" for="twitter">Twitter (Komple link https:// ile)</label>
          <input class="form-control" type="text" name="twitter" value="<?php echo $setting['twitter']; ?>" id="twitter">
        </div>
        <div class="form-group">
          <label class="control-label" for="instagram">Instagram (Komple link https:// ile)</label>
          <input class="form-control" type="text" name="instagram" value="<?php echo $setting['instagram']; ?>" id="instagram">
        </div>
        <div class="form-group">
          <label class="control-label" for="linkedin">Google+ (Komple link https:// ile)</label>
          <input class="form-control" type="text" name="googlep" value="<?php echo $setting['googlep']; ?>" id="googlep">
        </div>
        <div class="form-group">
          <label class="control-label" for="linkedin">LinkedIn (Komple link https:// ile)</label>
          <input class="form-control" type="text" name="linkedin" value="<?php echo $setting['linkedin']; ?>" id="linkedin">
        </div>
        <hr>
        <div class="form-group">
          <button class="btn btn-success" type="submit" name="submit">Save Settings</button>
        </div>
      </div>
    </form>
    <div id="menu5" class="tab-pane">
      <form name="updatedata" id="upload1" class="form-horizontal">
        <h3>Logo ve Favicon Ayarları</h3>
        <img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="30">
        <div class="form-group">
          <label>Logo (.PNG,.JPG):</label>
          <div class="input-group">
            <div class="custom-file">
              <input type="file" name="logoimg" class="custom-file-input" id="inputGroupFile04">
              <label class="custom-file-label" for="inputGroupFile04">Dosya Seçin</label>
            </div>
          </div>
        </div>
        <img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_favicon']; ?>" height="30">
        <div class="form-group">
          <label>Favicon (.PNG,.JPG):</label>
          <div class="input-group">
            <div class="custom-file">
              <input type="file" name="faviconimg" class="custom-file-input" id="inputGroupFile04">
              <label class="custom-file-label" for="inputGroupFile04">Dosya Seçin</label>
            </div>
          </div>
        </div>
        <input class="form-control" type="hidden" name="id" value="<?php echo $productDetails['id'];?>">
        <hr>
        <button type="submit" id="btn" class="btn btn-success w-100">Resimleri kaydet</button>

        <div id="res1"></div>
      </form>
    </div>
    <div id="menu6" class="tab-pane">
      <div class="col-md-12">
      <form action="settings.php" method="post" class="form-horizontal">
        <input class="form-control" type="hidden" name="save" value="shopier">
        
        <h3>Ödeme Ayarları</h3>
        <div class="row">
          <input class="form-control" type="hidden" name="txn" value="0" id="txn">
          <div class="col-md-4">
            <div class="form-group">
          <label class="control-label" for="curr">Para Birimi</label>
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1">TRY</span> </div>
          <input class="form-control" type="text" name="currency" value="<?php echo $setting['currency']; ?>" id="curr">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
          <label class="control-label" for="curr">Para Birimi Sembolü</label>
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
          <input class="form-control" type="text" name="currency_sym" value="<?php echo $setting['currency_sym']; ?>" id="curr-sym">
              </div>
            </div>
          </div>
        </div>
        <hr />
        <h3>Shopier Ayarları</h3>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value1" value="<?php echo $setting['value1'] ; ?>" id="curr">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value2" value="<?php echo $setting['value2'] ; ?>">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value3" value="<?php echo $setting['value3'] ; ?>">
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value4" value="<?php echo $setting['value4'] ; ?>">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value5" value="<?php echo $setting['value5'] ; ?>">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-lira-sign"></i></span> </div>
                <input class="form-control" type="text" name="value6" value="<?php echo $setting['value6'] ; ?>">
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i>Api Kullanıcı</i></span> </div>
                <input class="form-control" type="password" name="apiuser" value="<?php echo $setting['apiuser'] ; ?>">
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i>Api Şifre</i></span> </div>
                <input class="form-control" type="password" name="apipass" value="<?php echo $setting['apipass'] ; ?>">
              </div>
            </div>
          </div>
        </div>
        <div class="form-group">
          <button class="btn btn-success" type="submit" name="submit">Kaydet</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
  $("#upload1").on("submit",(function(e) {
    e.preventDefault();
    $.ajax({
          url: "ajax-update-settings.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,
      beforeSend: function() 
        {
            $("#res1").html('Yükleniyot... Lütfen bekleyin...!');
        },  
        success: function(response)
        {
            $("#res1").html(response);
        }        
     });
  }));
  
  $('.custom-file-input').on('change', function() { 
      fileName = $(this).val().split('\\').pop(); 
      $(this).next('.custom-file-label').addClass("selected").html(fileName); 
  });

</script>
<?php require_once('includes/admin-footer.php'); ?>