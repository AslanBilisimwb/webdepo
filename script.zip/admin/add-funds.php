<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle = "Bakiye Ekle";
require_once('../system/config-admin.php');
$customer = new Customer($DB_con);
$_SESSION['payment']['use_prepaid'] = false;
if(isset($_REQUEST['id'])){
$customerDetails = $customer->details($_REQUEST['id']);
$error = ($customer->error?$customer->error:false);

if(isset($_GET['action']) && $_GET['action'] == 'add'){

if(!$error){
$customer->add_funds($_REQUEST['id'],$_REQUEST['amt']);
$error = ($customer->error?$customer->error:false);

$success = $error?$error:'Bakiye eklendi. 3sn içinde "Kullanıcılar" sayfasına yönlendirileceksiniz..';
header('Refresh: 3; url=users.php');
}
}


}else{
require_once('includes/admin-header.php');
echo 'Geçersiz istek';
require_once('includes/admin-footer.php');
exit;
}
if(empty($error)){
unset($error);
}
require_once('includes/admin-header.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item"> <a class="nav-link" href="users.php">Tüm Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="new-users.php">Yeni Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="banned-users.php">Banlı Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="top-buyers.php">Çok Alanlar</a> </li>
    </ul>
  </div>
</nav>
<div class="my-3 p-3 bg-white rounded box-shadow">
  <div class="row">
    <div class="col-md-12">
      <?php if(isset($customerDetails)){
?>
      <form class="form-horizontal" id="customerFund" method="POST" action="add-funds.php?action=add">
        <input class="form-control" type="hidden" name="id" value="<?php echo $customerDetails['id']; ?>">
        <div class="form-group">
          <label for="exampleInputPassword1">Mevcut Bakiye</label>
          <input type="text" class="form-control" id="exampleInputPassword1" name="bal" value="<?php echo $customerDetails['balance']; ?>"  disabled>
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Eklenecek Tutar</label>
          <input type="number" class="form-control" id="exampleInputEmail1" name="amt" aria-describedby="emailHelp" placeholder="Tutar ekle" required>
          <small id="emailHelp" class="form-text text-muted">Bakiye eklendiğinde kullanıcıya email ile bildirilecektir!</small> </div>
        <div class="form-group">
          <button type="submit" class="btn btn-info w-100">Bakiye Ekle</button>
        </div>
      </form>
      <?php 
}
?>
    </div>
  </div>
</div>
<?php require_once('includes/admin-footer.php');?>