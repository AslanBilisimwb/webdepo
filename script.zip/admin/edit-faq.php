<?php 

$pageTitle = 'SSS Düzenle'; 
require_once('../system/config-admin.php');
if(isset($_REQUEST['id'])){
	if(!empty($_REQUEST['id'])){
		$details = $faq->details(trim($_REQUEST['id']));
	}else{
		header("location: faq.php");
	}
}else{
		$details = $faq->details('0');
	}
if(isset($_REQUEST['id']) && isset($_REQUEST['title']) && isset($_REQUEST['content'])){
	
		$id = 	trim($_REQUEST['id']);
		$title = trim($_REQUEST['title']);
		$content = trim($_REQUEST['content']);
	
		$result = $faq->updatefaqs($id,$title,$content);
		$details = $faq->details(trim($_REQUEST['id']));
	
		
	
}
if(!empty($faq->msg)){
	$success = $faq->msg;
	}
	if(!empty($faq->error)){
	$error = $faq->error;
	}	
require_once('includes/admin-header.php');

?>

<div class="content">
  <?php if(isset($details)){ ?>
  <div class="content">
    <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav">
          <li class="nav-item"> <a class="nav-link" href="faq.php">Tüm SSS'ler</a> </li>
          <li class="nav-item"> <a class="nav-link" href="add-faq.php">SSS Ekle</a> </li>
          <li class="nav-item"> <a class="nav-link" href="deleted-faq.php">Silinmiş SSS'ler</a> </li>
        </ul>
      </div>
    </nav>
    <div class="my-3 p-3 bg-white rounded box-shadow">
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'?id='.$details['id']);?>" method="post" class="form-horizontal">
        <input type="hidden" class="form-control" name="id" value="<?php echo $details['id']; ?>">
        <div class="form-group">
          <label>Soru:</label>
          <input type="text" class="form-control" name="title" value="<?php echo $details['title']; ?>" id="coupon-code" required>
        </div>
        <div class="form-group">
          <label>Cevap:</label>
          <textarea type="text" class="form-control" name="content" id="coupon-code"><?php echo $details['content']; ?></textarea>
        </div>
        <button type="submit" class="btn btn-success w-100">Kaydet</button>
      </form>
    </div>
    <?php } ?>
  </div>
  <script type="text/javascript">
	tinymce.init({
		selector: "textarea",
		themes: "modern",
		branding: false,
		  plugins: [
    'advlist autolink lists link image charmap preview',
    'visualblocks code',
    'insertdatetime media contextmenu paste code'
  ],
  toolbar: 'bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code'
	});
</script>
<?php require_once('includes/admin-footer.php');?>