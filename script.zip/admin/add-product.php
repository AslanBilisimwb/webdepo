<?php 

$pageTitle = "Ürün Ekle";
require_once('../system/config-admin.php');

$category = $product->get_categories();
//$category1 = $product->get_subcategories();
require_once('includes/admin-header.php');
?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="products.php">Tüm Ürünler</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="add-product.php">Ürün Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="best-selling-products.php">Çok Satanlar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
  <form id="upload" class="form-horizontal">
    <div class="form-group">
      <label>Ürün Adı (Max. 50 karakter):</label>
      <input class="form-control" name="name" id="coupon-code" type="text" minlength="10" maxlength="50" required>
    </div>
    <div class="form-group">
      <label>Kısa Açıklama (Max. 80 karakter):</label>
      <input class="form-control" name="sdesc" id="coupon-code" type="text" maxlength="80">
    </div>
    <div class="form-group">
      <label>Açıklama:</label>
      <textarea type="text" class="form-control" name="description" id="coupon-code" minlength="100"></textarea>
    </div>
    <hr>
    <div class="form-group">
      <label>Kategori:</label>
      <div class="input-group mb-3">
        <select class="custom-select" name="cat_id" id="cat_id" required>
          <option value="">Kategori Seçin...</option>
          <?php foreach($category as $cat) {
?>
          <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
          <?php } ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Alt Kategori:</label>
      <div class="input-group mb-3">
        <select class="custom-select" name="subcat" id="subcat" required>
          <option value="">Alt Kategori seçin...</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Fiyatı:</label>
      <div class="input-group mb-3">
        <div class="input-group-prepend"> <span class="input-group-text">$</span> </div>
        <input type="number" name="price" class="form-control" aria-label="Amount" required>
        <div class="input-group-append"> <span class="input-group-text">.00</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label>Canlı Demo(http://www.ornekwebsite.com):</label>
      <input class="form-control" name="demo" id="coupon-code" type="url" pattern="https?://.+[^()/><\][\\\x22,;|]+" title="http://ile yazın ve özel karakter kullanmayın">
    </div>    
    <hr>
    <div class="form-check">
      <input type="checkbox" name="featured" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Öne çıkan ürün</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="free" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Üctersiz ürün</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="free_ins" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Ücretsiz kurulum hizmeti</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="support" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Ürün desteği</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="reviews_off" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Yoruma kapalı</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="views_off" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">İzlenme sayılarını gizle</label>
    </div>
    <div class="form-check">
      <input type="checkbox" name="stock_on" id="exampleCheck1" data-toggle="collapse" data-target="#stockcoll" aria-expanded="false" aria-controls="stockcoll">
      <label class="form-check-label" for="exampleCheck1">Stok miktarı uygulansın mı?</label>
    </div>
    <div class="collapse" id="stockcoll"> <br>
      <div class="card card-body">
        <div class="form-group">
          <label>Stok miktarı:</label>
          <div class="input-group mb-0">
            <input class="form-control" value="0" name="stock" type="number">
          </div>
        </div>
      </div>
    </div>
    <hr>
    <div class="form-group">
      <label>Icon (80x80px and .PNG or .JPG):</label>
      <div class="input-group">
        <div class="custom-file">
          <input type="file" name="iconimgfile" class="custom-file-input" id="inputGroupFile04" required>
          <label class="custom-file-label" for="inputGroupFile04">Dosya Seçin</label>
        </div>
      </div>
    </div>
    <div class="form-group">
      <label>Afiş (Ön izleme resmi) (590x300px and .PNG or .JPG):</label>
      <div class="input-group">
        <div class="custom-file">
          <input type="file" name="previewimgfile" class="custom-file-input" id="inputGroupFile04" required>
          <label class="custom-file-label" for="inputGroupFile04">Dosya Seçin</label>
        </div>
      </div>
    </div>
    <div class="form-group">
      <label>Ürün dosyası (.ZIP):</label>
      <div class="input-group">
        <div class="custom-file">
          <input type="file" name="mainfile" class="custom-file-input" id="inputGroupFile04" required>
          <label class="custom-file-label" for="inputGroupFile04">Dosya Seçin</label>
        </div>
      </div>
    </div>
    <hr>
    <button type="submit" id="btn" class="btn btn-success w-100">Ürünü Kaydet</button>
    <div class="progress mt-3 none">
              <div class="progress-bar width0" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"> </div>
    </div>
    <div id="res"></div>
  </form>
  <script type="text/javascript">
$(function() {
 
 $("#cat_id").bind("change", function() {
     $.ajax({
         type: "GET", 
         url: "ajax-category.php",
         data: "cat_id="+$("#cat_id").val(),
         success: function(html) {
             $("#subcat").html(html);
         }
     });
 });
            
 
});

  $("#upload").on("submit",(function(e) {
      tinyMCE.triggerSave();
    e.preventDefault();
            e.stopImmediatePropagation();
            var formData = new FormData($(this)[0]);
            var file = $('input[type=file]')[0].files[0];
            formData.append('upload_file',file);
            $('.progress').show();
    $.ajax({
         xhr: function() {
                    var xhr = new window.XMLHttpRequest();
                    xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total;
                            percentComplete = parseInt(percentComplete * 100);
                            $('.progress-bar').css('width',percentComplete+"%");
                            $('.progress-bar').html(percentComplete+"%");
                            if (percentComplete === 100) {
                        }
                      }
                    }, false);
                    return xhr;
                  },
        
      url: "ajax-upload.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,
      beforeSend: function() 
        {
            $("#res").html('Yükleniyor, bekleyin...!');
        },  
        success: function(response)
        {
            $("#res").html(response);
        },  
error: function(xhr, ajaxOptions, thrownError){
                    alert(xhr.status);
                }
     });
  }));
   
   $('.custom-file-input').on('change', function() { 
		 fileName = $(this).val().split('\\').pop(); 
		 $(this).next('.custom-file-label').addClass("selected").html(fileName); 
   });

	tinymce.init({
		selector: "textarea",
		themes: "modern",
		branding: false,
		  plugins: [
    'advlist autolink lists link image charmap preview',
    'visualblocks code',
    'insertdatetime media contextmenu paste code'
  ],
  toolbar: 'bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code'
	});
	</script>
<?php require_once('includes/admin-footer.php');?>