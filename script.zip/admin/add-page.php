<?php 

$pageTitle = 'Sayfa Ekle'; 
require_once('../system/config-admin.php');

if(isset($_REQUEST['title']) && isset($_REQUEST['content']) && isset($_REQUEST['level'])){

	$title = trim($_REQUEST['title']);
	$content = trim($_REQUEST['content']);
	$level = trim($_REQUEST['level']);
	
$result = $pages->add($title,$content,$level);

}
	if(!empty($pages->msg)){
		$success = $pages->msg;
		}
	if(!empty($pages->error)){
		$error = $pages->error;
		}
require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="custom-pages.php">Tüm Sayfalar</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="add-page.php">Sayfa Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="deleted-pages.php">Silinmiş Sayfalar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="form-horizontal">
      <div class="form-group">
        <label>Başlık:</label>
        <input type="text" class="form-control" name="title" id="coupon-code" required>
      </div>
      <div class="form-group">
        <label>İçerik:</label>
        <textarea type="text" class="form-control" name="content" id="coupon-code"></textarea>
      </div>
      <div class="form-group">
        <label>Erişilebilirlik:</label>
        <div class="input-group mb-3">
          <select class="custom-select" name="level" required>
            <option value="1">Sadece giriş yapanlar görebilir</option>
            <option value="0">Herkes görebilir</option>
          </select>
        </div>
      </div>
      <button type="submit" class="btn btn-success w-100">Sayfa Ekle</button>
    </form>
  </div>
</div>
  <script type="text/javascript">
	tinymce.init({
		selector: "textarea",
		themes: "modern",
		branding: false,
		  plugins: [
    'advlist autolink lists link image charmap preview',
    'visualblocks code',
    'insertdatetime media contextmenu paste code'
  ],
  toolbar: 'bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code'
	});
  </script>
<?php require_once('includes/admin-footer.php');?>