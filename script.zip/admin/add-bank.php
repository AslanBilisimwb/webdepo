<?php 

$pageTitle = 'Banka Ekle'; 
require_once('../system/config-admin.php');

if(isset($_REQUEST['title']) && isset($_REQUEST['content'])){

	$title = trim($_REQUEST['title']);
	$content = trim($_REQUEST['content']);
$result = $bank->add($title,$content);

}
	if(!empty($bank->msg)){
		$success = $bank->msg;
		}
	if(!empty($bank->error)){
		$error = $bank->error;
		}
require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="bank.php">Tüm Bankalar</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="add-bank.php">Banka Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="deleted-bank.php">Silinmiş Bankalar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="form-horizontal">
      <div class="form-group">
        <label>Banka Adı:</label>
        <input type="text" class="form-control" name="title" id="coupon-code" required>
      </div>
      <div class="form-group">
        <label>Hesap/IBAN bilgileri:</label>
        <textarea type="text" class="form-control" name="content" id="coupon-code"></textarea>
      </div>
      <button type="submit" class="btn btn-success w-100">Banka Ekle</button>
    </form>
  </div>
<?php require_once('includes/admin-footer.php');?>