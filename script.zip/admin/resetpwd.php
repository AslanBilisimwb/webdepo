<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('../system/config-admin.php');
$pageTitle ='Şifre Sıfırla';

if($_POST && isset($_REQUEST['submit'])){

$npwd = $_POST['edit_new_pwd'];
$npwd2 = $_POST['edit_new_pwd2'];

if(!empty($npwd)){
$details = $auth->details($_SESSION['uid']);
if($npwd == $npwd2){
$result= $auth->update($_SESSION['uid'],'password',md5($npwd));
$result= $auth->update($_SESSION['uid'],'password_recover','0');
$auth->msg ="Password changed successfully!";
echo '<script>window.location = "' . $setting['website_url'] . '/admin/index.php"</script>';
}
else{
$auth->error  = 'Şifreler uyuşmuyor!';
}
}
else{
$auth->error  = 'Tüm alanları doldurunuz!';
}

}

?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<script src="../system/assets/js/jquery.min.js"></script>
	<link href="../system/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="../system/assets/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../system/assets/css/my-login.css">
	<title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
	</head>
	<body class="my-login-page">
    <section class="">
      <div class="container h-100">
        <div class="row justify-content-md-center align-items-center h-100">
          <div class="card-wrapper mt-5">
            <div class="card fat">
              <div class="card-body">
                <?php
if($auth->msg){
				echo  "<div class=\"alert alert-success block\">".$auth->msg."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				if($auth->error){
				echo "<div class=\"alert alert-danger block\">".$auth->error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				?>
                <h4 class="card-title text-center">Şifre Sıfırla</h4>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
                  <div class="form-group">
                    <div class="form-group">
                      <label for="email">Yeni Şifre</label>
                      <input id="email" type="password" class="form-control" name="edit_new_pwd" value="" minlength="6" pattern=".{6,}" autofocus>
                    </div>
                    <div class="form-group">
                      <label for="email">Yeni Şifre Tekrar</label>
                      <input id="email" type="password" class="form-control" name="edit_new_pwd2" value="" minlength="6" pattern=".{6,}" autofocus>
                    </div>
                    <div class="form-text text-muted"> Yeni şifre talebinizden dolayı şifrenizi sıfırlamalısınız! </div>
                  </div>
                  <div class="form-group no-margin">
                    <button type="submit" name="submit" class="btn btn-primary btn-block"> Change Password </button>
                  </div>
                </form>
              </div>
            </div>
            <div class="footer"> Copyright &copy; <?php echo $setting['site_name']; ?> </div>
          </div>
        </div>
      </div>
    </section>
</body>
</html>