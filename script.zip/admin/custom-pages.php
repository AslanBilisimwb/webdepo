<?php 

$pageTitle = 'Sayfalar'; 
require_once('../system/config-admin.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$num = $pages->countAll();
$cpages = $pages->get_all_pages();
require_once('includes/admin-header.php');

?>

<div class="content">
<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item active"> <a class="nav-link" href="custom-pages.php">Tüm Sayfalar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="add-page.php">Sayfa Ekle</a> </li>
      <li class="nav-item"> <a class="nav-link" href="deleted-pages.php">Silinmiş Sayfalar</a> </li>
    </ul>
  </div>
</nav>
<div class="my-3 p-3 bg-white rounded box-shadow">
<?php if($num == 0){
?>
<h2 align='center'>Henüz sayfa yok</h2>
<?php
}else{?>
<table class="table table-hover table-striped table-bordered">
  <thead>
    <tr>
      <th>Başlık</th>
      <th>Kural</th>
      <th>Tarih</th>
      <th>Durum</th>
      <th>İşlemler</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($cpages as $cpag) {
?>
    <tr>
      <td><a href="" class="header"><?php echo $cpag['title']?></a></td>
      <td><?php echo ($cpag['level']=='1'?'<span class="badge badge-warning">Sadece giriş yapanlar</span>':'<span class="badge badge-success">Herkese açık</span>'); ?></td>
      <td><p><?php echo $cpag['indate']?></p></td>
      <td><p><?php echo ($cpag['active']=='1'?'<span class="badge badge-success">Yayında</span>':'<span class="badge badge-danger">Silindi</span>'); ?></p></td>
      <td><div class="btn-group btn-group-sm" role="group" aria-label="AActions"> <a href="<?php echo $setting['website_url'];?>/page/<?php echo $cpag['id']; ?>/" class="btn btn-warning text-white" title="İncele" data-toggle="tooltip"><i class="fas fa-search-plus"></i></a> <a href="edit-page.php?id=<?php echo $cpag['id']; ?>" class="btn btn-info" title="Düzenle" data-toggle="tooltip"><i class="fas fa-pencil-alt"></i></a> <a href="remove-page.php?id=<?php echo $cpag['id']; ?>" class="btn btn-danger" title="Sil" data-toggle="tooltip"><i class="fas fa-trash-alt"></i></a> </div></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
<?php } ?>
<?php require_once('includes/admin-footer.php');?>