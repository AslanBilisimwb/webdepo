<?php 

$pageTitle = "Yeni Kullanıcılar";
require_once('../system/config-admin.php');
$customer = new Customer($DB_con);
$top = $customer->newUsers();
$num = count($top);
require_once('includes/admin-header.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item"> <a class="nav-link" href="users.php">Tüm Kullanıcılar</a> </li>
      <li class="nav-item active"> <a class="nav-link" href="new-users.php">Yeni Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="banned-users.php">Banlı Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="top-buyers.php">Çok Alanlar</a> </li>
    </ul>
  </div>
</nav>
<?php if($num > 0){ ?>
<div class="my-3 p-3 bg-white rounded box-shadow">
  <div class="row">
    <div class="col-md-12">
      <table class="table table-hover table-striped table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th class="hidden-phone">Alımlar</th>
            <th class="hidden-phone">Bakiye</th>
            <th class="hidden-phone">Katılım</th>
            <th>İşlemler</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($top as $topUser){?>
          <tr>
            <td><?php echo $topUser['id'];?></td>
            <td><?php echo $topUser['email'];?></td>
            <td class="hidden-phone"><?php echo $topUser['purchases'];?></td>
            <td class="hidden-phone"><?php echo $setting['currency_sym'] ." ".$topUser['balance'];?></td>
            <td class="hidden-phone"><?php echo $topUser['created'];?></td>
            <td><div class="btn-group btn-group-sm" role="group" aria-label="AActions"> <a href="add-funds.php?id=<?php echo $topUser['id'];?>" class="btn btn-success" title="Bakiye ekle" data-toggle="tooltip"><i class="fas fa-plus"></i></a> <a href="ban-user.php?id=<?php echo $topUser['id'];?>" class="btn btn-danger" title="Ban User" data-toggle="tooltip"><i class="fas fa-minus-circle"></i></a> </div></td>
          </tr>
          <?php }?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php 
  }else{
 echo  "<div class='alert alert-danger'>Şimdilik yeni kullanıcı yok!</div>";
 }
?>
<?php require_once('includes/admin-footer.php');?>