<?php 

$pageTitle = 'Kupon Ekle'; 
require_once('../system/config-admin.php');

if(isset($_REQUEST['coupon_code']) && isset($_REQUEST['coupon_off'])){

	$coupon_code = trim($_REQUEST['coupon_code']);
	$coupon_off = trim($_REQUEST['coupon_off']);
	$coupon_off_type = trim($_REQUEST['coupon_off_type']);
	$order_min = trim($_REQUEST['order_min']);
$result =$coupon->add($coupon_code,$coupon_off,$coupon_off_type,$order_min );

}
	if(!empty($coupon->msg)){
		$success = $coupon->msg;
		}
	if(!empty($coupon->error)){
		$error = $coupon->error;
		}
require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="coupons.php">Tüm Kuponlar</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="add-coupon.php">Kupon Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="deleted-coupons.php">Silinmiş Kuponlar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="form-horizontal">
      <div class="form-group">
        <label>Kupon Kodu:</label>
        <input type="text" class="form-control" name="coupon_code" id="coupon-code" required>
      </div>
      <div class="form-group">
        <label>Kupon İndirimi:</label>
        <div class="input-group">
          <input type="number" class="form-control" name="coupon_off" id="coupon-code" required>
          <div class="input-group-append">
            <select class="form-control" name="coupon_off_type" id="coupon-off-type">
              <option value="1" disabled>%</option>
              <option value="2" selected><?php echo $setting['currency_sym']; ?></option>
            </select>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label>Min. Geçerlilik Fiyatı:</label>
        <div class="input-group mb-3">
          <div class="input-group-prepend"> <span class="input-group-text"><?php echo $setting['currency_sym']; ?></span> </div>
          <input type="number" class="form-control" name="order_min" required>
        </div>
      </div>
      <button class="btn btn-success w-100">Kupon Ekle</button>
    </form>
  </div>
</div>
<?php require_once('includes/admin-footer.php');?>