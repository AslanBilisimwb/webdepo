<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle = "Kullanıcı Yönetimi";
require_once('../system/config-admin.php');
$customer = new Customer($DB_con);
$allCustomers = $customer->all();
$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;
$maxres = 25;
$num = $customer->countAll();
$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
$allCustomers = $customer->getUsers($start,$maxres);
if(isset($_GET['msg'])){
	$success=	$_GET['msg'];
}else{
	unset($success);
}

require_once('includes/admin-header.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item active"> <a class="nav-link" href="users.php">Tüm Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="new-users.php">Yeni Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="banned-users.php">Banlı Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="top-buyers.php">Çok Alanlar</a> </li>
    </ul>
  </div>
</nav>
<?php if($num > 0){ ?>
<div class="my-3 p-3 bg-white rounded box-shadow">
  <div class="row">
    <div class="col-md-12">
      <div class="table-responsive">
        <table class="table table-hover table-striped table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Email</th>
              <th class="hidden-phone">Alımlar</th>
              <th class="hidden-phone">Hbr.Abone</th>
              <th class="hidden-phone">Bakiye</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php 
foreach($allCustomers as $customer) {
?>
            <tr>
              <td><?php echo $customer['id'];?></td>
              <td ><?php echo $customer['email'];?></td>
              <td class="hidden-phone"><?php echo $customer['purchases'];?></td>
              <td class="hidden-phone"><?php echo ($customer['allow_email']=='1'?'<span data-toggle="tooltip" data-placement="top" title="Evet" class="badge badge-success"><i class="fas fa-check" aria-hidden="true"></i></span>':'<span data-toggle="tooltip" data-placement="top" title="Hayır" class="badge badge-danger"><i class="fas fa-times" aria-hidden="true"></i></span>');?></td>
              <td class="hidden-phone"><?php echo $setting['currency_sym'] ." ".$customer['balance'];?></td>
              <td><div class="btn-group btn-group-sm" role="group" aria-label="AActions"> <a href="edit-user.php?id=<?php echo $customer['username'];?>" class="btn btn-info" title="Düzenle" data-toggle="tooltip"><i class="fas fa-pencil-alt"></i></a> <a href="user-purchases.php?id=<?php echo $customer['id'];?>" class="btn btn-warning" title="Alımlar" data-toggle="tooltip"><i class="fas fa-shopping-basket"></i></a> <a href="add-funds.php?id=<?php echo $customer['id'];?>" class="btn btn-success" title="Bakiye Yükle" data-toggle="tooltip"><i class="fas fa-plus"></i></a> <a href="ban-user.php?id=<?php echo $customer['id'];?>" class="btn btn-danger" title="Banla" data-toggle="tooltip"><i class="fas fa-minus-circle"></i></a> </div></td>
            </tr>
            <?php }?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<br>
<ul class="pagination justify-content-center">
  <?php 
$back = (($currpage == 1)? '#':'users.php?page='.($currpage-1));
$next = (($currpage == $pages)? 'users.php?page='.$currpage:'users.php?page='.($currpage+1));
?>
  <li class="page-item"> <a class="page-link" <?php echo ($currpage == 1)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Önceki" href="<?php echo $back;?>" tabindex="-1"><i class="fa fa-chevron-left" aria-hidden="true"></i></a> </li>
  <li class="page-item"> <a class="page-link" <?php echo ($currpage == $pages)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Sonraki" href="<?php echo $next;?>"><i class="fa fa-chevron-right" aria-hidden="true"></i></a> </li>
</ul>
<?php 
   }else{
 echo  "<div class='alert'>Henüz kayıtlı bir kullanıcı yok</div>";
 }
?>
<?php require_once('includes/admin-footer.php');?>