</div>
</div>
</div>
<div class="footer">
  <div class="container text-center"> <b class="copyright">&copy; <?php echo date('Y');?> TheScriptMarket - by ZodiaxWeb </b>All rights reserved. </div>
</div>
</body>
</html>