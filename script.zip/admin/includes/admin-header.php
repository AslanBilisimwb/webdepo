<!DOCTYPE html>
<html lang="tr">
<head>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
<script src="../system/assets/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/bootstrap.min.css">
<script src="../system/assets/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/all.css">
<script defer src="../system/assets/js/all.js"></script>
<link type="text/css" href="css/theme.css" rel="stylesheet">
<script src="../system/assets/tinymce/tinymce.min.js"></script>
<script>
$( document ).ready(function() {

    $('[data-toggle="tooltip"]').tooltip();

});
</script>
</head>
<body>
<?php if($auth->is_loggedin()){ ?>
<div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow">
  <h5 class="my-0 mr-md-auto font-weight-normal"><a href="<?php echo $setting['website_url']; ?>" >
    <?php if(empty($setting['site_logo'])){ ?>
    <?php echo $setting['site_name'];?>
    <?php } else{?>
    <img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="30">
    <?php } ?>
    </a></h5>
  <nav class="my-2 my-md-0 mr-md-3"> <a class="p-2 text-dark" href="<?php echo $setting['website_url']; ?>">Mağazaya Git</a> </nav>
  <div class="dropdown">
    <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Merhaba, Admin </button>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="account.php"><i class="far fa-address-card"></i> Hesabım</a> <a class="dropdown-item" href="login.php?logout"><i class="fas fa-sign-out-alt"></i> Çıkış</a> </div>
  </div>
</div>
<!-- /navbar -->
<div class="container">
<div class="row">
<div class="col-sm-3">
  <div class="my-3 sidebar">
    <ul class="widget widget-menu unstyled">
      <li class="active"><a href="index.php"><i class="fas fa-chart-line"></i> Genel Görünüm </a></li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleCat"><i class="fas fa-sitemap"></i> Kategoriler</a>
        <ul id="toggleCat" class="collapse unstyled">
          <li><a href="categories.php"><i class="fas fa-angle-double-right"></i> Tüm Kategoriler</a></li>
          <li><a href="add-category.php"><i class="fas fa-angle-double-right"></i> Kategori Ekle</a></li>
          <li><a href="deleted-categories.php"><i class="fas fa-angle-double-right"></i> Silinmiş Kategoriler</a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleProducts"><i class="fas fa-th-list"></i> Ürünler </a>
        <ul id="toggleProducts" class="collapse unstyled">
          <li><a href="products.php"><i class="fas fa-angle-double-right"></i> Tüm Ürünler</a></li>
          <li><a href="add-product.php"><i class="fas fa-angle-double-right"></i> Ürün Ekle</a></li>
          <li><a href="best-selling-products.php"><i class="fas fa-angle-double-right"></i> Çok Satanlar </a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleCustomers"><i class="fas fa-user"></i> Kullanıcılar</a>
        <ul id="toggleCustomers" class="collapse unstyled">
          <li><a href="users.php"><i class="fas fa-angle-double-right"></i> Tüm Kullanıcılar</a></li>
          <li><a href="banned-users.php"><i class="fas fa-angle-double-right"></i> Banlı Kullanıcılar </a></li>
          <li><a href="top-buyers.php"><i class="fas fa-angle-double-right"></i> Çok Alanlar</a></li>
          <li><a href="send-mail.php"><i class="fas fa-angle-double-right"></i> Toplu Email</a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleCoupons"><i class="fas fa-ticket-alt"></i> Kuponlar</a>
        <ul id="toggleCoupons" class="collapse unstyled">
          <li><a href="coupons.php"><i class="fas fa-angle-double-right"></i> Tüm Kuponlar</a></li>
          <li><a href="add-coupon.php"><i class="fas fa-angle-double-right"></i> Kupon Ekle</a></li>
          <li><a href="deleted-coupons.php"><i class="fas fa-angle-double-right"></i> Silinmiş Kuponlar</a></li>
        </ul>
      </li>
      <li><a href="transactions.php"><i class="fas fa-money-bill-alt"></i> Finansal İşlemler</a></li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleCus"><i class="fas fa-file-alt"></i> Sayfalar</a>
        <ul id="toggleCus" class="collapse unstyled">
          <li><a href="custom-pages.php"><i class="fas fa-angle-double-right"></i> Tüm Sayfalar</a></li>
          <li><a href="add-page.php"><i class="fas fa-angle-double-right"></i> Sayfa Ekle</a></li>
          <li><a href="deleted-pages.php"><i class="fas fa-angle-double-right"></i> Silinmiş Sayfalar</a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleNews"><i class="fas fa-newspaper"></i> Haberler</a>
        <ul id="toggleNews" class="collapse unstyled">
          <li><a href="news.php"><i class="fas fa-angle-double-right"></i> Tüm Haberler</a></li>
          <li><a href="add-news.php"><i class="fas fa-angle-double-right"></i> Haber Ekle</a></li>
          <li><a href="deleted-news.php"><i class="fas fa-angle-double-right"></i> Silinmiş Haberler</a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleFaq"><i class="fas fa-question"></i> SSS</a>
        <ul id="toggleFaq" class="collapse unstyled">
          <li><a href="faq.php"><i class="fas fa-angle-double-right"></i> Tüm SSS'ler</a></li>
          <li><a href="add-faq.php"><i class="fas fa-angle-double-right"></i> SSS Ekle</a></li>
          <li><a href="deleted-faq.php"><i class="fas fa-angle-double-right"></i> Silinmiş SSS'ler</a></li>
        </ul>
      </li>
      <li><a class="collapsed" data-toggle="collapse" href="#toggleBank"><i class="fas fa-university"></i> Bankalar</a>
        <ul id="toggleBank" class="collapse unstyled">
          <li><a href="bank.php"><i class="fas fa-angle-double-right"></i> Tüm Bankalar</a></li>
          <li><a href="add-bank.php"><i class="fas fa-angle-double-right"></i> Banka Ekle</a></li>
          <li><a href="deleted-bank.php"><i class="fas fa-angle-double-right"></i> Silinmiş Bankalar</a></li>
        </ul>
      </li>
	  <li><a href="settings.php"><i class="fas fa-cog"></i> Ayarlar</a></li>
      <li><a href="login.php?logout"><i class="fas fa-sign-out-alt"></i> Çıkış</a></li>
    </ul>
  </div>
  <!--/.sidebar--> 
</div>

<div class="col-sm-9">
<div class="jumbotron p-3 p-md-1 my-3 text-white rounded bg-danger box-shadow">
  <div class="col-md-12 px-0">
    <h1 class="display-4 text-white text-center"><?php echo $pageTitle;?></h1>
  </div>
</div>
<?php 
	if(isset($success)){
				echo  "<div class=\"alert alert-success block\">".$success."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div><br>";
				}
	if(isset($error)){
				echo "<div class=\"alert alert-danger block\">".$error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div><br>";
				}
				
?>
<?php } else{ ?>
<?php } ?>
