<?php 

$pageTitle = 'Silinmiş SSS ler'; 
require_once('../system/config-admin.php');
if(isset($_REQUEST['action'])){
switch ($_REQUEST['action']){
case 'restore':
$result = $faq->restore($_REQUEST['id']);
break;
}
}

// Pagination
$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;
$maxres = 20;
$num = $faq->countAllDeleted();
$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
////////////////
$faqs = $faq->getDeletedFaqs($start,$maxres);

if(!empty($faq->msg)){
	$success = $faq->msg;
	}
	if(!empty($faq->error)){
	$error = $faq->error;
	}


require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="faq.php">Tüm SSS'ler</a> </li>
        <li class="nav-item"> <a class="nav-link" href="add-faq.php">SSS Ekle</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="deleted-faq.php">Silinmiş SSS'ler</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php if($num == 0){ ?>
    <h2 align='center'>Silinmiş SSS yok</h2>
    <?php }else{ ?>
    <table class="table table-hover table-striped table-bordered">
      <thead>
        <tr>
          <th>Soru</th>
          <th>Cevap</th>
          <th>İşlemler</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($faqs as $faq) { ?>
        <tr>
          <td><?php echo $faq['title']; ?></td>
          <td><?php echo $faq['content']; ?></td>
          <td><a class="btn btn-success btn-sm" href="deleted-faq.php?action=restore&id=<?php echo $faq['id']; ?>" title="Geri Al">Geri Al</a></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
  <br>
  <ul class="pagination justify-content-center">
    <?php 
$back = (($currpage == 1)? '#':'deleted-faq.php?page='.($currpage-1));
$next = (($currpage == $pages)? 'deleted-faq.php?page='.$currpage:'faq.php?page='.($currpage+1));
?>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == 1)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Önceki" href="<?php echo $back;?>" tabindex="-1"><i class="fa fa-chevron-left" aria-hidden="true"></i></a> </li>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == $pages)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Sonraki" href="<?php echo $next;?>"><i class="fa fa-chevron-right" aria-hidden="true"></i></a> </li>
  </ul>
</div>
<?php } ?>
<?php require_once('includes/admin-footer.php');?>