<?php 

$pageTitle = 'Kategori Ekle'; 
require_once('../system/config-admin.php');

$category = $product->get_categories();

if(isset($_REQUEST['name'])){

	$name = trim($_REQUEST['name']);
$result = $product->addcat($name);

}
if(isset($_REQUEST['subname'])){

	$name = trim($_REQUEST['subname']);
	$cid = trim($_REQUEST['cat_id']);
$result = $product->addscat($name,$cid);

}
	if(!empty($product->msg)){
		$success = $product->msg;
		}
	if(!empty($product->error)){
		$error = $product->error;
		}
require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="categories.php">Tüm Kategoriler</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="add-category.php">Kategori Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="deleted-categories.php">Silinmiş Kategoriler</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <div class="bd-example bd-example-tabs">
      <nav class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="home" aria-expanded="true">Kategori Ekle</a> <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="profile" aria-expanded="false">Alt Kategori Ekle</a> </nav>
      <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab" aria-expanded="true"> <br>
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="form-horizontal">
            <div class="form-group">
              <label>Kategori Adı:</label>
              <input type="text" class="form-control" name="name" id="category" required required>
            </div>
            <button type="submit" class="btn btn-success w-100">Kategori Ekle</button>
          </form>
        </div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" aria-expanded="false"> <br>
          <form action="add-category.php" method="post" class="form-horizontal">
            <div class="form-group">
              <label>Ana Kategori:</label>
              <div class="input-group mb-3">
                <select class="custom-select" name="cat_id" id="cat_id" required="">
                  <option selected="" value="2">Ana Kategori Seçiniz...</option>
                  <?php foreach($category as $cat) {
?>
                  <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Alt Kategori Adı:</label>
              <input type="text" class="form-control" name="subname" id="subcategory" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Alt Kategori Ekle</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php require_once('includes/admin-footer.php');?>