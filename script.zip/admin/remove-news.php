<?php 

$pageTitle = 'Haber Sil'; 
require_once('../system/config-admin.php');
if(isset($_REQUEST['id'])){
	if(!empty($_REQUEST['id'])){
		$details = $newsl->details(trim(stripslashes(htmlspecialchars($_REQUEST['id']))));
	}else{
		header("location:news.php");
	}
}else{
		$details = $newsl->details('0');
	}
if(isset($_REQUEST['id']) && 'delete' == @$_REQUEST['action']){
if(!empty($_REQUEST['id'])){
	
		$result = $newsl->remove($_REQUEST['id']);
		unset($details);

			}
	
}	

if(!empty($newsl->msg)){
	$success = $newsl->msg;
	}
	if(!empty($newsl->error)){
	$error = $newsl->error;
	}
	
require_once('includes/admin-header.php');

?>
<?php if(isset($details)){ ?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item"> <a class="nav-link" href="news.php">Tüm Haberler</a> </li>
      <li class="nav-item"> <a class="nav-link" href="add-news.php">Haber Ekle</a> </li>
      <li class="nav-item"> <a class="nav-link" href="deleted-news.php">Silinmiş Haberler</a> </li>
    </ul>
  </div>
</nav>
<div class="my-3 p-3 bg-white rounded box-shadow">
    <h3>Silmek istiyor musunuz?</h3>
  <br>
  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'?id='.$details['id']);?>" method="post" class="form-horizontal">
    <div class="form-group">
      <div class="col-md-4 col-md-offset-3">
        <input class="form-control"type="hidden" name="action" value="delete">
        <button class="btn btn-danger">Sil</button>
      </div>
    </div>
  </form>
</div>
<?php } ?>
<?php require_once('includes/admin-footer.php');?>