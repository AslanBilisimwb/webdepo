<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle = 'Genel Görünüm';
require_once('../system/config-admin.php');
require_once('../system/gateways.php');
$customer = new Customer($DB_con);
$allU = $customer->countAll();
$allB = $customer->countBanned();
$allC = $coupon->countAll();
$allS = $sale->countAll();
$tmade = $transaction->AddAll();

$maxres = 5;
$num  = $transaction->countAll();

$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;

$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
$transactions = $transaction->getTransactions($start,$maxres);

$top = $customer->newUsers();

require_once('includes/admin-header.php');
?>

<div class="content">
  <div class="btn-controls">
    <div class="row my-3">
      <div class="col-xl-3 col-sm-6">
        <div class="card text-white bg-danger o-hidden h-100 box-shadow">
          <div class="card-body">
            <div class="card-body-icon"> <i class="fas fa-fw fa-shopping-basket"></i> </div>
            <div class="mr-5"><strong><?php echo $allS;?></strong><br>
              Satışlar</div>
          </div>
          <a class="card-footer text-white clearfix small z-1" href="best-selling-products.php"> <span class="float-left">Satışlara Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
      </div>
      <div class="col-xl-3 col-sm-6">
        <div class="card text-white bg-info o-hidden h-100">
          <div class="card-body">
            <div class="card-body-icon"> <i class="fas fa-fw fa-user"></i> </div>
            <div class="mr-5"><strong><?php echo $allU;?></strong><br>
              Kullanıcılar</div>
          </div>
          <a class="card-footer text-white clearfix small z-1" href="users.php"> <span class="float-left">Kullanıcılara Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
      </div>
      <div class="col-xl-3 col-sm-6">
        <div class="card text-white bg-warning o-hidden h-100">
          <div class="card-body">
            <div class="card-body-icon"> <i class="fas fa-fw fa fa-ticket-alt"></i> </div>
            <div class="mr-5"><strong><?php echo $allC;?></strong><br>
              Kuponlar</div>
          </div>
          <a class="card-footer text-white clearfix small z-1" href="coupons.php"> <span class="float-left">Kuponlara Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
      </div>
      <div class="col-xl-3 col-sm-6">
        <div class="card text-white bg-success o-hidden h-100">
          <div class="card-body">
            <div class="card-body-icon"> <i class="far fa-fw fa-money-bill-alt"></i> </div>
            <div class="mr-5 text-white"><b><?php echo $setting['currency_sym'], money_format("%.2n", $tmade);?></b><br>
              KK Geliri </div>
          </div>
          <a class="card-footer text-white clearfix small z-1" href="transactions.php"> <span class="float-left">Finansal İşlemlere Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
      </div>
    </div>
    
    <!--/#btn-controls-->
    <div class="module box-shadow">
      <div class="module-head">
        <h3> Son Finansal İşlemler</h3>
      </div>
      <div class="module-body">
        <div class="table-responsive">
          <table class="table table-striped table-hover table-bordered">
            <thead>
              <tr>
                <th scope="col">İşlem&nbsp;ID</th>
                <th scope="col">Tarih</th>
                <!--<th scope="col">Type</th>-->
                <th>Kullanıcı&nbsp;ID</th>
                <th scope="col">Detaylar</th>
                <th scope="col">Tutar</th>
                <th scope="col">Durum</th>
              </tr>
            </thead>
            <tbody>
<?php
foreach($transactions as $trans){
if($trans['product']!='0'){
$prod = $product->details($trans['product']);
$prod = $prod['name'];
}else{
$prod = 'Bakiye Yükleme';
}
if($trans['type']=='3'){
$prod = 'Manuel işlem';
}
?>
              <tr>
                <td><?php echo $trans['id'];?></td>
                <td><?php echo $trans['date'];?></td>
                <td><?php echo $trans['user_id'];?></td>
                <td><?php echo $prod;?></td>
                <td><?php echo $setting['currency_sym'] ." ". $trans['amount'];?></td>
                <td><?php echo ($trans['callback']=='1'?'<span data-toggle="tooltip" data-placement="top" title="Tamamlandı" class="badge badge-success"><i class="fas fa-check" aria-hidden="true"></i></span>':'<span data-toggle="tooltip" data-placement="top" title="Hata" class="badge badge-danger"><i class="fas fa-times" aria-hidden="true"></i></span>');?></td>
              </tr>
              <?php
}
?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!--/.module-->
    <div class="module hide">
      <div class="module-head">
        <h3> Son Kaydolan Kullanıcılar</h3>
      </div>
      <div class="module-body">
        <div class="table-responsive">
          <table class="table table-hover table-striped table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Email</th>
                <th class="hidden-phone">Alımlar</th>
                <th class="hidden-phone">Bakiye</th>
                <th>İşlemler</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($top as $topUser){?>
              <tr>
                <td><?php echo $topUser['id'];?></td>
                <td><?php echo $topUser['email'];?></td>
                <td class="hidden-phone"><?php echo $topUser['purchases'];?></td>
                <td class="hidden-phone"><?php echo $setting['currency_sym'] ." ".$topUser['balance'];?></td>
                <td><div class="btn-group btn-group-sm" role="group" aria-label="AActions"> <a href="user-purchases.php?id=<?php echo $topUser['id'];?>" class="btn btn-warning" title="Alımlar" data-toggle="tooltip"><i class="fas fa-shopping-basket"></i></a> <a href="add-funds.php?id=<?php echo $topUser['id'];?>" class="btn btn-success" title="Bakiye Yükle" data-toggle="tooltip"><i class="fas fa-plus"></i></a> <a href="ban-user.php?id=<?php echo $topUser['id'];?>" class="btn btn-danger" title="Kullanıcıyı Banla" data-toggle="tooltip"><i class="fas fa-minus-circle"></i></a> </div></td>
              </tr>
              <?php }?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <!--/.content--> 
</div>
<?php require_once('includes/admin-footer.php');?>