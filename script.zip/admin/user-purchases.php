<?php 

$pageTitle = "Alımlar";
require_once('../system/config-admin.php');
$customer = new Customer($DB_con);
if(isset($_REQUEST['id'])){
$customerDetails = $customer->details($_REQUEST['id']);
$error = ($customer->error?$customer->error:false);
$userPurchases =$sale->all('user_id',$crypt->decrypt($_REQUEST['id'],'USER'));
$userCount = count($userPurchases);

}else{
require_once('includes/admin-header.php');
echo 'Geçersiz istek';
require_once('includes/admin-footer.php');
exit;
}
if(empty($error)){
unset($error);
}
require_once('includes/admin-header.php');
?>

<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
  <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
    <ul class="navbar-nav">
      <li class="nav-item"> <a class="nav-link" href="users.php">Tüm Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="new-users.php">Yeni Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="banned-users.php">Banlı Kullanıcılar</a> </li>
      <li class="nav-item"> <a class="nav-link" href="top-buyers.php">Çok Alanlar</a> </li>
    </ul>
  </div>
</nav>
<div class="my-3 p-3 bg-white rounded box-shadow">
<div class="row">
<div class="col-md-12">
<?php if($userCount > 0){ ?>
<table class="table table-striped table-hover table-bordered">
<thead>
  <tr>
    <th>Tarih</th>
    <th>Ürün</th>
    <th>İndirme?</th>
    <th>Alım.ID</th>
    <th>İşlem.ID</th>
  </tr>
</thead>
<tbody>
  <?php foreach($userPurchases as $userPurchase){
$productName = $product->details($userPurchase['pro_id']);
$productName = $productName['name'];
?>
  <tr>
    <td><?php echo $userPurchase['date'];?></td>
    <td><?php echo $productName . " (".$userPurchase['pro_id'].")";?></td>
    <td><?php echo ($userPurchase['downloaded']=='1'?'<span class="badge badge-success">Evet</span>':'<span class="badge badge-danger">Hayır</span>');?></td>
    <td><?php echo $userPurchase['id'];?></td>
    <td><?php echo $crypt->encrypt($userPurchase['transaction_id'],'TRANSACTION');?></td>
  </tr>
  <?php 
}
echo "</tbody></table></div></div></div>";
}else{
 echo  "<div class='alert alert-danger'>Henüz alım yok</div>";
}
?>
</div>
</div>
<?php require_once('includes/admin-footer.php');?>
