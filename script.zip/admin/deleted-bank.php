<?php 

$pageTitle = 'Silinmiş Bankalar'; 
require_once('../system/config-admin.php');
if(isset($_REQUEST['action'])){
switch ($_REQUEST['action']){
case 'restore':
$result = $bank->restore($_REQUEST['id']);
break;
}
}

// Pagination
$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;
$maxres = 10;
$num = $bank->countAllDeleted();
$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
////////////////
$banks = $bank->getDeletedbanks($start,$maxres);

if(!empty($bank->msg)){
	$success = $bank->msg;
	}
	if(!empty($bank->error)){
	$error = $bank->error;
	}


require_once('includes/admin-header.php');

?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="bank.php">Tüm Bankalar</a> </li>
        <li class="nav-item"> <a class="nav-link" href="add-bank.php">Banka Ekle</a> </li>
        <li class="nav-item active"> <a class="nav-link" href="deleted-bank.php">Silinmiş Bankalar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php if($num == 0){ ?>
    <h2 align='center'>Silinmiş Banka yok</h2>
    <?php }else{ ?>
    <table class="table table-hover table-striped table-bordered">
      <thead>
        <tr>
          <th>Banka Adı</th>
          <th>Hesap/IBAN bigileri</th>
          <th>İşlemler</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($banks as $bank) { ?>
        <tr>
          <td><?php echo $bank['title']; ?></td>
          <td><?php echo $bank['content']; ?></td>
          <td><a class="btn btn-success btn-sm" href="deleted-bank.php?action=restore&id=<?php echo $bank['id']; ?>" title="Geri Al">Geri Al</a></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
  <br>
  <ul class="pagination justify-content-center">
    <?php 
$back = (($currpage == 1)? '#':'deleted-bank.php?page='.($currpage-1));
$next = (($currpage == $pages)? 'deleted-bank.php?page='.$currpage:'bank.php?page='.($currpage+1));
?>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == 1)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Önceki" href="<?php echo $back;?>" tabindex="-1"><i class="fa fa-chevron-left" aria-hidden="true"></i></a> </li>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == $pages)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Sonraki" href="<?php echo $next;?>"><i class="fa fa-chevron-right" aria-hidden="true"></i></a> </li>
  </ul>
</div>
<?php } ?>
<?php require_once('includes/admin-footer.php');?>