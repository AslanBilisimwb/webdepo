<?php 

$pageTitle = "Edit User Profile";
require_once('../system/config-admin.php');

if(isset($_REQUEST['id'])){
$customer = new Customer($DB_con);
$customerDetails = $customer->userdetails($_REQUEST['id']);
$error = ($customer->error?$customer->error:false);



if(empty($error)){
unset($error);
}


}else{
require_once('includes/admin-header.php');
echo 'Geçersiz istek';
require_once('includes/admin-footer.php');
exit;
}

require_once('includes/admin-header.php');
?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="users.php">Tüm Kullanıcılar</a> </li>
        <li class="nav-item"> <a class="nav-link" href="new-users.php">Yeni Kullanıcılar</a> </li>
        <li class="nav-item"> <a class="nav-link" href="banned-users.php">Banlı Kullanıcılar</a> </li>
        <li class="nav-item"> <a class="nav-link" href="top-buyers.php">Çok Alanlar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <form id="upload" class="form-horizontal">
      <div class="form-group">
        <label>Adı:</label>
        <input class="form-control" value="<?php echo $customerDetails['fname'];?>" name="fname" id="coupon-code" type="text" minlength="5">
      </div>
      <div class="form-group">
        <label>Email:</label>
        <input class="form-control" value="<?php echo $customerDetails['email'];?>" name="email" id="coupon-code" type="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Geçersiz email adresi!">
      </div>
      <hr>
      <div class="form-check">
        <input type="checkbox" name="allow_email" <?php if ($customerDetails['allow_email'] == 1) {echo 'checked="checked"';} ?> id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Allow Newsletter?</label>
      </div>
      <div class="form-check">
        <input type="checkbox" name="password_recover" <?php if ($customerDetails['password_recover'] == 1) {echo 'checked="checked"';} ?> id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Bir sonraki girişte şifre değiştirsin?</label>
      </div>
      <div class="form-check">
        <input type="checkbox" name="moderator" <?php if ($customerDetails['moderator'] == 1) {echo 'checked="checked"';} ?> id="exampleCheck1">
        <label class="form-check-label" for="exampleCheck1">Moderatör? (Yorum silme ve soru yanıtlama yetkisi)</label>
      </div>
      <hr>
      <input class="form-control" type="hidden" name="id" value="<?php echo $customerDetails['username'];?>">
      <button type="submit" id="btn" class="btn btn-success w-100">Update</button>
      <div id="res"></div>
    </form>
  </div>
  <script type="text/javascript">
  $("#upload").on("submit",(function(e) {
      
      tinyMCE.triggerSave();
      
    e.preventDefault();
    $.ajax({
          url: "ajax-user.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,
      beforeSend: function() 
        {
            $("#res").html('Yükleniyor, bekleyin...!');
        },  
        success: function(response)
        {
            $("#res").html(response);
        }        
     });
  }));
</script>
<?php require_once('includes/admin-footer.php');?>