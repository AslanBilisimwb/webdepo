<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$pageTitle ='Admin Hesabı';
$pg ='6';
require_once('../system/config-admin.php');

//rewrite in next update
if(isset($_REQUEST['account'])){
if($_REQUEST['account'] == 'cpassword'){

$pwd = md5($_POST['edit_pwd']);
$npwd = $_POST['edit_new_pwd'];
$npwd2 = $_POST['edit_new_pwd2'];
if(!empty($npwd)){
$details = $auth->details($_SESSION['uid']);
if(md5($pwd) == $details['password']){
if($npwd == $npwd2){
$npwd = md5($npwd);
$result= $auth->update($_SESSION['uid'],'password',$npwd);
$auth->msg ="Şifre değiştirildi";
}else{
$auth->error  = 'Yeni şifreler uyuşmuyor.';
}
}else{

$auth->error  = 'Eski şifre hatalı.';

}
}
else{
$auth->error  = 'All fields are required!';
}

}
elseif($_REQUEST['account'] == 'profile'){

$fname = $_POST['fname'];
$email = $_POST['email'];
if(!empty($fname) || empty($email)){
$details = $auth->details($_SESSION['uid']);
$result = $auth->update($_SESSION['uid'],'email',$email);
$result = $auth->update($_SESSION['uid'],'fname',$fname);
$auth->msg = "Hesap güncellendi!";
}else{
$auth->error  = 'Tüm alanlar gerekli!';
}

}
}



require_once('includes/admin-header.php');
?>
<?php
if($auth->msg){
				echo  "<div class=\"alert alert-success mb-0 mt-3 block\">".$auth->msg."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				if($auth->error){
				echo "<div class=\"alert alert-danger mb-0 mt-3 block\">".$auth->error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				?>

<div class="row">
  <div class="col-12 pl-0">
    <div id="accordion" class="accordion">
      <div class="my-3 p-3 bg-white rounded box-shadow">
        <div class="card m-b-0">
          <div class="card-header mpointer collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <a class="card-title"> Hesabım </a> </div>
          <div id="collapseOne" class="card-block collapse">
            <div class="card-body">
              <form action="account.php" method="post" id="edit-admin">
                <input class="form-control" type="hidden" name="account" value="profile">
                <div class="input-group mb-3">
                  <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope" aria-hidden="true"></i></span> </div>
                  <input type="text" class="form-control" name="email" value="<?php echo $userDetails['email'];?>" placeholder="Enter Email" title="Email Adresi" data-toggle="tooltip" aria-label="Email Giriniz" aria-describedby="basic-addon1" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Geçersiz email adresi!" required>
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="far fa-address-card" aria-hidden="true"></i></span> </div>
                  <input type="text" class="form-control" name="fname" value="<?php echo $userDetails['fname'];?>" placeholder="Enter Name" title="İsim" data-toggle="tooltip" aria-label="İsim Giriniz" aria-describedby="basic-addon1"  required>
                </div>
                <div class="clearfix">
                  <button type="submit" name="submit" class="btn btn-primary float-right" title="Hesabı güncelle">Değişiklikleri kaydet</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="my-3 p-3 bg-white rounded box-shadow">
        <div class="card m-b-0">
          <div class="card-header mpointer collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"> <a class="card-title"> Şifre Değiştir </a> </div>
          <div id="collapseTwo" class="card-block collapse">
            <div class="card-body">
              <form action="account.php" method="post" id="edit-admin">
                <input class="form-control" type="hidden" name="account" value="cpassword">
                <div class="input-group mb-3">
                  <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                  <input type="password" class="form-control" name="edit_pwd" placeholder="Eski şifre" aria-label="Yeni şifre" aria-describedby="basic-addon1">
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                  <input type="password" class="form-control" name="edit_new_pwd" placeholder="Yeni şifre" aria-label="Yeni şifre" aria-describedby="basic-addon1">
                </div>
                <div class="input-group mb-3">
                  <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                  <input type="password" class="form-control" name="edit_new_pwd2" placeholder="Yeni şifre tekrar" aria-label="Yeni şifre tekrar" aria-describedby="basic-addon1">
                </div>
                <div class="clearfix">
                  <button type="submit" name="submit" class="btn btn-primary float-right" title="Şifre değiştir">Şİfreyi Kaydet</button>
                </div>
              </form>
            </div
 >
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php require_once('includes/admin-footer.php');?>