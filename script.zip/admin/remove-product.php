<?php 

$pageTitle = "Ürün Sil";
require_once('../system/config-admin.php');
if(isset($_REQUEST['id'])){
$productDetails = $product->details($_REQUEST['id']);
$error = ($product->error?$product->error:false);

if(isset($_GET['action']) && $_GET['action'] == 'remove'){

if(!$error){
$product->remove($_REQUEST['id']);
$error = ($product->error?$product->error:false);
$success =($product->msg?$product->msg:false);
}
if(isset($_REQUEST['ajax'])){
echo (@$error ? $error:'success');
exit;
}

}

if(empty($error)){
unset($error);
}

}else{
require_once('includes/admin-header.php');
echo 'Geçersiz istek';
require_once('includes/admin-footer.php');
exit;
}
require_once('includes/admin-header.php');
?>

<div class="content">
  <nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="products.php">Tüm Ürünler</a> </li>
        <li class="nav-item"> <a class="nav-link" href="add-product.php">Ürün Ekle</a> </li>
        <li class="nav-item"> <a class="nav-link" href="best-selling-products.php">Çok Satanlar</a> </li>
      </ul>
    </div>
  </nav>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php if(!isset($error) || !isset($success)){?>
    <form class="form-horizontal" id="productRemove" method="POST" action="remove-product.php?action=remove">
      <input class="form-control" type="hidden" name="id" value="<?php echo $productDetails['id']; ?>">
    <h3>Silmek istiyor musunuz?</h3>
      <div class="form-actions">
        <button type="submit" class="btn btn-danger">Sil</button>
      </div>
    </form>
    <?php } ?>
    <?php require_once('includes/admin-footer.php');?>