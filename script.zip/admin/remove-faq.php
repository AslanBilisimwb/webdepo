<?php 

$pageTitle = 'SSS Sil';
require_once('../system/config-admin.php');
if(isset($_REQUEST['id'])){
	if(!empty($_REQUEST['id'])){
		$details = $faq->details(trim($_REQUEST['id']));
	}else{
		header("location:faq.php");
	}
}else{
		$details = $faq->details('0');
	}
if(isset($_REQUEST['id']) && 'delete' == @$_REQUEST['action']){
if(!empty($_REQUEST['id'])){
	
		$result = $faq->remove($_REQUEST['id']);
		unset($details);

			}
	
}	

if(!empty($faq->msg)){
	$success = $faq->msg;
	}
	if(!empty($faq->error)){
	$error = $faq->error;
	}
	
require_once('includes/admin-header.php');

?>

<?php if(isset($details)){ ?>
	
	<nav class="navbar navbar-expand-lg navbar-dark text-white rounded bg-danger box-shadow">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="faq.php">Tüm SSS'ler</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="add-faq.php">SSS Ekle</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="deleted-faq.php">Silinmiş SSS'ler</a>
          </li>
        </ul>
      </div>
    </nav>
	
	    <div class="my-3 p-3 bg-white rounded box-shadow">
    <h3>Silmek istiyor musunuz?</h3>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"].'?id='.$details['id']);?>" method="post" class="form-horizontal">

<div class="form-group"><div class="col-md-4 col-md-offset-3">
<input class="form-control"type="hidden" name="action" value="delete">
<button class="btn btn-danger">Sil</button></div></div>
</form>
</div>
<?php } ?>
<?php require_once('includes/admin-footer.php');?>