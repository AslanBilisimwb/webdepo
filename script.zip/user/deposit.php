<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Bakiye Yükle';
$pg ='3';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
?>

<div class="row">
  <div class="col-sm-4">
    <div class="my-1 p-3 bg-white rounded box-shadow">
      <?php include'includes/sidenav.php';?>
    </div>
  </div>
  <div class="col-sm-8">
    <div class="alert alert-primary">Yüklenen bakiyelerin iadesi yada geri çekimi <b>YOKTUR</b>!
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <div class="my-1 p-3 bg-white rounded box-shadow"> <a href="shopier.php" class="btn btn-success btn-block" role="button">Shopier ile Yükle</a> * <small>Otomatik olarak anında yüklenir</small></div>
      </div>
      <div class="col-sm-6">
        <div class="my-1 p-3 bg-white rounded box-shadow"> <a href="bank.php" class="btn btn-success btn-block" role="button">Banka Havalesi/EFT ile Yükle</a> * <small>Havele bize ulaştığında yüklenir</small></div>
      </div>
    </div>
  </div>
</div>
<?php require_once('includes/user-footer.php'); ?>
