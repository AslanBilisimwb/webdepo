<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='SSS - Sıkça Sorulan Sorular';
$pg ='8';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
$faqs = $faq->get_all_faqs();
//$faqs1 = $faqsl->get_important_faqs();
?>

<div class="row">
<div class="col-sm-4">
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php include'includes/sidenav.php';?>
  </div>
</div>
<div class="col-sm-8">
<?php foreach($faqs as $faq){?>
<div id="accordion" class="accordion">
<div class="my-3 p-3 bg-info rounded box-shadow">
  <div class="card m-b-0">
    <div class="card-header mpointer collapsed" data-toggle="collapse" data-parent="#accordion" href="#<?php echo $faq['id']?>"> <a class="card-title"> <?php echo $faq['title']?> </a> </div>
    <div id="<?php echo $faq['id']?>" class="card-block collapse">
      <div class="card-body"> <?php echo $faq['content']?> </div>
    </div>
  </div>
</div>
<?php } ?>
<?php require_once('includes/user-footer.php');?>
