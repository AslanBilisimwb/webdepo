<!doctype html>
<html lang="tr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="../system/assets/js/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/bootstrap.min.css">
<script src="../system/assets/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/all.css">
<script defer src="../system/assets/js/all.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/styles.css">
<title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
<script>
$( document ).ready(function() {
$('.js-open').on('click', function() {
  var target = $(this).attr('data-target'); 
  $(target).toggleClass('is-visible');  
});

$('.js-close').on('click', function() {
  $(this).parent().removeClass('is-visible');
});

    $('[data-toggle="tooltip"]').tooltip();

});
</script>
</head>
<body>
<header class="box-shadow1 fixed-top">
  <nav class="navbar p-0 navbar-expand-lg navbar-dark bg-dark1">
    <div class="container"> <a class="navbar-brand nav-m mr-5" href="<?php echo $setting['website_url'];?>">
      <?php if(empty($setting['site_logo'])){ ?>
      <?php echo $setting['site_name'];?>
      <?php } else{?>
      <img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="35">
      <?php } ?>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent1">
        <?php if($user->is_loggedin()){ ?>
        <ul class="navbar-nav darkernavhover mr-auto">
          <li class="nav-item"> <a class="nav-link" href="../free">Ücretsiz Ürünler</a> </li>
          <li class="nav-item"> <a class="nav-link" href="faq.php">SSS</a> </li>
          <li class="nav-item"> <a class="nav-link" href="news.php">Haberler</a> </li>
          <li class="nav-item"> <a class="nav-link" href="contact.php">İletişim</a> </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Merhaba, <?php echo $userDetails['fname'];?> <span class="badge badge-warning"><?php echo $setting['currency_sym'] .  $userDetails['balance'];?></span> </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="index.php"><i class="far fa-address-card"></i> Genel Görünüm</a> <a class="dropdown-item" href="downloads.php"><i class="fas fa-cloud-download-alt"></i> Aldıklarım</a> <a href="news.php" class="dropdown-item"><i class="far fa-newspaper"></i> News</a> <a class="dropdown-item" href="login.php?logout"><i class="fas fa-sign-out-alt"></i> Çıkış</a> </div>
          </li>
        </ul>
        <?php } else{ ?>
        <a href="login.php" class="btn btn-outline-warning mr-2 btn-sm">Login</a> <a href="register.php" class="btn btn-outline-warning btn-sm">Sign Up</a>
        <?php } ?>
      </div>
    </div>
  </nav>
  <?php if($user->is_loggedin()){ ?>
  <div class="nav-scroller bg-white box-shadow justify-content-md-center">
    <nav class="nav nav-underline justify-content-md-center"> 
    <a class="nav-link <?php echo $pg == '1' ? 'active':NULL ?>" href="index.php">Genel Görünüm</a> <a class="nav-link <?php echo $pg == '2' ? 'active':NULL ?>" href="downloads.php">Aldıklarım</a> 
    <a class="nav-link <?php echo $pg == '3' ? 'active':NULL ?>" href="deposit.php">Bakiye Yükle</a> 
    <a class="nav-link <?php echo $pg == '4' ? 'active':NULL ?>" href="transactions.php">Finansal Durum</a> 
    <a class="nav-link <?php echo $pg == '5' ? 'active':NULL ?>" href="wishlist.php">Beğendiklerim <span class="badge badge-danger align-text-bottom"><?php echo $wishcount;?></span></a> 
    <a class="nav-link <?php echo $pg == '6' ? 'active':NULL ?>" href="account.php">Hesabım</a> 
    <a class="nav-link <?php echo $pg == '7' ? 'active':NULL ?>"href="news.php">Haberler</a> 
    <a class="nav-link <?php echo $pg == '8' ? 'active':NULL ?>"href="faq.php">SSS</a> <a class="nav-link <?php echo $pg == '9' ? 'active':NULL ?>"href="contact.php">İletişim</a> </nav>
  </div>
  <?php } ?>
</header>
<div class="container mt-5 p-3">
  <div class="jumbotron p-0 p-md-2 mt-5 mb-0 text-white rounded bg-info box-shadow">
    <div class="col-md-12 px-0">
      <h1 class="display-4 text-center"><?php echo $pageTitle;?></h1>
    </div>
  </div>
</div>
<main role="main" class="container">
