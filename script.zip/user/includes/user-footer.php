</main>
<script src="../system/assets/tinymce/tinymce.min.js"></script>
</body>
</html>