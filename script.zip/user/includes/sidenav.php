<aside class="user-info-wrapper">
  <div class="user-cover" style="background-image: url();"> <a href="account.php" class="info-label"><i class="icon-medal"></i>Profili Güncelle</a> </div>
  <div class="user-info">
    <div class="user-avatar"><a href="<?php echo '/profile/'.$userDetails['username']; ?>/"><img src="<?php echo $userDetails['profile']?>" alt="User"></a></div>
    <div class="user-data">
      <h6 class="mb-1">Merhaba, <?php echo $userDetails['fname'];?></h6>
      <span class="">Katılım: <strong>
      <?php $modified = $userDetails['created']; $date = new DateTime($modified ); echo $date->format('d/m/Y');?>
      </strong></span> </div>
  </div>
</aside>
<div class="list-group sidenav_radius"> 
<a href="index.php" class="list-group-item list-group-item-action <?php echo $pg == '1' ? 'active':NULL ?>"><i class="fas fa-address-card"></i> Genel Görünüm</a> 
<a href="downloads.php" class="list-group-item list-group-item-action <?php echo $pg == '2' ? 'active':NULL ?>"><i class="fas fa-cloud-download-alt"></i> Aldıklarım</a> 
<a href="deposit.php" class="list-group-item list-group-item-action <?php echo $pg == '3' ? 'active':NULL ?>"><i class="fas fa-shopping-basket"></i> Bakiye Yükle</a> 
<a href="transactions.php" class="list-group-item list-group-item-action <?php echo $pg == '4' ? 'active':NULL ?>"><i class="fas fa-money-bill-alt"></i> Finansal İşlemler</a> 
<a href="wishlist.php" class="list-group-item list-group-item-action  <?php echo $pg == '5' ? 'active':NULL ?>"><i class="fas fa-heart"></i> Beğendiklerim <span class="badge badge-danger fright"><?php echo $wishcount;?></span></a> <a href="account.php" class="list-group-item list-group-item-action <?php echo $pg == '6' ? 'active':NULL ?>"><i class="fas fa-user"></i> Hesabım</a> <a href="news.php" class="list-group-item list-group-item-action <?php echo $pg == '7' ? 'active':NULL ?>"><i class="fas fa-newspaper"></i> Haberler</a> 
<a href="faq.php" class="list-group-item list-group-item-action <?php echo $pg == '8' ? 'active':NULL ?>"><i class="fas fa-question"></i> SSS</a> 
<a href="contact.php" class="list-group-item list-group-item-action <?php echo $pg == '9' ? 'active':NULL ?>"><i class="fas fa-envelope"></i> İletişim</a> </div>
