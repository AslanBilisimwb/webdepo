<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Yeni Kayıt';
require_once('../system/config-user.php');
require_once('../system/recaptchalib.php');
$error = false;
if(isset($_REQUEST['error'])){
$user->error = $_REQUEST['error'];
}

if($_POST && isset($_REQUEST['signup'])){

$fname = clean($_POST['new_fname']);
$lname = clean($_POST['new_lname']);
$username = clean($_POST['new_username']);
$email = clean($_POST['new_email']);
$gsm = clean($_POST['new_gsm']);
$address = clean($_POST['new_address']);
$city = clean($_POST['new_city']);
$postcode = clean($_POST['new_postcode']);
$npwd = clean($_POST['new_pwd']);
$npwd2 = clean($_POST['new_pwd2']);
if ($setting['re_sitekey'] !=''){ 
$secret = $setting['re_securekey'];
$ip = $_SERVER['REMOTE_ADDR'];
//verify if user has filled the captcha correctly

if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){ 
$response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$_POST['g-recaptcha-response']."&remoteip=".$ip);
	$responseData = json_decode($response);

		if($responseData->success){
		//reCaptcha API has validated the user as a human being.
		}else{
		// show error message if response from the reCaptcha server is not ‘Success’
echo '<h2 align="center">SPAM??? Tekrar Deneyin.</h2>';
exit;		
}

}else{
//show error message if user has not clicked on reCaptcha box
echo '<h2 align="center">Robot olmadığınızı bilmek istiyoruz. <br>Geri gidin ve güvenlik aşamasını tamamlayın.</h2>';
exit;		
}	
}else{}
	
	
if(!$validate->email($email)){
$user->error  = 'Geçerli bir email adresi girin!';
        }else{ 
if($user->is_new_user($email,$username)){
if($npwd == $npwd2 && !$error){
$result= $user->add($fname,$lname,$username,$email,$gsm,$address,$city,$postcode,$npwd);
if($result == true){
				$result = $user->login($email,$npwd);
				if(!isset($_REQUEST['ajax'])){
	echo("<script> top.location.href='index.php'</script>");
	}
				
				}
}else{
$user->error  = 'Şifreler uyuşmuyor!';
}
}else{

$user->error  = 'Kullanıcı zaten mevcut.';

}
}
	if(isset($_REQUEST['ajax'])){
	echo ($user->error?$user->error:"success");
	exit;
	}
} ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<script src="../system/assets/js/jquery.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<link href="../system/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../system/assets/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/my-login.css">
<link rel="stylesheet" type="text/css" href="../system/assets/css/all.css">
<script defer src="../system/assets/js/all.js"></script>

<title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
</head>
<body class="my-login-page">
<section class="">
  <div class="container h-100">
    <div class="row justify-content-md-center align-items-center h-100">
      <div class="card-wrapper mt-5">
        <div class="card fat">
          <div align="center"> <img src="<?php echo$setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" width="300"> </div>
          <div class="card-body">
            <h4 class="card-title text-center">Yeni Kayıt</h4>
            <form action"<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
              <?php 

if($user->msg){
				echo  "<div class=\"alert alert-success block\">".$user->msg."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
if($user->error){
				echo  "<div class=\"alert alert-danger block\">".$user->error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}?>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-user-circle" aria-hidden="true"></i></span> </div>
                <input id="fname" class="form-control" name="new_fname" required autofocus type="text" minlength="2" placeholder="İsim">
              </div></div></div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-user-circle" aria-hidden="true"></i></span> </div>
                <input id="lname" class="form-control" name="new_lname" required type="text" minlength="2" placeholder="Soyisim">
              </div></div></div></div>
              <div class="input-group mb-0">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-user-circle" aria-hidden="true"></i></span> </div>
                <input id="uname" class="form-control" name="new_username" required type="text" minlength="5" maxlength="15" pattern="[a-z0-9]{5,15}" title="5-15 karakter arası sadece küçük harf ve rakam. Türkçe karakter kullanmayınız." placeholder="Kullanıcı Adı">
              </div>
          		<small id="emailHelp" class="form-text text-muted mb-2">Kullanıcı adı: Küçük harf ve rakamla. Türkçe karakter geçersiz!</small>
              <div class="input-group mb-3">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-at" aria-hidden="true"></i></span> </div>
                <input id="email" class="form-control" name="new_email" required type="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Geçersiz email adresi!" placeholder="Email">
              </div>
              <div class="input-group mb-3">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-mobile-alt" aria-hidden="true"></i></span> </div>
                <input id="gsm" class="form-control" name="new_gsm" required type="text" minlength="10" maxlength="11" pattern="[0-9]{10,11}" title="Sadece rakam kullanınız." placeholder="GSM no">
              </div>
              <div class="input-group mb-3">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="far fa-address-card" aria-hidden="true"></i></span> </div>
                <input id="address" class="form-control" name="new_address" required type="text" minlength="10" maxlength="99" placeholder="Adres">
              </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt" aria-hidden="true"></i></span> </div>
                <input id="city" class="form-control" name="new_city" required type="text" minlength="3" maxlength="20"  minlength="10" maxlength="11" pattern="[a-zA-Z]{3,20}" title="Sadece harf kullanınız." placeholder="Şehir">
              </div></div></div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope" aria-hidden="true"></i></span> </div>
                <input id="postcode" class="form-control" name="new_postcode" required type="text" minlength="5" maxlength="6" pattern="[0-9]{5,6}" title="Sadece rakam kullanınız." placeholder="Posta Kodu">
              </div></div></div></div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                <input id="password" type="password" class="form-control" name="new_pwd" minlength="6" maxlength="15" pattern=".{6,15}" required title="Min. 6 Max. 15 karakter!" placeholder="Şifre">
              </div></div></div>
          <div class="col-md-6">
            <div class="form-group">
              <div class="input-group">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                <input id="password" type="password" class="form-control" name="new_pwd2" minlength="6" maxlength="15" pattern=".{6,15}" required title="Min. 6 Max. 15 karakter!" placeholder="Şifre Tekrar">
              </div></div></div></div>				
              <div class="form-group">
                <label>
                  <input name="aggree" value="1" type="checkbox" required>
                  Kullanım koşullarını kabul ediyorum </label>
              </div>
              <input class="form-control" type="hidden" name="signup" value="true">
              <?php if ($setting['re_sitekey'] !=''){ ?>
              <div class="g-recaptcha" data-sitekey="<?php echo $setting['re_sitekey']; ?>"></div>
              <?php }else{} ?>
              <div class="form-group mt-1">
                <button type="submit" name="submit" class="btn btn-success"> Kayıt Ol </button>
              </div>
              <div class="margin-top20 ml-3"> Zaten hesabınız var mı? <a href="login.php">Giriş Yap</a> </div>
            </form>
          </div>
        </div>
        <div class="footer"> Copyright &copy; <?php echo $setting['site_name']; ?> </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>