<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Buy Credits';
$pg ='3';
require_once('../system/config-user.php');
require_once('../system/gateways.php');
$msg = false;
$error = false;
$crf = md5("TSM" . date('YMD'));
if(isset($_POST) && isset($_POST['crf'])){
$error = ($_POST['crf'] != $crf ? 'Invalid CRF':false);
$error = (empty($_POST['amount'])? 'Please select amount':$error);
$error = (empty($_POST['gateway'])? 'Please select payment method':$error);

if(!$error){

$_SESSION['payment']['crf'] = $crf;
$_SESSION['payment']['amount'] = $_POST['amount'];
$_SESSION['payment']['gateway'] = $_POST['gateway'];
$_SESSION['payment']['detail'] = "Funds Deposit";
$_SESSION['payment']['redir'] = "transactions.php";
$_SESSION['payment']['action'] = "deposit";


if(!isset($_REQUEST['ajax'])){
header('location:process.php?action=process');
exit;
}
}
if(isset($_REQUEST['ajax'])){
echo ($error ? $error:'success');
exit;
}
}
require_once('includes/user-header.php');
?>

<div class="row">
  <div class="col-sm-4">
    <div class="my-1 p-3 bg-white rounded box-shadow">
      <?php include'includes/sidenav.php';?>
    </div>
  </div>
  <div class="col-sm-8">
    <div class="my-1 p-3 bg-white rounded box-shadow">
    <form class="form-horizontal amount" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" id="deposit-funds">
        <div class="card-deck text-center">
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym'];?> <?php echo $setting['value1']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value1']?>" id="<?php echo $setting['value1']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value1']?>">Seçiniz</label>
            </div>
          </div>
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym']?> <?php echo $setting['value2']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value2']?>" id="<?php echo $setting['value2']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value2']?>">Seçiniz</label>
            </div>
          </div>
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym']?> <?php echo $setting['value3']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value3']?>" id="<?php echo $setting['value3']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value3']?>">Seçiniz</label>
            </div>
          </div>
        </div>
        <div class="card-deck text-center">
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym']?> <?php echo $setting['value4']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value4']?>" id="<?php echo $setting['value4']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value4']?>">Seçiniz</label>
            </div>
          </div>
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym']?> <?php echo $setting['value5']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value5']?>" id="<?php echo $setting['value5']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value5']?>">Seçiniz</label>
            </div>
          </div>
          <div class="card mb-4">
            <div class="card-header">
              <h2 class="my-0"><?php echo $setting['currency_sym'];?> <?php echo $setting['value6']?></h2>
            </div>
            <div class="card-body">
              <ul class="list-unstyled mt-3 mb-4">
                <li><i class="fas fa-check-square text-success fa-fw"></i> Kredi kartı geçerli</li>
                <li><i class="fas fa-check-square text-success fa-fw"></i> Ekstra ücret yok</li>
              </ul>
            <input name="amount" type="radio" value="<?php echo $setting['value6']?>" id="<?php echo $setting['value6']?>" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="<?php echo $setting['value6']?>">Seçiniz</label>
            </div>
          </div>
        </div>
      <div class="collapse collapseExample" id="collapseExample">
        <div class="card card-body">
          <table class="table gateways">
            <h4 class="text-center">Ödeme Metodu</h4>
            <?php 
			foreach($gateways as $gateway){
			?>
            <tr>
              <td class="text-center"><input name="gateway" type="radio" name="gateway" value="<?php echo $gateway['file']; ?>" id="<?php echo $gateway['file']; ?>" checked="checked">
                <label class="text-center"for="<?php echo $gateway['file']; ?>">
                <h4><img src="../system/gateways/<?php echo $gateway['logo'];	?>" width="200px"/></h4>
                </label></td>
            </tr>
            <?php } ?>
          </table>
        </div>
      </div>
      <div class="clearfix">
        <button type="submit" name="submit" class="btn btn-success pull-right w-100"> Bakiye yükle <i class="icon-arrow-right icon-white"></i></button>
      </div>
      <input type="hidden" name="crf" value="<?php echo $crf;?>">
    </form>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function() { 
            $("input").click(function() { 
                $("html, body").animate({ 
                    scrollTop: $( 
                      'html, body').get(0).scrollHeight 
                }, 2000); 
            }); 
        });  

</script>
<?php require_once('includes/user-footer.php'); ?>
