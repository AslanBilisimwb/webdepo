<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='PayPal ile Yükle';
$pg ='3';
require_once('../system/config-user.php');
require_once('../system/gateways.php');
$msg = false;
$error = false;
$crf = md5("TSM" . date('YMD'));
if(isset($_POST) && isset($_POST['crf'])){
$error = ($_POST['crf'] != $crf ? 'Invalid CRF':false);
$error = (empty($_POST['amount'])? 'Please select amount':$error);
$error = (empty($_POST['gateway'])? 'Please select payment method':$error);

if(!$error){

$_SESSION['payment']['crf'] = $crf;
$_SESSION['payment']['amount'] = $_POST['amount'];
$_SESSION['payment']['gateway'] = $_POST['gateway'];
$_SESSION['payment']['detail'] = "Funds Deposit";
$_SESSION['payment']['redir'] = "transactions.php";
$_SESSION['payment']['action'] = "deposit";


if(!isset($_REQUEST['ajax'])){
header('location:process.php?action=process');
exit;
}
}
if(isset($_REQUEST['ajax'])){
echo ($error ? $error:'success');
exit;
}
}
require_once('includes/user-header.php');
?>

<div class="row">
<div class="col-sm-4">
  <div class="my-1 p-3 bg-white rounded box-shadow">
    <?php include'includes/sidenav.php';?>
  </div>
</div>
<div class="col-sm-8">
  <div class="my-1 p-3 bg-white rounded box-shadow">
    <form class="form-horizontal amount" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" id="deposit-funds">
      <?php
if($msg){
				echo  "<div class=\"alert alert-success block\">".$user->msg."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				if($error){
				echo "<div class=\"alert alert-danger block\">".$user->error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
				?>
      <div class="card-deck text-center">
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym'];?>20</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="20" id="20" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="20">Seçiniz</label>
          </div>
        </div>
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym']?>30</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="30" id="30" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="30">Seçiniz</label>
          </div>
        </div>
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym']?>50</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="50" id="50" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="50">Seçiniz</label>
          </div>
        </div>
      </div>
      <div class="card-deck text-center">
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym']?>70</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="70" id="70" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="70">Seçiniz</label>
          </div>
        </div>
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym']?>100</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="100" id="100" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="100">Seçiniz</label>
          </div>
        </div>
        <div class="card mb-4">
          <div class="card-header">
            <h2 class="my-0"><?php echo $setting['currency_sym'];?>200</h2>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mt-3 mb-4">
              <li><i class="fas fa-check-square text-success fa-fw"></i> Transfer ücreti yok</li>
            </ul>
            <input name="amount" type="radio" value="200" id="200" data-toggle="collapse" data-target=".collapseExample" aria-expanded="false" aria-controls="collapseExample">
            <label for="200">Seçiniz</label>
          </div>
        </div>
      </div>
      <div class="collapse collapseExample" id="collapseExample">
        <div class="card card-body">
          <table class="table gateways">
            <h4>Ödeme Yöntemi Seçiniz</h4>
            <?php 
	$g_count= 1;
	foreach($gateways as $gateway){
	if(!is_int($g_count/2)){
		echo "<tr>";
		}
	
	?>
            
              <td class="width50"><input name="gateway" type="radio" name="gateway" value="<?php echo $gateway['file']; ?>" id="<?php echo $gateway['file']; ?>">
                <label class="text-center"for="<?php echo $gateway['file']; ?>">
                <h4><img src="../system/gateways/<?php echo $gateway['logo'];	?>" /></h4>
                </label></td>
              <?php 
	if(is_int($g_count/2) && $g_count != 1 ){
		echo "</tr>";
		}
		$g_count = $g_count + 1;
	}
	?>
          </table>
        </div>
      </div>
      <div class="clearfix">
        <button type="submit" name="submit" class="btn btn-success pull-right w-100"> Bakiye Yükle <i class="icon-arrow-right icon-white"></i></button>
      </div>
      <input type="hidden" name="crf" value="<?php echo $crf;?>">
    </form>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
$("input[name=gateway]").change(function(){
$(".gateways td").removeClass("selected text-success");
$(this).parent().addClass("selected text-success");
});

$("input[name=amount]").change(function(){
$(".amount label").removeClass("selected text-success");
$(this).parent().children('label').addClass("selected text-success");
});

$("#deposit-funds").unbind().bind('submit',function(){
$(".alert").remove();
$("#deposit-funds").prepend("<div class=\"alert none\"><span></span><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>");
if(!$("input[name=amount]:checked").val()){
$(".alert span").text("Tutar seçiniz");
$(".alert").addClass("alert-danger");
$(".alert").show();
return false;
}
if(!$("input[name=gateway]:checked").val()){
$(".alert span").text("Ödeme yöntemi seçiniz");
$(".alert").addClass("alert-danger");
$(".alert").show();
return false;
}
$(".alert span").text("Bekleyiniz...");
$(".alert").addClass("alert-success");
$(".alert").show();

var actionUrl = $(this).attr('action');
var serialized = $(this).serialize();
$.ajax({
			type:"POST",
			url: actionUrl,
			data:serialized + "&ajax=true",
			success: function(html){
			if( html == "success" ){
				top.location.href='process.php?action=process';
				}else{
			$(".alert").remove();
			$("#deposit-funds").prepend("<div class=\"alert alert-error\"><span>"+html+"</span><button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>");		
					}
			}
});

return false;
});
});
</script>
<?php require_once('includes/user-footer.php'); ?>
