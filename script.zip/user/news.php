<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Haberler';
$pg ='7';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
$news = $newsl->get_all_news();
//$news1 = $newsl->get_important_news();
?>

<div class="row">
<div class="col-sm-4">
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php include'includes/sidenav.php';?>
  </div>
</div>
<div class="col-sm-8">
<?php foreach($news as $newsl){?>
<div id="accordion" class="accordion">
<div class="my-3 p-3 bg-warning rounded box-shadow">
  <div class="card m-b-0">
    <div class="card-header mpointer collapsed" data-toggle="collapse" data-parent="#accordion" href="#<?php echo $newsl['id']?>"> <a class="card-title"> <?php echo $newsl['title']?><br />
      <small>
      <?php $timeago=get_timeago(strtotime($newsl['date'])); echo $timeago; ?> önce
      | <?php echo $newsl['author'];?> tarafından gönderildi</small> </a> </div>
    <div id="<?php echo $newsl['id']?>" class="card-block collapse">
      <div class="card-body"> <?php echo $newsl['content']?> </div>
    </div>
  </div>
</div>
<?php } ?>
<?php require_once('includes/user-footer.php');?>
