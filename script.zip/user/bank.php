<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Havale/EFT ile Bakiye Yükle';
$pg ='3';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
$banks = $bank->get_all_banks();
//$banks1 = $banksl->get_important_banks();
?>

<div class="row">
  <div class="col-sm-4">
    <div class="my-3 p-3 bg-white rounded box-shadow">
      <?php include'includes/sidenav.php';?>
    </div>
  </div>
  <div class="col-sm-8">
    <div class="my-3 p-3 bg-white rounded box-shadow">
    <h5>Banka Hesaplarımız</h5>
    <?php foreach($banks as $bank){?>
    <div id="accordion" class="accordion">
      <div class="my-3 p-3 bg-light rounded box-shadow">
        <div class="card m-b-0">
          <div class="card-header mpointer collapsed" data-toggle="collapse" data-parent="#accordion" href="#<?php echo $bank['id']?>"> <a class="card-title"> <?php echo $bank['title']?></a> </div>
          <div id="<?php echo $bank['id']?>" class="card-block collapse">
            <div class="card-body"> <?php echo $bank['content']?> </div>
          </div>
        </div>
      </div>
      <?php } ?>
      </div></div>
      <hr />
      <h5>Havale bildirimi</h5>
      <h6 class="text-red">Havale/Eft Yaptıktan sonra, işleminizi hızlandırmak için lütfen aşağıdaki form ile bize bildirin.</h6>
        <div class="my-3 p-3 bg-light rounded box-shadow">
          <form id="havale">
            <div class="input-group mb-3">
              <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-user-circle" aria-hidden="true"></i></span> </div>
              <input type="text" name="username" class="form-control" value="<?php echo $userDetails['username']; ?>" ="" readonly="readonly">
            </div>
            <div class="input-group mb-3">
              <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="far fa-address-card" aria-hidden="true"></i></span> </div>
              <input type="text" name="name" class="form-control" value="<?php echo $userDetails['fname']; ?>" ="" readonly="readonly">
            </div>
            <div class="input-group mb-3">
              <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope" aria-hidden="true"></i></span> </div>
              <input type="text" name="email" class="form-control" value="<?php echo $userDetails['email']; ?>" ="" readonly="readonly">
            </div>
            <div class="form-group">
              <label for="subject"><?php echo $l['bbank']; ?></label>
      <div class="input-group mb-3">
        <select class="custom-select" name="bbank" id="bbank" required>
          <option value="">Banka Seçin...</option>
          <?php foreach($banks as $bank) {
?>
          <option value="<?php echo $bank['title']; ?>"><?php echo $bank['title']; ?></option>
          <?php } ?>
        </select>
      </div>
            </div>
            <div class="form-group">
              <label for="subject"><?php echo $l['ubank']; ?></label>
              <input type="text" name="ubank" class="form-control" maxlength="100" required>
            </div>
            <div class="form-group">
              <label for="subject"><?php echo $l['tutar']; ?></label>
        <input type="text" name="tutar" class="form-control" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1"><?php echo $l['message']; ?></label>
              <textarea name="message" class="form-control" id="exampleInputPassword1" maxlength="500"></textarea>
            </div>
            <div id="result">
              <button type="submit" id="contactbutton" class="btn btn-success submit"><?php echo $l['submit']; ?></button>
            </div>
          </form>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#havale").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "<?php echo $setting['website_url'];?>/system/assets/ajax/havale-bildirimi.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			beforeSend: function() 
        {
            $("#result").html('Veriler işleniyor...');
        },  
        success: function(response)
        {
            $("#result").html(response);
        }        
	   });
	}));
});
</script>
<?php require_once('includes/user-footer.php');?>
