<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('../system/config-user.php');
require_once('../system/classes/class.phpmailer.php');
require_once('../system/classes/class.smtp.php');
require_once('../system/classes/class.pop3.php');
$pageTitle ='Kullanıcı Girişi';
if(isset($_REQUEST['action']) && ($_REQUEST['action'] == "recover")){
		if(isset($_REQUEST['email']) && empty($_REQUEST['email'])){
			$reseterror= 'Email giriniz';
		}
		elseif(isset($_REQUEST['email']) && !$user->emailcontrol($_REQUEST['email'])){
			$reseterror= 'Geçersiz email';
		}
		elseif(isset($_REQUEST['email'])) {
		
		$email=trim($_REQUEST['email']);
		$generated_password = substr(md5(rand(999, 999999)), 0, 8);
$smtp_auth   = $setting['smtp_auth'];
$smtp_secure = $setting['smtp_secure'];
$smtp_host   = $setting['smtp_host'];
$smtp_port   = $setting['smtp_port'];
$smtp_user   = $setting['smtp_user'];
$smtp_pass   = $setting['smtp_pass'];
if ($setting['re_sitekey'] !=''){ 
$secret = $setting['re_securekey'];
$ip = $_SERVER['REMOTE_ADDR'];
//verify if user has filled the captcha correctly

if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){ 
$response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$_POST['g-recaptcha-response']."&remoteip=".$ip);
	$responseData = json_decode($response);

		if($responseData->success){
		//reCaptcha API has validated the user as a human being.
		}else{
		// show error message if response from the reCaptcha server is not ‘Success’
echo '<h2 align="center">SPAM??? Tekrar deneyin.</h2>';
exit;		
}

}else{
//show error message if user has not clicked on reCaptcha box
echo '<h2 align="center">Robot olmadığınızı bilmek istiyoruz. <br>Geri gidin ve güvenlik kutucuğunu tıklayın.</h2>';
exit;		
}	
}else{}
		if(!$user->error){
	$headers  = "MIME-Version: 1.0\n";
	$headers .= "From: ".$setting['site_name']." <noreply@".$_SERVER['HTTP_HOST']."> \n";
    $headers .= "Content-type: text/html; charset=utf-8\n";
    $headers .='Content-Transfer-Encoding: 8bit\n';
	$subject = "Şifremi Unuttum";
	$message = '<html>
         <head>
           <meta charset="utf-8" />
         </head>
         <body>
           <font color="#303030";>
             <div align="center">
               <table width="600px">
                 <tr>
                   <td>
                     <div align="center"><img src="'.$setting['website_url']."/system/assets/uploads/img/".$setting['site_logo'].'" width="300"></div><br>
                     <div align="center"><b>Yeni şifre talebinde bulundunuz</b>,</font></div><br>
                     <div align="center">Email adresiniz: <b>'.$email .'</b></div><br>
                     <div align="center">Yeni Şifreniz: <b>'.$generated_password.'</b></div><br>
                     <div align="center"><a href='.$setting['website_url'].'/user/login.php><b>Buraya tıklayıp şifrenizi güncelleyiniz</b></a></div><br><hr>
                   </td>
                 </tr>
                 <br><br>
                 <tr>
                   <td align="center">
                     <font size="2">
                       Copyright &copy; '.$setting['site_name'].'
                     </font>
                   </td>
                 </tr>
               </table>
             </div>
           </font>
         </body>
         </html>';


$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = $smtp_auth; // authentication enabled
$mail->SMTPSecure = $smtp_secure; // secure transfer enabled REQUIRED for GMail
$mail->Host = $smtp_host;
$mail->Port = $smtp_port; // or 587
$mail->IsHTML(true);
$mail->SetLanguage('en', 'phpmailer/language');
$mail->CharSet  ='utf-8';

$mail->Username = $smtp_user; // Mail adresi
$mail->Password = $smtp_pass; // Parola
$mail->SetFrom($smtp_user, $setting['homepage_header']); // Mail adresi

$mail->AddAddress($email); // Gönderilecek kişi

$mail->Subject = $subject;
$mail->Body = $message;

if(!$mail->Send()){
     echo '<span class="text-danger">Password genarate Error: '.$mail->ErrorInfo.'</span>';
}
	
	$generated_password = md5($generated_password);
	$result= $user->updateve($email,'password_recover','1');
	$result= $user->updateve($email,'password',$generated_password);
	$success = 'Geçici şifreniz email hesabınıza gönderildi!';
	}else{
	$reseterror = $user->error;
	}
	}
}
?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<script src="../system/assets/js/jquery.min.js"></script>
<link href="../system/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../system/assets/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" type="text/css" href="../system/assets/css/my-login.css">
<link rel="stylesheet" type="text/css" href="../system/assets/css/all.css">
<script defer src="../system/assets/js/all.js"></script>

<title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
</head>
<body class="my-login-page">
<?php
if(isset($_REQUEST['action']) && ($_REQUEST['action'] == "recover")){
?>
<section class="">
  <div class="container h-100">
    <div class="row justify-content-md-center align-items-center h-100">
      <div class="card-wrapper mt-5">
        <div class="card fat">
          <div align="center"> <img src="<?php echo$setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" width="300"> </div>
          <div class="card-body">
            <h4 class="card-title text-center">Forgot Password</h4>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
              <?php if(isset($reseterror)){
		echo  "<div class=\"alert alert-danger block\">".$reseterror."<button  type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
		 }elseif(isset($success)){
		echo  "<div class=\"alert alert-success block\">".$success."<button   type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
		 }
		 ?>
              <div class="form-group">
                <label for="email">E-Mail Adresi</label>
                <input id="email" type="email" class="form-control" name="email" value="" required autofocus pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Geçerli bir email adresi giriniz!">
                <input  class="form-control" type="hidden" name="action" value="recover">
                <div class="form-text text-muted"> "Şifremi Sıfırla" tuşuna bastığınızda yeni şifreniz gönderilecek </div>
              </div>
              <?php if ($setting['re_sitekey'] !=''){ ?>
              <div class="g-recaptcha" data-sitekey="<?php echo $setting['re_sitekey']; ?>"></div>
              <?php }else{} ?>
              <div class="form-group no-margin">
                <button type="submit" name="submit" class="btn btn-info btn-block"> Şifremi Sıfırla </button>
              </div>
            </form>
          </div>
        </div>
        <div class="footer"> Copyright &copy; <?php echo $setting['site_name']; ?> </div>
      </div>
    </div>
  </div>
</section>
<?php
}
else{
?>
<section class="">
  <div class="container h-100">
    <div class="row justify-content-md-center h-100">
      <div class="card-wrapper mt-5">
        <div class="card fat">
          <div align="center"> <img src="<?php echo$setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" width="300"> </div>
          <div class="card-body">
            <h4 class="card-title text-center">Giriş</h4>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
              <?php
if(isset($error)){
				echo  "<div class=\"alert alert-danger block\">".$error."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
				}
	?>
              <div class="input-group mb-3">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-at" aria-hidden="true"></i></span> </div>
                <input id="email" type="email" class="form-control" name="email" value="" required autofocus pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter a valid email address!" placeholder="Email">
              </div>
              <div class="input-group mb-3">
                <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-key" aria-hidden="true"></i></span> </div>
                <input id="password" type="password" class="form-control" name="pwd" required placeholder="Şifre">
                </div>
                <div>
                <a href="login.php?action=recover" class="float-right"> Şifremi Unuttum </a> </div>
              <input  class="form-control" type="hidden" name="login">
              <br>
              <div class="form-group no-margin">
                <button type="submit" class="btn btn-success btn-block"> Giriş Yap </button>
              </div>
              <div class="margin-top20 text-center"> Hesabınız yok mu? <a href="register.php">Şimdi Kayıt Ol</a> </div>
            </form>
          </div>
        </div>
        <div class="footer"> Copyright &copy; <?php echo $setting['site_name']; ?> </div>
      </div>
    </div>
  </div>
</section>
<?php
}
?>
</body>
</html>