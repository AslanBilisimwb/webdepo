<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Aldıklarım';
$pg ='2';
require_once('../system/config-user.php');
$sales = $purchases->all('user_id',$crypt->decrypt($_SESSION['uid'],'USER'));
$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;
$maxres = 5;
$num = count($sales);
$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
require_once('includes/user-header.php');
if(isset($_GET['type']) && isset($_GET['msg'])){
echo  "<div class=\"alert mt-3 ".$_GET['type']." block\">".$_GET['msg']."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
}?>

<div class="alert alert-info alert-dismissible fade show mb-0 mt-3" role="alert">Aldığınız ürünleri <strong>yayından kalkmadan indirin!</strong> . </div>
<div class="row">
<div class="col-sm-4">
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php include'includes/sidenav.php';?>
  </div>
</div>
<div class="col-sm-8">
  <?php if($num > 0){ ?>
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <th scope="col">Adı</th>
          <th scope="col">Tarih</th>
          <th scope="col">İndir</th>
        </tr>
      </thead>
      <tbody>
        <?php 
for($i = $start; $i <= $last; $i++) {
if(!isset($sales[$i])){
break;
}
$pro_details= $product->details($sales[$i]['pro_id']);
$tran_details= $transaction->details($sales[$i]['transaction_id']);
?>
        <tr>
          <td class="align-middle"><b><a href="<?php echo $setting['website_url'].'/item/'.$sales[$i]['pro_id']; ?>/"><?php echo $pro_details['name'];?></a></b></td>
          <td class="align-middle"><?php echo $sales[$i]['date'];?></td>
          <td class="align-middle"><div class="btn-group"><a href="download.php?id=<?php echo $sales[$i]['pro_id'];?>" class="btn btn-success">İndir <i class="fas fa-cloud-download-alt" aria-hidden="true"></i></a></div></td>
        </tr>
        <?php }?>
      </tbody>
    </table>
  </div>
  <br>
  <ul class="pagination justify-content-center">
    <?php 
$back = (($currpage == 1)? '#':'downloads.php?page='.($currpage-1));
$next = (($currpage == $pages)? 'downloads.php?page='.$currpage:'downloads.php?page='.($currpage+1));
?>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == 1)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Önceki" href="<?php echo $back;?>" tabindex="-1"><i class="fa fa-chevron-left" aria-hidden="true"></i></a> </li>
    <li class="page-item"> <a class="page-link" <?php echo ($currpage == $pages)?"class='disabled'":''; ?> data-toggle="tooltip" data-placement="top" title="Sonraki" href="<?php echo $next;?>"><i class="fa fa-chevron-right" aria-hidden="true"></i></a> </li>
  </ul>
  <?php
 }else{
 echo  "<div class='my-3 p-3 bg-white rounded box-shadow'><div class='alert alert-primary mb-0'>Henüz bir ürün almadınız!</div></div>";
 }?>
</div>
<?php require_once('includes/user-footer.php');?>
