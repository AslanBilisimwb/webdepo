<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$pageTitle ='İletişim';
$pg ='9';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
if(isset($_GET['type']) && isset($_GET['msg'])){
echo  "<div class=\"alert ".$_GET['type']." block\">".$_GET['msg']."<button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button></div>";
}
?>

<div class="row">
<div class="col-sm-4">
  <div class="my-3 p-3 bg-white rounded box-shadow">
    <?php include'includes/sidenav.php';?>
  </div>
</div>
<div class="col-sm-8">
  <div class="my-3 p-3 bg-light rounded box-shadow">
    <form id="contact">
      <div class="input-group mb-3">
        <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-user-circle" aria-hidden="true"></i></span> </div>
        <input type="text" name="username" class="form-control" value="<?php echo $userDetails['username']; ?>" ="" readonly="readonly">
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="far fa-address-card" aria-hidden="true"></i></span> </div>
        <input type="text" name="name" class="form-control" value="<?php echo $userDetails['fname']; ?> <?php echo $userDetails['lname']; ?>" ="" readonly="readonly">
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope" aria-hidden="true"></i></span> </div>
        <input type="text" name="email" class="form-control" value="<?php echo $userDetails['email']; ?>" ="" readonly="readonly">
      </div>
      <div class="input-group mb-3">
        <div class="input-group-prepend"> <span class="input-group-text" id="basic-addon1"><i class="fas fa-mobile-alt" aria-hidden="true"></i></span> </div>
        <input type="text" name="gsm" class="form-control" value="<?php echo $userDetails['gsm']; ?>" ="" readonly="readonly">
      </div>
      <div class="form-group">
        <label for="subject"><?php echo $l['subject']; ?></label>
        <input type="text" name="subject" class="form-control" minlength="10" maxlength="100" required>
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1"><?php echo $l['message']; ?></label>
        <textarea name="message" class="form-control" id="exampleInputPassword1"  minlength="10" maxlength="500" required></textarea>
      </div>
      <div id="result">
        <button type="submit" id="contactbutton" class="btn btn-success submit"><?php echo $l['submit']; ?></button>
      </div>
    </form>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#contact").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "<?php echo $setting['website_url'];?>/system/assets/ajax/contact-process.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			beforeSend: function() 
        {
            $("#result").html('Veriler işleniyor...');
        },  
        success: function(response)
        {
            $("#result").html(response);
        }        
	   });
	}));
});
</script>
<?php require_once('includes/user-footer.php'); ?>