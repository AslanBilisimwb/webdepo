<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$pageTitle ='Genel Görünüm';
$pg ='1';
require_once('../system/config-user.php');
require_once('includes/user-header.php');
$num  = $transaction->countAll('user_id',$crypt->decrypt($_SESSION['uid'],'USER'));
$currpage = (isset($_GET['page'])) ? $_GET['page'] : 1;
$maxres = 5;
$pages = $num / $maxres;
$pages = ceil($pages);
$start = ( $currpage - 1 ) * $maxres ;
$last = $start + $maxres -1;
$transactions = $transaction->getUserTransactions($crypt->decrypt($_SESSION['uid'],'USER'),$start,$maxres);
?>

<div class="row my-3">
  <div class="col-xl-4 col-sm-6">
    <div class="card text-white bg-success o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon float-right"> <i class="far fa-fw fa-money-bill-alt font40"></i> </div>
        <div class="mr-5"><span class="font16"> Bakiyem &nbsp;&nbsp;</span> <span class="font24"><?php echo $setting['currency_sym'] . $userDetails['balance'];?></span></div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo $setting['website_url']; ?>/user/deposit.php"> <span class="float-left">Bakiye Yükle</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
  </div>
  <div class="col-xl-4 col-sm-6">
    <div class="card text-white bg-danger o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon float-right"> <i class="fas fa-fw fa-heart font40"></i> </div>
        <div class="mr-5"><span class="font16"> Beğendiklerim &nbsp;&nbsp;</span> <span class="font24"><?php echo $wishcount;?></span> </div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo $setting['website_url']; ?>/user/wishlist.php"> <span class="float-left">Beğendiklerime Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
  </div>
  <div class="col-xl-4 col-sm-6">
    <div class="card text-white bg-warning o-hidden h-100 box-shadow">
      <div class="card-body">
        <div class="card-body-icon float-right"> <i class="fas fa-fw fa-shopping-basket font40"></i> </div>
        <div class="mr-5"><span class="font16"> Aldıklarım &nbsp;&nbsp;</span> <span class="font24"><?php echo $userDetails['purchases'];?></span> </div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo $setting['website_url']; ?>/user/downloads.php"> <span class="float-left">Aldıklarıma Git</span> <span class="float-right"> <i class="fa fa-angle-right"></i> </span> </a> </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-4">
    <div class="my-3 p-3 bg-white rounded box-shadow">
      <?php include'includes/sidenav.php';?>
    </div>
  </div>
  <div class="col-sm-8">
    <div class="my-3 p-3 bg-white rounded box-shadow">
      <h4 class="pb-2 mb-2">Son Finansal İşlemler</h4>
      <div id="transactions" class="collapse show">
        <div class="table-responsive">
          <table class="table table-striped table-bordered">
            <thead>
              <tr>
              	<th scope="col"><?php echo $l['id'];?></th>
              	<th scope="col"><?php echo $l['date'];?></th>
              	<th scope="col"><?php echo $l['type'];?></th>
              	<th scope="col"><?php echo $l['details'];?></th>
              	<th scope="col"><?php echo $l['amount'];?></th>
              	<th scope="col"><?php echo $l['status'];?></th>
              </tr>
            </thead>
            <tbody>
              <?php
foreach($transactions as $trans){
if($trans['product']!='0'){
$prod = $product->details($trans['product']);
$prod = $prod['name'];
}else{
$prod = 'Bakiye Yükleme';
}
if($trans['type']=='3'){
$prod = 'Manuel Yükleme';
}
?>
            <tr>
              <th scope="row"><?php echo $trans['id'];?></th>
              <td><?php echo $trans['date'];?></td>
              <td><?php echo ($trans['type']=='1'?'<span class="badge badge-danger">Ürün alış</span>':'<span class="badge badge-success">Yükleme</span>');?></td>
              <td><?php echo $prod;?></td>
              <td><?php echo $setting['currency_sym'] . $trans['amount'];?></td>
              <td><?php echo ($trans['callback']=='1'?'<span data-toggle="tooltip" data-placement="top" title="Tamamlandı" class="badge badge-success"><i class="fas fa-check" aria-hidden="true"></i></span>':'<span data-toggle="tooltip" data-placement="top" title="Hata" class="badge badge-danger"><i class="fas fa-times" aria-hidden="true"></i></span>');?></td>
            </tr>
              <?php
}
?>
            </tbody>
          </table>
        </div>
        <div class="row justify-content-md-center"> <a href="<?php echo $setting['website_url'];?>/user/transactions.php" class="btn btn-sm btn-info">Tüm Finansal İşlemler</a> </div>
      </div>
    </div>
  </div>
</div>
<?php require_once('includes/user-footer.php');?>
