jQuery(document).ready(function(){

// Set path to PHP source to use in ajax

	var sitepath = "";

// Append PHP source path to <body> for further use
	if(!jQuery("#tsm-site-path").length){
		jQuery("body").append("<span class=\"none\" id=\"tsm-site-path\">" + sitepath + "</span>");
	}
	
// Append Modal to handle 
	if(!jQuery("#tsm-buy-dialog").length){
	jQuery("body").append("<div id=\"tsm-buy-dialog\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\"aria-labelledby=\"buydialog\" aria-hidden=\"true\"><div class=\"modal-dialog\">    <div class=\"modal-content\"><div class=\"modal-header\"> <h5 class=\"modal-title\"></h5>   <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button>  </div>  <div class=\"modal-body\" id=\"tsm-buy-dialog-body\"></div>      <div class=\"modal-footer text-center\"><i class=\"fab fa-cc-visa fa-2x\"></i> <i class=\"fab fa-cc-paypal fa-2x\"></i> <i class=\"fab fa-cc-mastercard fa-2x\"></i> <i class=\"fab fa-cc-discover fa-2x\"></i></div></div>");
	
	}
	
// Init functions to create buttons
	jQuery(".tsm-btn").tsmBtn();
	jQuery(".tsm-img").tsmImg();
	jQuery(".tsm-desc").tsmDesc();
	jQuery(".tsm-info").unbind().bind('click',function(){
	jQuery(this).tsmLighbox();
	});

//	Functions in modal
	jQuery("#tsm-buy-btn").click(function(){
	jQuery("#tsm-buy-info").hide();
	jQuery("#tsm-buy-now").fadeIn("slow");
	});
	jQuery(".tsm-show-forgot-pwd").click(function(){
	jQuery("#tsm-buy-now").hide();
	jQuery("#tsm-new-account").hide();
	jQuery("#tsm-forgot-pwd").fadeIn("slow");
	});
	jQuery(".tsm-show-new-account").click(function(){
	jQuery("#tsm-buy-now").hide();
	jQuery("#tsm-forgot-pwd").hide();
	jQuery("#tsm-new-account").fadeIn("slow");
	});
	jQuery(".tsm-show-buy-login").click(function(){
	jQuery("#tsm-forgot-pwd").hide();
	jQuery("#tsm-new-account").hide();
	jQuery("#tsm-buy-now").fadeIn("slow");
	});
	jQuery("#tsm-pay-now").click(function(){
	jQuery("#tsm-pay-now").hide();
	jQuery("#tsm-pay-now-form").fadeIn("slow");
	});
		jQuery("#tsm-pay-now-form").unbind().bind('submit',function(){
	jQuery(".alert").remove();
		if(!jQuery("input[name=gateway]:checked").val()){
		jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger'>Ödeme metodu seçiniz</div>");
		return false;
		}else{
	
			var pro_id = jQuery("#product_id_div").html();
			var serialized = jQuery(this).serialize();
		jQuery.ajax({
	  		type: "POST",
	  		url: sitepath + "/system/assets/ajax/buy.php",
	  		data:serialized + "&pay_now=true&ajax=true",
	  		success: function(html){
			if(html =="success"){
			top.location.href= sitepath + "/user/process.php?action=process";	
			}else{
			jQuery("#buy-dialog-body").prepend("<div class='alert alert-error error'>"+html+"</div>");
			}
		}
	});
	return false;
	}
	});	
		jQuery("#tsm-use-prepaid").unbind().bind('click',function(){
		var r=confirm("Tutar bakiyenizden düşülecektir.\r\nDevam Et");
			if (r!=true)
			{
			jQuery(".alert").remove();
			jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>Ödemeden çıkıldı!</div>");
			jQuery("#tsm-pay-now").fadeIn("slow");
			return false;
			}else{			
			jQuery('#tsm-buy-dialog .modal-body').prepend("<div id='tsm-loading' class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
		
		jQuery("#tsm-pay-now-form").hide();
		var pro_id = jQuery("#product_id_div").html();
	jQuery.ajax({
	  		type: "POST",
	  		url: sitepath + "/system/assets/ajax/buy.php",
	  		data:"product_id="+pro_id + "&buy=true&ajax=true",
	  		success: function(html){
			if(html =="success"){
			top.location.href=sitepath + '/user/downloads.php';
			}else{
			jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>"+html+"</div>");
			}
		}
	});
	return false;
	}
	return false;
	});
	
	
	jQuery("input[name=gateway]").change(function(){
		jQuery(".gateways td").removeClass("selected text-success");
		jQuery(this).parent().addClass("selected text-success");
	});

	
		jQuery("#tsm-buy-login-form").unbind().bind('submit',function(){
		jQuery('#tsm-buy-dialog .modal-body').prepend("<div id='tsm-loading' class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
	jQuery("#tsm-buy-dialog-body .alert").remove();
	var email = jQuery("#inputEmail").val();
	var password = jQuery("#inputPassword").val();
	if(email == "" || password ==""){
	jQuery("#tsm-loading").remove();
	jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>Email ve şifrenizle giriş yapınız</div>");
	return false;
	}else{
	
	var pro_id = jQuery("#product_id_div").html();
	var serialized = jQuery(this).serialize();
		jQuery.ajax({
	  		type: "POST",
	  		url: sitepath + "/system/assets/ajax/buy.php",
	  		data:serialized + "&ajax=true",
	  		success: function(html){
			if(html =="success"){
			jQuery("#tsm-buy-dialog-body").load(sitepath + "/system/assets/ajax/buy.php?product_id="+pro_id ,function(){
			jQuery("#tsm-buy-info").hide();
			jQuery("#tsm-buy-now").fadeIn("slow");
			jQuery.getScript(sitepath + '/system/tsm.js');
			});			
			}else{
			jQuery("#tsm-loading").remove();
			jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>"+html+"</div>");
			}
		}
	});
	return false;
	}
	});	
	
		jQuery("#tsm-new-user").unbind().bind('submit',function(){
	jQuery('#tsm-buy-dialog .modal-body').prepend("<div id='tsm-loading' class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
	jQuery("#tsm-buy-dialog-body .alert").remove();
	var email = jQuery("#new-email").val();
	var password = jQuery("#new-pwd").val();
	var password2 = jQuery("#new-pwd2").val();
	if(email == "" || password =="" || password!=password2){
	jQuery("#buy-dialog-body").prepend("<div class='alert alert-danger text-center'>Tüm alanları doldurunuz</div>");
	jQuery("#tsm-loading").remove();
	return false;
	}else{
	var pro_id = jQuery("#product_id_div").html();
	var serialized = jQuery(this).serialize();
		jQuery.ajax({
	  		type: "POST",
	  		url: sitepath + "/user/new.php",
	  		data:serialized + "&signup=true&ajax=true",
	  		success: function(html){
			if(html =="success"){
			jQuery("#tsm-buy-dialog-body").load(sitepath + "/system/assets/ajax/buy.php?product_id="+pro_id ,function(){
			jQuery("#tsm-buy-info").hide();
			jQuery("#tsm-buy-now").show();
			jQuery.getScript(sitepath + '/system/tsm.js');
			});			
			}else{
			jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>"+html+"</div>");
			jQuery("#tsm-loading").remove();
			}
		}
	});
	return false;
	}
	});
		jQuery("#tsm-coupons-form").unbind().bind('submit',function(){
		var pro_id = jQuery("#product_id_div").html();
			jQuery('#tsm-buy-dialog .modal-body').prepend("<div id='tsm-loading' class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
	jQuery("#tsm-buy-dialog-body .alert").remove();
		var couponCode = jQuery("#tsm-coupon-code").val();
		var jsonUrl = sitepath + "/system/assets/ajax/coupons.php";
		jQuery.get( jsonUrl, { discountcoupon: couponCode }).done(function( data ) {
		var jsonData = jQuery.parseJSON(data);
		if(typeof jsonData['error'] == 'undefined'){
		jQuery("#tsm-buy-dialog-body").load(sitepath + "/system/assets/ajax/buy.php?product_id="+pro_id ,function(){
			jQuery("#tsm-buy-info").hide();
			jQuery("#tsm-buy-now").show();
			jQuery.getScript(sitepath + '/system/tsm.js');
			});
		}else{
		jQuery("#tsm-buy-dialog-body").prepend("<div class='alert alert-danger text-center'>"+jsonData.error+"</div>");
		jQuery("#tsm-loading").remove();
		return false;
		}
		});
		return false;
	});
	jQuery("#tsm-coupon-remove").unbind().bind('click',function(){
		 jQuery("#tsm-coupon-code").val(null);
		jQuery("#tsm-coupons-form").submit();
		return false;
		});
// end jQuery(document).ready()		
		}); 
// functions
 //Buttons
jQuery.fn.tsmBtn = function(){
 var sitepath = jQuery("#tsm-site-path").html();
	this.each(function(){
		var id = jQuery(this).attr('data-pid');
		var button_text = jQuery(this).attr('data-text');
		var price = jQuery(this).attr('data-price');
		var name = jQuery(this).attr('data-name');
		jQuery(this).removeClass('tsm-btn');
		var jsonUrl = sitepath + "/system/assets/ajax/json-load.php";
		var curr = jQuery(this) ;
		jQuery(this).html('Bağlanıyor...');
		jQuery.get( jsonUrl, { product_id: id, type: "btn" }).done(function( data ) {
		var jsonData = jQuery.parseJSON(data);
		if(typeof jsonData['error'] == 'undefined'){
			var markup = "<form class=\"tsm-form form-horizontal\" method=\"post\">";
			markup +="<input name=\"product_id\" type=\"hidden\" value=\"" +id+"\">";
			if(name =='show'){
			markup +="<span class='tsm-name'>"+jsonData.name+"</span> ";
			}
			if(price =='show'){
			markup +="<span class='tsm-price'>Fiyat: "+jsonData.currency+"&nbsp;"+jsonData.price+"</span>";
			}
			if(button_text !=null){
			markup +=" <button class='btn btn-success btn-lg btn-block font-bold mt-4' type=\"submit\" >"+button_text+"</button>";
			}else{
			markup +=" <button class='btn btn-success btn-lg btn-block font-bold mt-4' type=\"submit\" >Satın Al</button>";
			}
			markup +="</form>";
			curr.html(markup);
		}else{
		curr.html(jsonData.error);
		return false;
		}
			});
	});
	jQuery.getScript(sitepath + '/system/tsm.js');
	jQuery(".tsm-form").unbind().bind('submit',function(){
	jQuery(this).tsmBuy();
	return false;
	});
return false;
};
 //Images
jQuery.fn.tsmImg = function(){
// extract previously saved sitepath
 var sitepath = jQuery("#tsm-site-path").html();
	this.each(function(){
		var id = jQuery(this).attr('data-pid');
		var size = jQuery(this).attr('data-size');
		var responsive = jQuery(this).attr('data-responsive');
		var shape = jQuery(this).attr('data-shape');
		var w = jQuery(this).attr('data-w');
		var h = jQuery(this).attr('data-h');
		var jsonUrl = sitepath + "/system/assets/ajax/json-load.php";
		jQuery(this).addClass('cart-image');
		jQuery(this).removeClass('tsm-img');
		var curr = jQuery(this) ;
		jQuery(this).html('Loading Image..');
		jQuery.get( jsonUrl, { product_id: id, type: "img" }).done(function( data ) {
		var jsonData = jQuery.parseJSON(data);
		if(typeof jsonData['error'] == 'undefined'){
			var markup = "<img ";
			if(size =='small' || size =='medium' || size =='large'){
			jsonData.image =  size+'-'+jsonData.image;
			}
			markup +="src ='"+sitepath+"/system/assets/uploads/products/"+jsonData.image+"' ";
			markup +="style=\"";
			if(w !=null){
			markup +=" width:"+w+"px;";
			}
			if(h !=null){
			markup +=" height:"+h+"px;";
			}
			markup +="\"";
			markup += "/>";
			curr.html(markup);
			if(responsive !=null){
			curr.children('img').addClass('img-responsive');
			}
			if(shape == 'rounded' || shape == 'circle' || shape == 'thumbnail'){
			curr.children('img').addClass('img-'+shape);
			}
		}else{
		curr.html(jsonData.error);
		return false;
		}
		});
	});
return false;
};
	//Description
jQuery.fn.tsmDesc = function(){
// extract previously saved sitepath
 var sitepath = jQuery("#tsm-site-path").html();
	this.each(function(){
		var id = jQuery(this).attr('data-pid');
		jQuery(this).addClass('cart-description');
		jQuery(this).removeClass('tsm-desc');
		var jsonUrl = sitepath + "/system/assets/ajax/json-load.php";
		var curr = jQuery(this) ;
		jQuery.get( jsonUrl, { product_id: id, type: "desc" }).done(function( data ) {
		var jsonData = jQuery.parseJSON(data);
		if(typeof jsonData['error'] == 'undefined'){
		curr.html(jsonData.desc);
		}else{
		curr.html(jsonData.error);
		return false;
		}
		});
	});
return false;
};
jQuery.fn.tsmLighbox = function(){
// extract previously saved sitepath
 var sitepath = jQuery("#tsm-site-path").html();
  jQuery('#tsm-buy-dialog .modal-title').html("Item details");
 jQuery('#tsm-buy-dialog .modal-body').html("<div class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
	jQuery('#tsm-buy-dialog').modal();

		var id = jQuery(this).attr('data-pid');
		var jsonUrl = sitepath + "/system/assets/ajax/json-load.php";
		var curr = jQuery(this) ;
		jQuery.get( jsonUrl, { product_id: id, type: "all" }).done(function( data ) {
		var jsonData = jQuery.parseJSON(data);
		if(typeof jsonData['error'] == 'undefined'){
		var markup = "<div class='row'><div class='col-md-4 text-center'>";
		markup += "<img class='img-responsive img-thumbnail' src='"+sitepath + "/system/assets/uploads/products/"+jsonData.image+"' /></div>";
		markup +="<div class='col-md-8'><h3 class='no-top'>"+jsonData.name+"</h3>";
		markup +="<h4>Price"+jsonData.currency+"&nbsp;"+jsonData.price+"</h4>";
		markup +="<p>"+jsonData.desc+"</p>";
		markup += "<form class=\"tsm-form form-horizontal\" method=\"post\">";
		markup +="<input name=\"product_id\" type=\"hidden\" value=\"" +id+"\">";
		markup +=" <button class='btn btn-success btn-lg btn-block font-bold mt-4' type=\"submit\" >Satın Al</button>";
		markup +="</form>";
		markup +="</div></div>";
		jQuery('#tsm-buy-dialog .modal-body').html(markup);
		}else{
		 jQuery('#tsm-buy-dialog .modal-body').html("<div class='alert alert-danger'>"+jsonData.error+"</div>");
		return false;
		}
		});

return false;
};
jQuery.fn.tsmBuy = function(){
// extract previously saved sitepath
 var sitepath = jQuery("#tsm-site-path").html();
 jQuery('#tsm-buy-dialog .modal-title').html("Satın Al");
jQuery('#tsm-buy-dialog .modal-body').html("<div class='text-center'><img src='"+sitepath + "/system/assets/uploads/img/loadingAnimation.gif' /></div>");
	jQuery('#tsm-buy-dialog').modal();
	var form = jQuery(this);
	var serialized = jQuery(form).serialize();
	jQuery.ajax({
					type:"POST",
					url: sitepath + "/system/assets/ajax/buy.php",
					data:serialized ,
					success: function(html){
					jQuery('#tsm-buy-dialog .modal-body').html(html);
					jQuery.getScript(sitepath + '/system/tsm.js');
					}
				});
return false;
};