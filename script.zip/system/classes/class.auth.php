<?php
require_once('class.phpmailer.php');
require_once('class.smtp.php');
require_once('class.pop3.php');

class Auth{
	
	var $error = '';
	var $msg = '';
	
	private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
	 
public function all(){ //Get all admin data
    global $crypt;

    	$result = $this->db->prepare("SELECT * FROM  tsm_admins WHERE active = 1");
		$result->execute();
		$admins = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $row['id']= $crypt->encrypt($row['id'],'ADMIN');
        $admins[]=$row;
	    }
	    return $admins;

}

public function is_admin($id){
	global $crypt;
	
		$id = $crypt->decrypt($id,'ADMIN');
		$result = $this->db->prepare("SELECT id FROM  tsm_admins WHERE id = ?");
		$result->execute(array($id));
		if ($result->fetchColumn() == 1){
    		return true;
		}
		$this->error = "No such customer exists";
		return false;
		
}
	
public function details($id){
	global $crypt;
	
		if($this->is_admin($id)){
		$id = $crypt->decrypt($id,'ADMIN');
        $result = $this->db->prepare("SELECT * FROM  tsm_admins WHERE id = ?");
        $result->execute(array($id));
		while($result = $result->fetch(PDO::FETCH_ASSOC)) {
		$result['id'] = $crypt->encrypt($result['id'],'ADMIN');
	    $result['password'] = md5($result['password']);
		return $result;
		}
		}
        $this->error = "Böyle bir kullanıcı kayıtlı değil";
		return false;
		
}

public function update($id,$col,$value){
    global $crypt;

        if($this->is_admin($id)){
        $id = $crypt->decrypt($id,'ADMIN');
        $result = $this->db->prepare("UPDATE tsm_admins SET `$col` = '$value' WHERE id = ?");
        $result->execute(array($id));
        if($result){
        return true;
        }
        $this->error = "Hata Oluştu";
        return false;
        }
        $this->error = "Böyle bir kullanıcı kayıtlı değil";
	return false;
		
}

public function is_loggedin(){
		
		if(isset($_SESSION['auth']) && isset($_SESSION['curr_user']) && isset($_SESSION['token'])){
		$checksum = md5($_SESSION['curr_user'] . 'tsm' . date('ymd'));
		if($checksum == $_SESSION['token']){
		return true;
		}
		return false;
		}
		return false;	
		
}

public function updateve($email,$col,$value){
    global $crypt;
    
    $email = trim($email);
        $result = $this->db->prepare("UPDATE tsm_admins SET `$col` = '$value' WHERE email = ?");
		$result->execute(array($email));
        if($result){
        return true;
        }
        $this->error = "Hata Oluştu";
        return false;
		
}

public function login($email,$password){
    global $crypt;

	    $password = md5($password);
	    $result = $this->db->prepare("SELECT * FROM  tsm_admins WHERE active = 1  AND email = '$email' AND password = '$password'");
	    $result->execute();
		while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $row['id']= $crypt->encrypt($row['id'],'ADMIN');
	    echo $row['id'];
		$_SESSION['uid'] = $row['id'];
		$_SESSION['curr_user'] = $row['email'];
		$_SESSION['token'] = md5($row['email'] . 'tsm' . date('ymd'));
		$_SESSION['auth'] = true;
		return true;
		}
	    $this->error = 'Geçersiz kullanıcı adı / Şifre';
    	return false;

}
public function emailcontrol($email){
	global $crypt;
	
	$result = $this->db->prepare("SELECT * FROM  tsm_admins WHERE active = 1  AND email = '$email'");
		$result->execute();
		if ($result->fetchColumn() >= 1){
    	return true;
		}
		$this->error = "Geçersiz Email adresi";
		return false;
}

public function logout(){
    
	    session_destroy();
    	header("location: login.php");
	    exit;
	    
}	

public function add($email,$password){
$smtp_auth   = $setting['smtp_auth'];
$smtp_secure = $setting['smtp_secure'];
$smtp_host   = $setting['smtp_host'];
$smtp_port   = $setting['smtp_port'];
$smtp_user   = $setting['smtp_user'];
$smtp_pass   = $setting['smtp_pass'];


		if($this->is_new_admin($email)){
			
		$password = base64_encode($password);
		$add = $this->db->prepare("INSERT INTO tsm_admins (`id`, `email`, `password`,`active`) VALUES (NULL, '$email' , '$password', '1')");
		$add->execute();
	    if($add){
	    $headers  = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=utf-8\n";
        $headers .= "From: ".$setting['site_name']." <noreply@".$_SERVER['HTTP_HOST']."> \n";
	    $subject = "Account Signup Information";
	    $message = "<h4>Hi, ".$email ."</h4><br />";
	    $message .= "Congratulations, you have successfully registered at ".$_SERVER['HTTP_HOST']." with this email id. <br />";
	    $message .= "&copy; ".$_SERVER['HTTP_HOST'];
		
		
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = $smtp_auth; // authentication enabled
$mail->SMTPSecure = $smtp_secure; // secure transfer enabled REQUIRED for GMail
$mail->Host = $smtp_host;
$mail->Port = $smtp_port; // or 587
$mail->IsHTML(true);
$mail->SetLanguage('en', 'phpmailer/language');
$mail->CharSet  ='utf-8';

$mail->Username = $smtp_user; // Mail adresi
$mail->Password = $smtp_pass; // Parola
$mail->SetFrom($smtp_user, $setting['homepage_header']); // Mail adresi

$mail->AddAddress($email); // Gönderilecek kişi

$mail->Subject = $subject;
$mail->Body = $message;
if(!$mail->Send()){
        echo '<span class="text-danger">Mailer Error: '.$mail->ErrorInfo.'</span>';
} else {
	    $this->msg = "Registered successfully";
		return $this->db->lastInsertId(); 
		}
		$this->error = "Hata oluştu, tekrar deneyiniz.";
		return false;
	    }
	    $this->error = "Bu admin zaten mevcut";
	    return false;
	    
}
}

public function is_new_admin($email){
	
	    $result = $this->db->prepare("SELECT id FROM  tsm_admins WHERE email = ?");
        $result->execute(array($email));
        if ($result->fetchColumn() == 0){
        return true;
        }
		$this->error = "Bu kullanıcı zaten kayıtlı";
		return false;
		
}

public function get_pass($email){
    
		$email = trim($email);
		$result = $this->db->prepare("SELECT password FROM  tsm_admins WHERE email = ?");
		$result->execute(array($email));
		while($row = $result->fetch(PDO::FETCH_ASSOC)){
        return base64_decode($row['password']);	
        }	
	    $this->error = "Kullanıcı bulunamadı";
		return false;
        }
        
}

?>