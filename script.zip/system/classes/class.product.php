<?php 

class Item{
	var $error = false;
	var $msg = false;
	
		private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
	
	public function all(){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 ORDER BY `id` DESC");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
		return $products;
		}
		
		public function getProducts($start,$total){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 OR active = 2 ORDER BY `id` DESC LIMIT $start , $total");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getCProducts($id = null, $cat_id = null){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND cat_id = '$cat_id' ORDER BY `id` DESC");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getCSProducts($id = null, $sub_id = null){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND subc_id = '$sub_id' ORDER BY `id` DESC");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getFeaturedProducts(){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND featured = 1 ORDER BY `id` LIMIT 4");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getPopularProducts(){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND sales > 0 ORDER BY sales ASC,views DESC LIMIT 8");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getNewProducts(){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 ORDER BY `id` DESC LIMIT 12");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getSimilarProducts($cat_id){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND cat_id = $cat_id LIMIT 4");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

		public function getFreeProducts(){
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 AND free = 1 ORDER BY `id` DESC LIMIT 4");
    $result->execute();
	$products = array();
	while($row = $result->fetch(PDO::FETCH_ASSOC)) {
		$products[]=$row;
		}
	return $products;
}

	public function countAll(){
	    
	    $result = $this->db->prepare("SELECT count(*) FROM  tsm_products WHERE active = 1 ORDER BY `id` DESC");
        $result->execute();
		$products = $result->fetchColumn();
	    return $products;
}	

	public function countFree(){
	    
	    $result = $this->db->prepare("SELECT count(*) FROM  tsm_products WHERE free = 1 AND active = 1");
        $result->execute();
		$products = $result->fetchColumn();
	    return $products;
}	

	public function countPopular(){
	    
	    $result = $this->db->prepare("SELECT count(*) FROM  tsm_products WHERE sales > 0 AND active = 1");
        $result->execute();
		$products = $result->fetchColumn();
	    return $products;
}	


public function top(){
	
	$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE active = 1 ORDER BY `sales` DESC LIMIT 0 , 10");
		$result->execute();
	    $products = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
		$products[]=$row;
	    }	
	    return $products;
	
}

	public function is_product($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_products WHERE id = '$id' AND  active = 1");
		$result->execute();
		
		if ($result){
    	return true;
		}
		$this->error = "Ürün bulunamadı";
		return false;
		
	}
	
	public function details($id){
		if($this->is_product($id)){
			
			$result = $this->db->prepare("SELECT * FROM  tsm_products WHERE id = :id");
          $result->bindParam(':id', $id);
		$result->execute();
			
			while($result=$result->fetch(PDO::FETCH_ASSOC)){
			return $result;
			}
			}
		return false;
	}
		public function catdetails($id){
			
			$result = $this->db->prepare("SELECT * FROM  tsm_categories WHERE id = :id");
          $result->bindParam(':id', $id);
		$result->execute();
			
			while($result=$result->fetch(PDO::FETCH_ASSOC)){
			return $result;
			}
	}
			public function scatdetails($id){
			
			$result = $this->db->prepare("SELECT * FROM  tsm_subcat WHERE id = :id");
          $result->bindParam(':id', $id);
		$result->execute();
			
			while($result=$result->fetch(PDO::FETCH_ASSOC)){
			return $result;
			}
	}
	
	public function add_sale($id){
		if($this->is_product($id)){
		$sales = $this->details($id);
		$sales = $sales['sales'] + 1;
		$update = $this->db->prepare("UPDATE tsm_products  SET `sales` = '$sales' WHERE id ='$id'");
    		$update->execute();
		if($update){
		return true;
		}
		return false;
		}
	}
	
	public function remove($id){
	$detail = $this->details($id);
		if($this->is_product($id)){
		    
		$update = $this->db->prepare("UPDATE tsm_products  SET `active` = '0' WHERE id ='$id'");
		$update->execute();
	if($update){
		$this->msg = "Ürün silindi";
		return true;
	}
	$this->error = "Ürün silinemedi";
	return false;
	}
	$this->error = "Ürün silinemedi";
	return false;
	}
//Categories start here	
	public function countAllCat(){
	    
	    $result = $this->db->prepare("SELECT count(*) FROM  tsm_categories ORDER BY `id` DESC");
        $result->execute();
		$category = $result->fetchColumn();
	    return $category;
}

	public function countAllSCat(){
	    
	    $result = $this->db->prepare("SELECT count(*) FROM  tsm_subcat ORDER BY `id` DESC");
        $result->execute();
		$category = $result->fetchColumn();
	    return $category;
}	

public function countAllCatDeleted(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_categories WHERE active = 0");
		$result->execute();
		$categories = $result->fetchColumn();
	    return $categories;
	
}

public function countAllCatSDeleted(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_subcat WHERE active = 0");
		$result->execute();
		$categories = $result->fetchColumn();
	    return $categories;
	
}

public function get_categories($id = null){
   
   $query = $this->db->prepare("SELECT * FROM `tsm_categories` WHERE active = 1  ORDER BY `id` ASC");
   $query->execute();
   $categories = array();
   while($row=$query->fetch(PDO::FETCH_ASSOC)){
    $categories[] = $row;

   }
   
   return $categories;
}

public function get_scategories($id = null){
   
   $query = $this->db->prepare("SELECT * FROM `tsm_subcat` WHERE active = 1  ORDER BY `id` ASC");
   $query->execute();
   $categories = array();
   while($row=$query->fetch(PDO::FETCH_ASSOC)){
    $categories[] = $row;

   }
   
   return $categories;
}

public function dispsubcategories($parent_id) {

$query = $this->db->prepare("SELECT * FROM tsm_subcat WHERE active = 1 AND cat_id = :parent_id ORDER BY `id` ASC");
$query->bindParam(':parent_id', $parent_id);
   $query->execute();
$scategories = array();
		 while($row=$query->fetch(PDO::FETCH_ASSOC)){
		     $scategories[] = $row;
		}
		  return $scategories;
	}

public function getReviews($id){
   
   $query = $this->db->prepare("SELECT * FROM `tsm_reviews` WHERE product_id = $id AND status = 1 ORDER BY `id` DESC");
   $query->execute();
   $reviews = array();
   while($row=$query->fetch(PDO::FETCH_ASSOC)){
    $reviews[] = $row;
   }
   
   return $reviews;
}

public function sumReviews($id){
	global $crypt;
	
		$result = $this->db->prepare("SELECT SUM(rating) as ratingsum FROM  tsm_reviews WHERE product_id = $id AND status = 1");
		$result->execute();
	
	    $rows = $result->fetchColumn();
	    //return money_format("%.2n", $rows['SUM(price)']);
	    return $rows;
	
}	

public function getQuestions($id){
   
   $query = $this->db->prepare("SELECT * FROM `tsm_questions` WHERE product_id = $id AND status = 1 ORDER BY `id` DESC");
   $query->execute();
   $questions = array();
   while($row=$query->fetch(PDO::FETCH_ASSOC)){
    $questions[] = $row;
   }
   
   return $questions;
}

	public function countQuestion($pid){
	    
	    $result = $this->db->prepare("SELECT count(id) FROM  tsm_questions WHERE product_id = ? AND status = 1");
        $result->execute(array($pid));
		$questions = $result->fetchColumn();
	    return $questions;
}

	public function addquestion($pid,$uid,$question){
		$question = trim($question);
	    if(empty($question)){
		$this->error = 'Sorunuzu yazınız';
		return false;
		}
		$qdate = date("Y-m-d");
		$add = $this->db->prepare("INSERT INTO tsm_questions (`product_id`, `user_id`, `question`, `qdate`, `answer`, `adate`, `status`) VALUES ('$pid', '$uid', '$question', '$qdate', '', '', '1')");
		$add->execute();
	    	if($add){
		$this->msg = "Soru gönderildi";
		return true;
		}	
		$this->error = 'Soru gönderilemedi';
		return false;	
		
}

	public function addanswer($id,$answer){
		$answer = trim($answer);
	    if(empty($answer)){
		$this->error = 'Cevap yazınız';
		return false;
		}
		$adate = date("Y-m-d");
		$update = $this->db->prepare("UPDATE tsm_questions  SET `answer` = '$answer', `adate` = '$adate' WHERE id ='$id'");
    		$update->execute();
		if($update){
		return true;
		}
		return false;
	}

public function is_alreadyadd($userID,$productID){

		$result = $this->db->prepare("SELECT * FROM `tsm_reviews` WHERE user_id = '$userID' AND product_id = '$productID' AND status = '1'");
		$result->execute();
		if ($result->fetchColumn() >= 1){
    	return true;
		}
		$this->error = "Yorum bulunamadı";
		return false;
	
}

	public function countReview($pid){
	    
	    $result = $this->db->prepare("SELECT count(id) FROM  tsm_reviews WHERE product_id = ? AND status = 1");
        $result->execute(array($pid));
		$reviews = $result->fetchColumn();
	    return $reviews;
}

	public function addreview($pid,$uid,$message1,$rating){
    
		$message1 = trim($message1);
	    if(empty($message1)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$add = $this->db->prepare("INSERT INTO tsm_reviews (`product_id`, `user_id`, `review`, `rating`, `status`) VALUES ('$pid', '$uid', '$message1', '$rating', '1')");
		$add->execute();
	    	if($add){
		$this->msg = "Yorum gönderildi";
		return true;
		}	
		$this->error = 'Yorum gönderilemedi';
		return false;	
		
}
	
	public function addcat($name){
		$name = trim($name);
	    if(empty($name)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$add = $this->db->prepare("INSERT INTO tsm_categories (`id`, `name`, `active`) VALUES (NULL, :name, '1')");
      	$add->bindParam(':name', $name);
		$add->execute();
	    	if($add){
		$this->msg = "Kategori eklendi";
		return true;
		}	
		$this->error = 'Kategori eklenemedi';
		return false;	
		
}

	public function addscat($name,$cid){
    if (!preg_match("/^[a-zA-Z0-9 ]*$/",$name)) {
      $this->error = 'ALT KATEGORİ ADI: Özel karakter kullanmayınız.';
		return false;
	}
		$name = trim($name);
	    if(empty($name)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$add = $this->db->prepare("INSERT INTO tsm_subcat (`name`, `cat_id`, `active`) VALUES (:name, :cid, '1')");
      	$add->bindParam(':name', $name);
      	$add->bindParam(':cid', $cid);
		$add->execute();
	    	if($add){
		$this->msg = "Alt kategori eklendi";
		return true;
		}	
		$this->error = 'Alt kategori eklenemedi';
		return false;	
		
}

public function updatecat($id,$name){
    if (!preg_match("/^[a-zA-Z0-9 ]*$/",$name)) {
      $this->error = 'KATEGORİ ADI: Özel karakter kullanmayınız.';
		return false;
	}
		$name = trim($name);
		if($this->is_cat($id)){
		if(empty($name)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$update = $this->db->prepare("UPDATE tsm_categories  SET `name` = :name WHERE id = :id");
        $update->bindParam(':name', $name);
        $update->bindParam(':id', $id);
		$update->execute();
		if($update){
		$this->msg = "Kategori güncellendi";
		return true;
	}
	    	$this->error = "Kategori güncellenemedi";
	    	return false;
	    	}
    		$this->error = "Kategori güncellenemedi";
	    	return false;

}

	public function is_cat($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_categories WHERE id = '$id' AND  active = 1");
		$result->execute();
		
		if ($result){
    	return true;
		}
		$this->error = "Kategori bulunamadı";
		return false;
		
	}
	
	public function updatescat($id,$name,$cid){
    if (!preg_match("/^[a-zA-Z0-9 ]*$/",$name)) {
      $this->error = 'ALT KATEGORİ ADI: Özel karakter kullanmayınız.';
		return false;
	}
		$name = trim($name);
		if($this->is_scat($id)){
		if(empty($name)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$update = $this->db->prepare("UPDATE tsm_subcat  SET `name` = :name, `cat_id` = :cid WHERE id = :id");
        $update->bindParam(':name', $name);
        $update->bindParam(':cid', $cid);
        $update->bindParam(':id', $id);
		$update->execute();
		if($update){
		$this->msg = "Alt kategori güncellendi";
		return true;
	}
	    	$this->error = "Alt kategori güncellenemedi";
	    	return false;
	    	}
    		$this->error = "Alt kategori güncellenemedi";
	    	return false;

}

	public function is_scat($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_subcat WHERE id = '$id' AND  active = 1");
		$result->execute();
		
		if ($result){
    	return true;
		}
		$this->error = "Alt kategori bulunamadı";
		return false;
		
	}
	
public function removecat($id){
    
		if($this->is_cat($id)){
		$update = $this->db->prepare("UPDATE tsm_categories  SET `active` = '0' WHERE id ='$id'");
		$update->execute();
								
	    if($update){
		$this->msg = "Kategori silindi";
		return true;
	    }
	    $this->error = "Kategori silinemedi";
	    return false;
	    }
	    $this->error = "Kategori silinemedi";
	    return false;
	    
}	
public function removescat($id){
    
		if($this->is_cat($id)){
		$update = $this->db->prepare("UPDATE tsm_subcat  SET `active` = '0' WHERE id ='$id'");
		$update->execute();
								
	    if($update){
		$this->msg = "Alt kategori silindi";
		return true;
	    }
	    $this->error = "Alt kategori silinemedi";
	    return false;
	    }
	    $this->error = "Alt kategori silinemedi";
	    return false;
	    
}

public function getDeletedCategories($start,$total){
	
		$result = $this->db->prepare("SELECT * FROM  tsm_categories WHERE active = 0 ORDER BY `id` DESC LIMIT $start , $total");
		$result->execute();
		$categories = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $categories[]=$row;
	    }
	    return $categories;
	    
}

public function getDeletedSubCategories(){
	
		$result = $this->db->prepare("SELECT * FROM  tsm_subcat WHERE active = 0 ORDER BY `id`");
		$result->execute();
		$categories = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $categories[]=$row;
	    }
	    return $categories;
	    
}

public function restorecat($id){
		
		$update = $this->db->prepare("UPDATE tsm_categories  SET `active` = '1' WHERE id ='$id'");
		$update->execute();
								
	    if($update){
		$this->msg = "Kategori geri alındı";
		return true;
	    }
	    $this->error = "Kategori geri alınamadı";
	    return false;
	    
}

public function restorescat($id){
		
		$update = $this->db->prepare("UPDATE tsm_subcat  SET `active` = '1' WHERE id ='$id'");
		$update->execute();
								
	    if($update){
		$this->msg = "Alt kategori geri alındı";
		return true;
	    }
	    $this->error = "Alt kategori geri alınamadı";
	    return false;
	    
}
	
}
?>