<?php 

class Coupon{
	var $error = '';
	var $msg = '';
		private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}

public function all(){
	    
	    $result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE active = 1");
		$result->execute();
		$coupons = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $coupons[]=$row;
	    }
	    return $coupons;
	    
}

public function getCoupons($start,$total){

		$result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE active = 1 ORDER BY `id` DESC LIMIT $start , $total");
		$result->execute();
		$coupons = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $coupons[]=$row;
	    }
	    return $coupons;
	
}

public function countAll(){
    
		$result = $this->db->prepare("SELECT count(*) FROM  tsm_coupons WHERE active = 1");
		$result->execute();
		$coupons = $result->fetchColumn();
	    return $coupons;
	    
}

public function is_coupon($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_coupons WHERE id = ? AND  active = 1");
		$result->execute(array($id));
		if ($result){
    	return true;
		}
		$this->error = "No such coupon exists";
		return false;
		
}
		
public function is_new($code){
    
		$result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE code = :code");
  		$result->bindParam(':code', $code);
		$result->execute();
		if ($result->fetchColumn() == 0){
    		return true;
		}
		$this->error = "Bu kod '$code' zaten mevcut.";
		return false;
		
}

public function details($id){
    
		if($this->is_coupon($id)){
        $result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE id = :id");
        $result->bindParam(':id', $id);
        $result->execute();
		while($result = $result->fetch(PDO::FETCH_ASSOC)) {
		return $result;
		}
		}
		return false;
		
}

public function getDetails($code){
		
		$result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE code = :code");
  		$result->bindParam(':code', $code);
		$result->execute();
	    while($result=$result->fetch(PDO::FETCH_ASSOC)){
        return $result;
	    }
	    return false;
		
}

public function add($code,$off,$type,$min){
		$code = trim($code);
		$code = strtoupper($code);
		$off = trim($off);
		$type = trim($type);
		$min = trim($min);
	    if(empty($code) || empty($off)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		if(!is_numeric($off)){
		$this->error = 'Sadece Rakam';
		return false;
		}
		if(!is_numeric($type) || $type > 2 || $type < 1){
		$this->error = 'Geçersiz veri';
		return false;
		}
		if(!is_numeric($min)){
		$this->error = 'Sadece rakam';
		return false;
		}
		if($type == '1' && $off > 100){
		$this->error = 'Geçersiz indirim oranı';
		return false;
		}
		if($type == '2' && $off > $min){
		$this->error = 'Geçersiz indirim değeri';
		return false;
		}
		if($type == '2'){
		$off = number_format($off,2);
		}

		$add = $this->db->prepare("INSERT INTO tsm_coupons (`id`, `code`, `off`,`off_type`,`order_min`,`active`) VALUES (NULL, '$code' , '$off','$type','$min','1')");
		$add->execute();
	    	if($add){
		$this->msg = "Kupon eklendi";
		return true;
		}	
		$this->error = 'Kupon eklenemedi';
		return false;	
		
}
	
public function update($id,$code,$off,$type,$min){
		$code = trim($code);
		$code = strtoupper($code);
		$off = trim($off);
		$min = trim($min);
		if($this->is_coupon($id)){
		if(empty($code) || empty($off)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		
		if(!is_numeric($type) || $type > 2 || $type < 1){
		$this->error = 'Geçersiz değer';
		return false;
		}
		if(!is_numeric($off)){
		$this->error = 'Sadece rakam';
		return false;
		}
		if(!is_numeric($min)){
		$this->error = 'Sadece rakam';
		return false;
		}
		if($type == '1' && $off > 100){
		$this->error = 'Geçersiz indirim oranı';
		return false;
		}
		if($type == '2' && $off > $min){
		$this->error = 'Geçersiz indirim değeri';
		return false;
		}
		if($type == '2'){
		$off = number_format($off,2);
		}
		/*if(!$this->is_new($code)){
		return false;
		}*/
		
		$update = $this->db->prepare("UPDATE tsm_coupons  SET `code` = '$code',`off` = '$off',`off_type`= '$type',`order_min` = '$min' WHERE id ='$id'");
		$update->execute();

		if($update){
		$this->msg = "Kupon güncellendi";
		return true;
	}
	    	$this->error = "Kupon güncellenemedi";
	    	return false;
	    	}
    		$this->error = "Kupon güncellenemedi";
	    	return false;

}

public function remove($id){
    
		if($this->is_coupon($id)){
		$update = $this->db->prepare("UPDATE tsm_coupons  SET `active` = '0' WHERE id = :id");
        $update->bindParam(':id', $id);
		$update->execute();
								
	    if($update){
		$this->msg = "Kupon silindi";
		return true;
	    }
	    $this->error = "Kupon silinemedi";
	    return false;
	    }
	    $this->error = "Kupon silinemedi";
	    return false;
	    
}	

public function restore($id){
		
		$update = $this->db->prepare("UPDATE tsm_coupons  SET `active` = '1' WHERE id = :id");
  		$update->bindParam(':id', $id);
		$update->execute();
								
	    if($update){
		$this->msg = "Kupon geri alındı";
		return true;
	    }
	    $this->error = "Kupon geri alınamadı";
	    return false;
	    
}

public function getDeletedCoupons($start,$total){
	
		$result = $this->db->prepare("SELECT * FROM  tsm_coupons WHERE active = 0 ORDER BY `id` DESC LIMIT $start , $total");
		$result->execute();
		$coupons = array();
	    while($row=$result->fetch(PDO::FETCH_ASSOC)){
        $coupons[]=$row;
	    }
	    return $coupons;
	    
}

public function countAllDeleted(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_coupons WHERE active = 0");
		$result->execute();
		$coupons = $result->fetchColumn();
	    return $coupons;
	
}

}
?>