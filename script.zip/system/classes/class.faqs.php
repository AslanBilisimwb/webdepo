<?php 
class faqs{

private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}

	public function get_all_faqs(){

		$query = $this->db->prepare('SELECT * FROM tsm_faqs WHERE active = "1" order by id asc');
		$query->execute();

		return $query->fetchAll(PDO::FETCH_ASSOC);
	}

public function is_faqs($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_faqs WHERE id = ? AND  active = 1");
		$result->execute(array($id));
		if ($result){
    	return true;
		}
		$this->error = "SSS mevcut değil";
		return false;
		
}

	public function details($id){
		if($this->is_faqs($id)){
			
			$result = $this->db->prepare("SELECT * FROM  tsm_faqs WHERE id = ?");
		$result->execute(array($id));
			
			while($result=$result->fetch(PDO::FETCH_ASSOC)){
			return $result;
			}
			}
		return false;
	}

public function add($title,$content){
		$title = trim($title);
		$content = trim($content);
	    if(empty($title) || empty($content)){
		$this->error = 'Tüm alanları doldurun';
		return false;
		}
		$add = $this->db->prepare("INSERT INTO tsm_faqs (`title`, `content`, `active`) VALUES (:title, :content, '1')");
        $add->bindParam(':title', $title);
        $add->bindParam(':content', $content);
		$add->execute();
	    	if($add){
		$this->msg = "Soru eklendi";
		return true;
		}	
		$this->error = 'Soru eklenemedi';
		return false;	
		
}

public function remove($id){
    
		if($this->is_faqs($id)){
		$update = $this->db->prepare("UPDATE tsm_faqs SET `active` = '0' WHERE id = ?");
		$update->execute(array($id));
								
	    if($update){
		$this->msg = "SSS silindi";
		return true;
	    }
	    $this->error = "SSS silinemedi";
	    return false;
	    }
	    $this->error = "SSS silinemedi";
	    return false;
	    
}	

public function restore($id){
		
		$update = $this->db->prepare("UPDATE tsm_faqs SET `active` = '1' WHERE id = ?");
		$update->execute(array($id));
								
	    if($update){
		$this->msg = "SSS geri alındı";
		return true;
	    }
	    $this->error = "SSS geri alınamadı";
	    return false;
	    
}

public function updatefaqs($id,$title,$content){
		$title = trim($title);
		$content = trim($content);
		if($this->is_faqs($id)){
		if(empty($title) || empty($content)){
		$this->error = 'Please input all details';
		return false;
		}
		$update = $this->db->prepare("UPDATE tsm_faqs  SET title=:title,content=:content WHERE id=:id");
		$update->bindParam(':title', $title);
        $update->bindParam(':content', $content);
        $update->bindParam(':id', $id);
		$update->execute();
		if($update){
		$this->msg = "SSS düzenlendi";
		return true;
	}
	    	$this->error = "SSS düzenlenemedi";
	    	return false;
	    	}
    		$this->error = "SSS düzenlenemedi";
	    	return false;

}

public function getDeletedFaqs(){
	    
	    $query = $this->db->prepare("SELECT * FROM  tsm_faqs WHERE active = 0 ORDER BY `id` ASC");
		$query->execute();

		return $query->fetchAll(PDO::FETCH_ASSOC);
	    
}

public function countAllDeleted(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_faqs WHERE active = 0");
		$result->execute();
		$faqs = $result->fetchColumn();
	    return $faqs;
	
}
public function countAll(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_faqs WHERE active = 1");
		$result->execute();
		$faqs = $result->fetchColumn();
	    return $faqs;
	
}

}

?>