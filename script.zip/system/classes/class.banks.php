<?php 
class banks{

private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}

	public function get_all_banks(){

		$query = $this->db->prepare('SELECT * FROM tsm_banks WHERE active = "1" order by id asc');
		$query->execute();

		return $query->fetchAll(PDO::FETCH_ASSOC);
	}

public function is_banks($id){
		
		$result = $this->db->prepare("SELECT active FROM  tsm_banks WHERE id = ? AND  active = 1");
		$result->execute(array($id));
		if ($result){
    	return true;
		}
		$this->error = "Banka mevcut değil";
		return false;
		
}

	public function details($id){
		if($this->is_banks($id)){
			
			$result = $this->db->prepare("SELECT * FROM  tsm_banks WHERE id = ?");
		$result->execute(array($id));
			
			while($result=$result->fetch(PDO::FETCH_ASSOC)){
			return $result;
			}
			}
		return false;
	}

public function add($title,$content){
		$title = trim($title);
		$content = trim($content);
	    if(empty($title) || empty($content)){
		$this->error = 'Tüm alanları doldurunuz';
		return false;
		}
		$add = $this->db->prepare("INSERT INTO tsm_banks (`title`, `content`, `active`) VALUES (:title, :content, '1')");
        $add->bindParam(':title', $title);
        $add->bindParam(':content', $content);
		$add->execute();
	    	if($add){
		$this->msg = "Banka eklendi";
		return true;
		}	
		$this->error = 'Banka eklenemedi';
		return false;	
		
}

public function remove($id){
    
		if($this->is_banks($id)){
		$update = $this->db->prepare("UPDATE tsm_banks SET `active` = '0' WHERE id = ?");
		$update->execute(array($id));
								
	    if($update){
		$this->msg = "Banka silindi";
		return true;
	    }
	    $this->error = "Banka silinemedi";
	    return false;
	    }
	    $this->error = "Banka silinemedi";
	    return false;
	    
}	

public function restore($id){
		
		$update = $this->db->prepare("UPDATE tsm_banks SET `active` = '1' WHERE id = ?");
		$update->execute(array($id));
								
	    if($update){
		$this->msg = "Banka geri alındı";
		return true;
	    }
	    $this->error = "Banka geri alınamadı";
	    return false;
	    
}

public function updatebanks($id,$title,$content){
		$title = trim($title);
		$content = trim($content);
		if($this->is_banks($id)){
		if(empty($title) || empty($content)){
		$this->error = 'Please input all details';
		return false;
		}
		$update = $this->db->prepare("UPDATE tsm_banks  SET title=:title,content=:content WHERE id=:id");
		$update->bindParam(':title', $title);
        $update->bindParam(':content', $content);
        $update->bindParam(':id', $id);
		$update->execute();
		if($update){
		$this->msg = "Banka düzenlendi";
		return true;
	}
	    	$this->error = "Banka düzenlenemedi";
	    	return false;
	    	}
    		$this->error = "Banka düzenlenemedi";
	    	return false;

}

public function getDeletedbanks(){
	    
	    $query = $this->db->prepare("SELECT * FROM  tsm_banks WHERE active = 0 ORDER BY `id` ASC");
		$query->execute();

		return $query->fetchAll(PDO::FETCH_ASSOC);
	    
}

public function countAllDeleted(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_banks WHERE active = 0");
		$result->execute();
		$banks = $result->fetchColumn();
	    return $banks;
	
}
public function countAll(){
    
    	$result = $this->db->prepare("SELECT count(*) FROM  tsm_banks WHERE active = 1");
		$result->execute();
		$banks = $result->fetchColumn();
	    return $banks;
	
}

}

?>