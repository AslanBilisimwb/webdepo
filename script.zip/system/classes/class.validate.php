<?php

class Validate{
	var $error = '';
	public function email($email){
		$email = trim($email);
		if(strstr($email,'@') && strstr($email,'.')){
			$email = explode('@',$email);
			
			if(count($email)  == 2) { return true;}
			$this->error = 'Email geçerli değil';
			return false;
	}
	$this->error = 'Email geçerli değil';
			return false;
	}
public function password($passowrd){
	$passowrd = trim($passowrd);
	if(strlen($passowrd) >= 15 || strlen($passowrd) <= 5 )
		$this->error = 'Şifre 6-15 karakter arasında olmalı';
		return false;
	}
public function role($role){
	if($role == 1 || $role == 2){ return true;}
	$this->error = 'Geçersiz veri';
	return false;
	}


}

?>