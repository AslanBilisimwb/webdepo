<?php
class Search{
	
		 	private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
	
  public function search($keyword) {
	$exc = $this->db->prepare("SELECT * FROM  `tsm_products` WHERE `name` LIKE ? AND active = 1");
	$exc->execute( ['%' . $keyword . '%']);

        return $exc->fetchAll();
    }
  
  public function get($form) {
   	return (isset($_GET["{$form}"]) ? true : false);                                                
    }
}

?>