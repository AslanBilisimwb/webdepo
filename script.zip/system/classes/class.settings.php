<?php

class Settings
{
    var $error = false;
    var $msg = false;
    
    private $db;
    
    function __construct($DB_con)
    {
        $this->db = $DB_con;
    }
    
    public function get_all()
    {
        $setting = array();
        
        $result = $this->db->prepare("SELECT * FROM  tsm_settings");
        $result->execute();
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $setting[$row['setting']] = $row['value'];
        }
        return $setting;
    }
    public function update($newsettings)
    {
        foreach ($newsettings as $key => $value) {
            
            $update = $this->db->prepare("UPDATE tsm_settings  SET `value` = :value WHERE setting = :key");
          	$update->bindParam(':value', $value);
          	$update->bindParam(':key', $key);
            $update->execute();
            
            if (!$update) {
                $this->error = "Ayarlar kaydedilemedi";
                return false;
            }
        }
        if (empty($this->error)) {
            $this->msg = "Ayarlar kaydedildi";
            return true;
        }
    }
    
}

?>