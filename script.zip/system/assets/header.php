<!doctype html>
<html lang="tr">
  <head itemscope itemtype="http://schema.org/Product">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="robots" content="index,follow" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <script src="<?php echo $setting['website_url'];?>/system/assets/js/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo $setting['website_url'];?>/system/assets/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo $setting['website_url'];?>/system/assets/css/styles.css">
  <script src="<?php echo $setting['website_url'];?>/system/assets/js/bootstrap.bundle.min.js"></script>
  <script defer src="<?php echo $setting['website_url'];?>/system/assets/js/all.js"></script>
  <script src="<?php echo $setting['website_url'];?>/system/tsm.js"></script>
  <link rel="icon" type="image/png" href="<?php echo $setting['website_url'].'/system/assets/uploads/img/'.$setting['site_favicon']; ?>">
  <meta name="author" content="ZodiaxWeb">
  <meta itemprop="name" content="<?php echo $setting['homepage_header'];?>">
  <meta itemprop="url" content="<?php echo $setting['website_url'];?>">
  <meta itemprop="description" content="<?php echo $setting['homepage_subheader'];?>">
  <meta itemprop="image" content="<?php echo $setting['website_url'].'/system/assets/uploads/img/'.$setting['site_favicon']; ?>">
  <meta name="twitter:title" content="<?php echo $setting['site_name'];?>">
  <meta name="twitter:image" content="<?php echo $setting['website_url'].'/system/assets/uploads/img/'.$setting['site_favicon']; ?>">
  <meta property="og:title" content="<?php echo $setting['site_name'];?>">
  <meta property="og:url" content="<?php echo $setting['website_url'];?>">
  <meta property="og:site_name" content="<?php echo $setting['site_name'];?>">
  <meta property="og:image" content="<?php echo $setting['website_url'].'/system/assets/uploads/img/'.$setting['site_favicon']; ?>">
  <title><?php echo $pageTitle . " | " . $setting['site_name']; ?></title>
  <script>
    $(document).ready(function() {
      $('[data-toggle="tooltip"]').tooltip();
    });
  </script>
  </head>
  <body class="homepage">
<?php if(!empty($setting['global_message'])){ ?>
<div class="alert box-shadow text-center alert-<?php echo $setting['alert_type'];?> alert-dismissible fade show mb-0 rounded-0" role="alert"> <?php echo $setting['global_message'];?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
  </div>
<?php } else{?>
<?php } ?>
<header class="box-shadow1 fixed-top">
    <nav class="navbar p-0 navbar-expand-lg navbar-dark bg-dark1">
    <div class="container"> <a class="navbar-brand nav-m mr-5" href="<?php echo $setting['website_url'];?>">
      <?php if(empty($setting['site_logo'])){ ?>
      <?php echo $setting['site_name'];?>
      <?php } else{?>
      <img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="35" alt="<?php echo $setting['site_name'];?> - <?php echo $setting['homepage_subheader'];?>" title="<?php echo $setting['site_name'];?> - <?php echo $setting['homepage_subheader'];?>">
      <?php } ?>
      </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent1">
        <ul class="navbar-nav darkernavhover mr-auto">
            <li class="nav-item"> <a class="nav-link" href="<?php echo $setting['website_url'];?>/free/">Ücretsiz Ürünler</a> </li>
            <?php if($user->is_loggedin()){ ?>
            <li class="nav-item"> <a class="nav-link" href="<?php echo $setting['website_url'];?>/user/faq.php">SSS</a> </li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo $setting['website_url'];?>/user/news.php">Haberler</a> </li>
            <li class="nav-item"> <a class="nav-link" href="<?php echo $setting['website_url'];?>/user/contact.php">İletişim</a> </li>
            <?php } ?>
          </ul>
        <?php if($user->is_loggedin()){ ?>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Merhaba, <?php echo $userDetails['fname'];?> <span class="badge badge-warning"><?php echo $setting['currency_sym'] .  $userDetails['balance'];?></span> </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink"> <a class="dropdown-item" href="<?php echo $setting['website_url'];?>/user/"><i class="far fa-address-card"></i> Genel Görünüm</a> <a class="dropdown-item" href="<?php echo $setting['website_url'];?>/user/downloads.php"><i class="fas fa-cloud-download-alt"></i> Aldıklarım</a> <a href="<?php echo $setting['website_url'];?>/user/news.php" class="dropdown-item"><i class="far fa-newspaper"></i> Haberler</a> <a class="dropdown-item" href="<?php echo $setting['website_url'];?>/user/login.php?logout"><i class="fas fa-sign-out-alt"></i> Çıkış</a> </div>
          </li>
          </ul>
        <?php } else{ ?>
        <a href="<?php echo $setting['website_url'];?>/user/" class="btn btn-outline-warning mr-2 btn-sm">Giriş</a> <a href="<?php echo $setting['website_url'];?>/user/register.php" class="btn btn-outline-warning btn-sm">Kayıt</a>
        <?php } ?>
      </div>
      </div>
  </nav>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2" aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent2">
        <ul class="navbar-nav lightnavhover mr-auto">
            <?php
$category = $product->get_categories();
foreach($category as $cat) {
?>
            <li class="nav-item dropdown"> <a class="nav-link dropdown-toggle" href="<?php echo $setting['website_url']; ?>/category/<?php echo $cat['id']; ?>/" id="navbarDropdown<?php echo $cat['id']; ?>"> <?php echo $cat['name']; ?> </a>
            <div class="dropdown-menu box-shadow1" aria-labelledby="navbarDropdown<?php echo $cat['id']; ?>">
                <?php $subcat = $product->dispsubcategories($cat['id']); foreach($subcat as $scat) { ?>
                <a class="dropdown-item" href="<?php echo $setting['website_url']; ?>/subcat/<?php echo $scat['id']; ?>/"><?php echo $scat['name']; ?></a>
                <?php } ?>
              </div>
          </li>
            <?php } ?>
          </ul>
        <form action="<?php echo htmlspecialchars('../search.php');?>" method="GET" class="form-inline my-2 my-lg-0">
            <div class="input-group mb-0">
            <input name="key" minlength="3" required type="text" class="form-control form-control-sm header-search" placeholder="Arama yap..." aria-label="Arama yap...">
            <div class="input-group-append">
                <button class="btn header-searchcustombtn btn-sm btn-warning" type="submit"><i class="fas fa-search"></i></button>
              </div>
          </div>
          </form>
      </div>
      </div>
  </nav>
  </header>
