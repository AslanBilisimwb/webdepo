<?php
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
require_once('../../config-user.php');
require_once('../../classes/class.phpmailer.php');
require_once('../../classes/class.smtp.php');
require_once('../../classes/class.pop3.php');
if(empty($_POST['message']))
{
	echo '<div class="ui error visible message"><p>Lütfen sorunuzu yazın!</p></div>';
	die();
}
$productid = $_POST['pid'];
$uid = $_POST['uid'];
$username = $_POST['username'];
$name = $_POST['name'];
$email = $_POST['email'];
$question = $_POST['message'];
$smtp_auth   = $setting['smtp_auth'];
$smtp_secure = $setting['smtp_secure'];
$smtp_host   = $setting['smtp_host'];
$smtp_port   = $setting['smtp_port'];
$smtp_user   = $setting['smtp_user'];
$smtp_pass   = $setting['smtp_pass'];
	$subject = 'Website ürün hakkında soru - '.$_POST['subject'].'';
	$message = '<html>
         <head>
           <meta charset="utf-8" />
         </head>
         <body>
           <font color="#303030";>
             <div align="left">
               <table width="500px">
                 <tr>
                   <td>
                   <div align="center"><img src="'.$setting['website_url']."/system/assets/uploads/img/".$setting['site_logo'].'" width="300"></div><br>
                     <div align="left"><font size="4">Merhaba, <b>Admin</b>!</font></div><br>
                     <div align="left"><font size="2">Aşağıdaki kullanıcının ürün hakkında sorusu var!</font></div><br>
                     <div align="left">Kullanıcı Adı: <b>'.$username.'</b></div>
                     <div align="left">İsim: <b>'.$name.'</b></div>
                     <div align="left">Email: <b>'.$email.'</b></div><hr>
                     <div align="left">Konu: <b>'.$subject.'</b></div><hr>
                     <div align="left">Soru: <b>'.$question.'</b></div><hr>
                   </td>
                 </tr>
                 <br><br>
                 <tr>
                   <td align="left">
                     <font size="2">
                       Copyright &copy; '.$setting['site_name'].'
                     </font>
                   </td>
                 </tr>
               </table>
             </div>
           </font>
         </body>
         </html>';

$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = $smtp_auth; // authentication enabled
$mail->SMTPSecure = $smtp_secure; // secure transfer enabled REQUIRED for GMail
$mail->Host = $smtp_host;
$mail->Port = $smtp_port; // or 587
$mail->IsHTML(true);
$mail->SetLanguage('en', 'phpmailer/language');
$mail->CharSet  ='utf-8';

$mail->Username = $smtp_user; // Mail adresi
$mail->Password = $smtp_pass; // Parola
$mail->SetFrom($smtp_user, $setting['homepage_header']); // Mail adresi

$mail->AddAddress($smtp_user); // Gönderilecek kişi

$mail->Subject = $subject;
$mail->Body = $message;
$result = $product->addquestion($productid,$uid,$question);
if(!$mail->Send()){
                echo '<span class="text-danger">Mailer Error: '.$mail->ErrorInfo.'</span>';
} else {
                echo '<span class="text-success">Sorunuz gönderildi... Teşekkürler!</span>';
}
}
?>
