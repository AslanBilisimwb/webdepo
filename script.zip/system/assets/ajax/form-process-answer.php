<?php
if(isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
require_once('../../config-user.php');
if(isset($_POST['answer']) && !empty($_POST['answer']))
{
$id = $_POST['id'];
$answer = $_POST['answer'];
$result = $product->addanswer($id,$answer);
	if($result){
echo '<span class="text-success">Cevap gönderildi..!</span>';
}
}else{
	echo '<div class="ui error visible message"><p>Cevap alanını doldurun!</p></div>';
	die();
}
}
?>
