<?php
require_once('../../config-user.php');

$jsonReturn = array();
if(isset($_REQUEST['discountcoupon'])){
if(!empty($_REQUEST['discountcoupon'])){
$c = $_REQUEST['discountcoupon'];
$c = strtoupper($c);
	if($coupon->getDetails($c)){
	if($purchases->is_coupon_fresh($crypt->decrypt($_SESSION['uid'],'USER'),$c)){
	$_SESSION['discountcoupon'] = $c;
	}else{
	unset($_SESSION['discountcoupon']);
	$jsonReturn['error'] ='Bu kupon daha önce kullanılmıştı';
	}
	}else{
	unset($_SESSION['discountcoupon']);
	$jsonReturn['error'] ='Böyle bir kupon yok';
	}
	}else{
	unset($_SESSION['discountcoupon']);
	$jsonReturn['error'] ='Kupon kaldırıldı';
	}
}else{
	$jsonReturn['error'] ='Tanımsız işlem';
	}
$jsonReturn = json_encode($jsonReturn);
echo $jsonReturn;
?>