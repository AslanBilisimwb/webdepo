<?php
require_once('../../config-user.php');
require_once('../../gateways.php');
if(isset($_REQUEST['product_id'])){
	if(!empty($_REQUEST['product_id'])){
	$id = $_REQUEST['product_id'];
		if(isset($_SESSION['product'][$id])){
			$details = $_SESSION['product'][$id];
		}else{
			$details = $product->details($id);
			$_SESSION['product'][$id] = $details;
		}
	if($details){
	$base = $setting['website_url'];
	$name = $details['name'];
	$price = $details['price'];
		$success = false;
		$error = false;
	if($user->is_loggedin()){
	if($purchases->is_purchased($_SESSION['uid'],$id)){
	$error = "Bu ürünü daha önce almıştınız!";
	}
	}

	
	if(isset($_SESSION['discountcoupon'])){
$discountCoupon = $coupon->getDetails($_SESSION['discountcoupon']);
 if($price >= $discountCoupon['order_min']){
	$discount = $discountCoupon['off'];
 	if($discountCoupon['off_type'] == '1'){
	$discount = $price  * $discount / 100;
	}
	$price = $price - $discount;
 }
}

if(isset($_REQUEST['buy'])){
$error =false;
$error = ($userDetails['balance'] >= $price?false:"Ürünü almak için teyerli bakiyeniz yok!");
if(!$error){
$query_age = (isset($_SESSION['discountcoupon']) ? $_SESSION['discountcoupon'] : null);
$_SESSION['payment']['use_prepaid'] = true;
$trans_id = $transaction->add($_SESSION['uid'],$price,$id,'1','1');
$error = ($trans_id?false:$transaction->error);
$stockminus = $purchases->updatestock($id);
$buy = $purchases->add($_SESSION['uid'],$id,$trans_id,'1',$query_age);
$error = ($buy?false:$purchases->error);
unset($_SESSION['payment']);
unset($_SESSION['discountcoupon']);
}
if(isset($_REQUEST['ajax'])){
echo ($error ? $error:'success');
exit;
}
}
//////////
$crf = md5("TSM" . date('YMD'));
if(isset($_POST) && isset($_POST['pay_now'])){
$error = ($_POST['crf'] != $crf ? 'Invalid CRF':false);
$error = (empty($_POST['gateway'])? 'Ödeme metodu seçiniz':$error);

if(!$error){
$price = ($setting['txn'] > 0?$price + $setting['txn']:$price);
$_SESSION['payment']['product_id'] = $id;
$_SESSION['payment']['crf'] = $crf;
$_SESSION['payment']['amount'] = $price;
$_SESSION['payment']['gateway'] = $_POST['gateway'];
$_SESSION['payment']['detail'] = "Item Purchase";
$_SESSION['payment']['redir'] = "downloads.php";
$_SESSION['payment']['action'] = "purchase";


if(!isset($_REQUEST['ajax'])){
header('location:'.$setting['website_url'].'/user/process.php?action=process');
exit;
}
}
if(isset($_REQUEST['ajax'])){
echo ($error ? $error:'success');
exit;
}
}
///////////
	
	if($success){
	echo "<div class='alert alert-success  text-center'>$success</div>";
	} 
	if($error){
	echo "<div class='alert alert-danger text-center'>$error</div>";
	} ?>
	<div id="product_id_div" class="hide"><?php echo $id;?></div>
	<div class="row" id="tsm-buy-info">
	<div class="col-12">
	    
	    <ul class="list-group">
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <h4><?php echo $name; ?> <b>(<?php echo $setting['currency_sym'] . $price; ?>)</b></h4>
    <span><a href="#" class="btn btn-success" id="tsm-buy-btn"><span class="glyphicon glyphicon-ok-sign"></span> Satın Al</a></span>
  </li>
</ul>
	</div>
	</div> <!-- end .row !-->
	<?php if(!$user->is_loggedin()){?>
	<div class="row none" id="tsm-buy-now">
	<div class="col-12">
	<h3 class="no-topr">Giriş Yap</h3>
	<form class="form-horizontal" method="post" id="tsm-buy-login-form">
	<div class="form-group">
    <label class="col-md-4 control-label" for="inputEmail">Email</label>
    <div class="col-md-8">
      <input class="form-control"type="email" id="inputEmail" placeholder="Email" name="email">
    </div>
  </div>
  <div class="form-group">
    <label class="col-md-4 control-label" for="inputPassword" >Şifre</label>
    <div class="col-md-8">
      <input class="form-control"type="password" id="inputPassword" name="pwd" placeholder="Password">
    </div>
  </div>
  <div class="form-group">
        <div class="col-md-offset-4 col-md-8">
      <input class="form-control"type="hidden" name="login">
      <button type="submit" class="btn btn-success">Giriş Yap</button>
    </div>
  </div>  
  <div class="form-group">
    <div class="col-md-offset-4 col-md-8">
         <a class="btn btn-link" href="<?php echo $setting['website_url'];?>/user/register.php">Yeni Kayıt</a> <a class="btn btn-link tsm-show-forgot-pwd" href="#">Şifremi unuttum</a>
    </div>
  </div>
</form> </div> <!-- end .col-md-12 !-->
		</div> <!-- end .row #tsm-buy-login!-->
	
	<div class="row none" id="tsm-forgot-pwd">
		<div class="col-md-12">
	<h3 class="no-top text-center">Şifremi Sıfırla</h3>
	<form method="post" class="form-horizontal" action="<?php echo $setting['website_url'];?>/user/login.php">
		 	 <div class="form-group">
    <label class="col-md-4 control-label" for="email">Email</label>
    <div class="col-md-8">
	<input class="form-control"type="text" name="email" value="" id="email"><input class="form-control"type="hidden" name="action" value="recover">
	</div></div>
	<div class="form-group">
    <div class="col-md-offset-4 col-md-8">
	<button type="submit" name="submit" class="btn btn-danger" ><i class="icon-white icon-envelope"></i> Şifremi Sıfırla</button>
	</div>
	</div>
	</form><hr>
	<div class="text-center">Şifre Sıfırlansın mı? <a href="#" class="btn btn-success tsm-show-buy-login">Giriş yapınız</a></div>
	</div> <!-- end .col-md-12 !-->
		</div> <!-- end .row #tsm-forgot-pwd !-->
	
		<div class="row none" id="tsm-new-account">
		<div class="col-md-12">
		
	<h3 class="no-top text-center">Yeni Kayıt</h3>
<form class="form-horizontal"  method="post" id="tsm-new-user">

				 <div class="form-group">
    <label class="col-md-4 control-label" for="new-email">Email</label>
    <div class="col-md-8">

<input class="form-control"type="text" name="new_email" value="" id="new-email">
</div></div>


 <div class="form-group">
    <label class="col-md-4 control-label" for="new-pwd">Şifre</label>
    <div class="col-md-8">
<input class="form-control"type="password" name="new_pwd" value="" id="new-pwd"></div></div>

 <div class="form-group">
    <label class="col-md-4 control-label" for="new-pwd2">Şİfre Tekrar</label>
    <div class="col-md-8">
<input class="form-control"type="password" name="new_pwd2" value="" id="new-pwd2"></div></div> 
<div class="form-group">
  
    <div class="col-md-offset-4 col-md-8">
Kullanım şartlarını kabul ediyorsanız <b>"Kayıt Ol"</b>a tıklayınız.
</div>
</div>
 <div class="form-group">
      <div class="col-md-offset-4 col-md-8">
<button type="submit" name="submit" class="btn btn-info" >Kayıt Ol</button></div></div>
</form>  <hr>
<div class="text-center">Hesabınız var mı? <a href="#" class="btn btn-success tsm-show-buy-login">Giriş yapınız</a></div>
</div> <!-- end .col-md-12 !-->
		</div> <!-- end .row #tsm-new-account !-->
<?php
}else{
?>
<div class="row none" id="tsm-buy-now"><div class="col-md-12">
<h3 class="no-top text-center"><?php echo $name; ?> <b>(<?php echo $setting['currency_sym'] . $price; ?>)</b></h4>
<hr>
<div class="row text-center"><div class="col-md-6">
<button class="btn btn-success mb-2 <?php echo ($price > $userDetails['balance']?"disabled":"");?>" id="tsm-use-prepaid">Bakiye kullan</button><br>
<p>Şu anda <?php echo $setting['currency_sym'] . $userDetails['balance'];?> bakiyeniz var.<br />
Yüklemek için <a href="<?php echo $setting['website_url'] . "/user/credits.php";?>">buraya tıklayınız</a></p>
</div><div class="col-md-6">
        <button class="btn btn-success mb-2" id="tsm-pay-now">Kredi Kartı ile öde</button>
      <form class="form-horizontal none" method="post" action="#" id="tsm-pay-now-form">
        <input class="form-control" type="hidden" value="<?php echo $id;?>" name="product_id">
        <input class="form-control"type="hidden" value="<?php echo $crf;?>" name="crf">
<table class="table table-bordered gateways">
		
	<tr align="center">
	<td><input class="form-control" name="gateway" type="radio" name="gateway" value="shopier.php" id="shopier.php" checked="checked"><label class="text-center"for="shopier.php"><img src="<?php echo $base;?>/system/gateways/shopier_logo.png" width="80px"/></label></td>
    </tr>
</table>
<button class="btn btn-success" >Şimdi Öde</button></form>

</div>
</div><hr>
<div class="row text-center"><div class="col-md-12">
	<form class="form-inline" method="post" id="tsm-coupons-form">
    Kupon Kodu: <div class="form-group"  role="group"><input class="form-control" type="text" name="coupon" id="tsm-coupon-code" value="<?php if(isset($_SESSION['discountcoupon'])){ echo $_SESSION['discountcoupon'];} ?>"> 
    <button  type="submit" class='btn btn-info'><i class='glyphicon glyphicon-ok'></i> Kuponu uygula</button></div>
	<?php if(isset($_SESSION['discountcoupon'])){ ?> 
    <button   type='button' name='remove' id="tsm-coupon-remove" class="btn btn-danger"><i class='glyphicon glyphicon-remove-sign'></i> Kuponu kaldır</button>
	<?php } ?>
	</div>
	<?php if(isset($_SESSION['discountcoupon'])){ 
	$sym = ($discountCoupon['off_type'] == 1)? "%":$setting['currency_sym'];
	echo "<br><br><p>Kupon: ".$discountCoupon['off'] . $sym.", ". $setting['currency_sym']. $discountCoupon['order_min']." ve üstü alışverişlerde geçerlidir.</p>";
	} ?></form>

</div>
</div>
</div></div>
<?php
}
	exit;
	} // if_$details
	}
}
echo "<div class='row'><div class='alert alert-danger col-md-12 text-center'>Hata oluştu, tekrar deneyin</div>";
?>