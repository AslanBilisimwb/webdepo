<?php if($user->is_loggedin()){ ?>
<!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4 bg-dark text-white">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left mt-3 pb-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold"><a class="navbar-brand nav-m mr-5" href="<?php echo $setting['website_url'];?>"><?php if(empty($setting['site_logo'])){ ?><?php echo $setting['site_name'];?><?php } else{?><img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="35" alt="<?php echo $setting['site_name'];?> - <?php echo $setting['homepage_subheader'];?>"><?php } ?></a></h6>
        <p class="justify">Buraya, web siteniz hakkında kısa bilgiler girebilir, web sitenizi kısaca tanıtabilirsiniz. Arama motorları için faydalı olacaktır.
		</p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold text-warning">SAYFALAR</h6>
            <?php 
            $cpages = $pages->get_all_pages();
            foreach($cpages as $cpag) {
		  	?>
        <p>
          <a class="text-light" href="<?php echo $setting['website_url'];?>/page/<?php echo $cpag['id']; ?>/"><i class="fas fa-angle-double-right text-warning"></i> <?php echo $cpag['title']; ?></a>
        </p>
          <?php } ?>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold text-warning">KATEGORİLER</h6>
      <?php
$category = $product->get_categories();
foreach($category as $cat) {
	  ?>
        <p>
<a class="text-light" href="<?php echo $setting['website_url']; ?>/category/<?php echo $cat['id']; ?>/"><i class="fas fa-angle-double-right text-warning"></i> <?php echo $cat['name']; ?></a>        
		</p>
          <?php } ?>
      </div>

      <!-- Grid column -->
      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold text-warning">YARDIM</h6>
        <p>
        <a class="text-light" href="<?php echo $setting['website_url'];?>/user/contact.php"><i class="fas fa-angle-double-right text-warning"></i> İletişim</a>
      </p>
      <p>
        <a class="text-light" href="<?php echo $setting['website_url'];?>/user/faq.php"><i class="fas fa-angle-double-right text-warning"></i> SSS</a>
      </p>
      <p>
        <a class="text-light" href="<?php echo $setting['website_url'];?>/user/news.php"><i class="fas fa-angle-double-right text-warning"></i> Haberler</a>
	  </p>
      <p>
        <a class="text-light" href="<?php echo $setting['website_url'];?>/user/bank.php"><i class="fas fa-angle-double-right text-warning"></i> Banka Hesaplarımız</a>
	  </p>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Footer links -->

    <hr class="text-gray">

    <!-- Grid row -->
    <div class="row d-flex align-items-center">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left">© <?php echo date('Y'); ?> Copyright:
          <a class="text-warning" href="<?php echo $setting['website_url'];?>">
            <strong><?php echo $setting['site_name'];?></strong>
          </a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
          <?php if ($setting['facebook'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['facebook']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['twitter'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['twitter']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['instagram'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['instagram']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['googlep']  !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['googlep']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['linkedin'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['linkedin']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
          <?php }else {} ?>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->

<?php }else{ ?>
<!-- Footer -->
<footer class="page-footer font-small mdb-color pt-4 bg-dark text-white">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Footer links -->
    <div class="row text-center text-md-left mt-3 pb-3">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold"><a class="navbar-brand nav-m mr-5" href="<?php echo $setting['website_url'];?>"><?php if(empty($setting['site_logo'])){ ?><?php echo $setting['site_name'];?><?php } else{?><img src="<?php echo $setting['website_url']."/system/assets/uploads/img/".$setting['site_logo']; ?>" height="35" alt="<?php echo $setting['site_name'];?> - <?php echo $setting['homepage_subheader'];?>"><?php } ?></a></h6>
        <p class="justify">Buraya, web siteniz hakkında kısa bilgiler girebilir, web sitenizi kısaca tanıtabilirsiniz. Arama motorları için faydalı olacaktır.
		</p>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold text-warning">SAYFALAR</h6>
            <?php 
            $cpages = $pages->get_all_pages();
            foreach($cpages as $cpag) {
		  	?>
        <p>
          <a class="text-light" href="<?php echo $setting['website_url'];?>/page/<?php echo $cpag['id']; ?>/"><i class="fas fa-angle-double-right text-warning"></i> <?php echo $cpag['title']; ?></a>
        </p>
          <?php } ?>
      </div>
      <!-- Grid column -->

      <hr class="w-100 clearfix d-md-none">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h6 class="text-uppercase mb-4 font-weight-bold text-warning">KATEGORİLER</h6>
      <?php
$category = $product->get_categories();
foreach($category as $cat) {
	  ?>
        <p>
<a class="text-light" href="<?php echo $setting['website_url']; ?>/category/<?php echo $cat['id']; ?>/">
          <i class="fas fa-angle-double-right text-warning"></i> <?php echo $cat['name']; ?>
        </a>        
		</p>
          <?php } ?>
      </div>

      <!-- Grid column -->
      <hr class="w-100 clearfix d-md-none">


    </div>
    <!-- Footer links -->

    <hr class="text-gray">

    <!-- Grid row -->
    <div class="row d-flex align-items-center">

      <!-- Grid column -->
      <div class="col-md-7 col-lg-8">

        <!--Copyright-->
        <p class="text-center text-md-left">© <?php echo date('Y'); ?> Copyright:
          <a class="text-warning" href="<?php echo $setting['website_url'];?>">
            <strong><?php echo $setting['site_name'];?></strong>
          </a>
        </p>

      </div>
      <!-- Grid column -->
    <!-- Grid column -->
      <div class="col-md-5 col-lg-4 ml-lg-0">

        <!-- Social buttons -->
        <div class="text-center text-md-right">
          <ul class="list-unstyled list-inline">
          <?php if ($setting['facebook'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['facebook']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['twitter'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['twitter']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['instagram'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['instagram']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['googlep']  !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['googlep']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-google-plus-g"></i>
              </a>
            </li>
          <?php }else {} ?>
          <?php if ($setting['linkedin'] !== ''){ ?>
            <li class="list-inline-item">
              <a href="<?php echo $setting['linkedin']; ?>" class="btn-warning btn-sm rgba-white-slight mx-1 bg-warning">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </li>
          <?php }else {} ?>
          </ul>
        </div>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

</footer>
<!-- Footer -->
<?php }?>
<!-- Footer -->
</body>
</html>
