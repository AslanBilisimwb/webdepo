<?php 
$gateways = array();
$gateways[] = array(
'name' => 'Shopier',
'logo' => 'shopier_logo.png',
'file' => 'shopier.php'
);
?>