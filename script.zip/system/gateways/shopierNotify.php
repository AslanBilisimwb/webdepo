<?php 
$status = $_POST["status"];
$status = strtolower($status);
require_once('../config-user.php');
$redir = $_SESSION['payment']['redir'];
$action = $_SESSION['payment']['action'];
$amount = $_SESSION['payment']['amount'];
$details = $product->details($_SESSION['payment']['product_id']);

if ($status == "success") {
		$transaction->update($_SESSION['payment']['id'] ,'callback','1');
			if($_SESSION['payment']['action']== "deposit"){
				$curr = $user->details($_SESSION['uid']);
				$newBal = $curr['balance'] + $_SESSION['payment']['amount'];
				$user->update($_SESSION['uid'],'balance',$newBal);
				}	
			if($_SESSION['payment']['action']== "purchase"){
				$query_age = (isset($_SESSION['discountcoupon']) ? $_SESSION['discountcoupon'] : null);
				$trans_id = $transaction->add($_SESSION['uid'],$amount,$_SESSION['payment']['product_id'],'1','1');
				$buy = $purchases->add($_SESSION['uid'],$_SESSION['payment']['product_id'],$trans_id,'1',$query_age);
				}
				
unset($_SESSION['payment']);header('location:../../user/'.$redir.'?msg=İşlem Başarılı!&type=alert-success');
}else{
	unset($_SESSION['payment']);header('location:../../user/'.$redir.'?msg=İşlem Başarısız&type=alert-danger');
}
?>
