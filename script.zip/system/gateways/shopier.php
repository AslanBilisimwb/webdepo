<?php
require_once('../config-user.php');
$userID = $_SESSION['uid'];		
$redir = $_SESSION['payment']['redir'];
$action = $_SESSION['payment']['action'];
if(isset($_REQUEST) && isset($_REQUEST['crf'])){
$_REQUEST['crf'] = $_SESSION['payment']['crf'];
$_REQUEST['transaction_id'] = $order_id = $_SESSION['payment']['id'];
$_REQUEST['detail'] = $detail = $_SESSION['payment']['detail'];
$_REQUEST['amount'] = $amount = $_SESSION['payment']['amount'];
$_REQUEST['product_id'] = $product_id = $_SESSION['payment']['product_id'];
}
$fname = $userDetails['fname'];
$lname = $userDetails['lname'];
$email = $userDetails['email'];
$gsm = $userDetails['gsm'];
$address = $userDetails['address'];
$city = $userDetails['city'];
$postcode = $userDetails['postcode'];

include 'shopierAPI.php'; 
$shopier = new Shopier($setting['apiuser'], $setting['apipass']);
$shopier->setBuyer([ 
'id' => $order_id, 
'paket' => $detail, 
'first_name' => $fname, 
'last_name' => $lname, 
'email' => $email, 
'phone' => $gsm]); 
$shopier->setOrderBilling([
'billing_address' => $address, 
'billing_city' => $city,
'billing_country' => 'Türkiye', 
'billing_postcode' => $postcode, 
]);
$shopier->setOrderShipping([
'shipping_address' => 'Online Teslimat', 
'shipping_city' => $city,
'shipping_country' => 'Türkiye', 
'shipping_postcode' => $postcode, 
]);

die($shopier->run($order_id, $amount, 'shopierNotify.php')); 
?>