<?php 

require_once('config-user.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_GET['pid'])){
$id = $_GET['pid'];
$error = false;
$error = (!$product->is_product($id)?$products->error:$error);

} else{
    echo'Invalid Data!';
    die();
}
if(!$error) {
$file = $product->details($id);
if($file['free'] == 0){
    echo'This item is not available for FREE!';
    die();
}
$dlname = $file['dlname'];
$file_url = $file['file'];
$file_location = '../system/assets/uploads/uploaded-items/'.$file_url;
	//Works


ob_clean();
ob_end_flush();
header('Content-type: application/zip');
header("Content-Transfer-Encoding: Binary"); 
header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\""); 
readfile($file_location);
//unlink($file_location);

}
echo $error;
 	